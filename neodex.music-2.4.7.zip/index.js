// NeoMusic : ton appli d'origine (HTML et code inchangés), livrée en plugin.
// Ses données sont dans le dossier du plugin, que NeoDex sauvegarde (synchro cloud et sauvegardes) ; à la première ouverture elle reprend ce que tu avais dans NeoDex.
// Elle tourne dans le bac à sable de NeoDex, avec ses outils d'interface (ctx.host) et seulement les autorisations de son plugin.json.
const HTML = "";
const MU_CSS = `/* NeoMusic: MuPlayer's look (Consolas, flat cards, accent strips); colours are the theme's, set on #mu by muApplyTheme */
#plug_neodex_music{overflow:hidden;background:#101425}
.mu{position:absolute;inset:0;display:flex;flex-direction:column;background:var(--mbg);color:var(--mtext);font:15px var(--mfont,Consolas),'Cascadia Mono',monospace;user-select:none;overflow:hidden}
:where(.mu) button{all:unset;box-sizing:border-box;cursor:var(--cp,pointer)}
:where(.mu) :is(input,select){font:inherit;color:inherit}
:where(.mu) button:disabled{cursor:default;opacity:.45}
:where(.mu) :focus-visible{outline:1px solid var(--macc);outline-offset:1px}
.mu ::-webkit-scrollbar{width:8px;height:8px} .mu ::-webkit-scrollbar-track{background:transparent}
.mu ::-webkit-scrollbar-thumb{background:var(--mcard2)} .mu ::-webkit-scrollbar-thumb:hover{background:var(--macc)}
.muTop{height:38px;flex:none;display:flex;align-items:center;background:var(--mside);white-space:nowrap;overflow:hidden}
.muTopStrip{width:5px;align-self:stretch;background:var(--macc)}
.muBrand{margin:0 4px 0 14px;color:var(--mwarn);font-size:15px;letter-spacing:.5px}
.muStatus{margin-left:18px;color:var(--mwarn);font-weight:bold;font-size:14px;overflow:hidden;text-overflow:ellipsis;min-width:0}
.muDl{width:120px;height:4px;margin-left:16px;flex:none} .muDl i{display:block;height:100%;width:0;background:var(--macc);transition:width .2s}
.muInd{margin-left:18px;color:var(--macc2);font-weight:bold;font-size:13px} .muInd:empty{display:none}
.muMenuBtn{margin-left:8px!important;margin-right:2px!important;color:#fff} .muTopBtn{margin-left:auto;width:44px;align-self:stretch;display:grid;place-items:center;color:var(--msub);font-size:15px;font-weight:bold}
.muTopBtn:hover{background:var(--mcard);color:var(--mtext)}
.muBody{flex:1;display:flex;min-height:0}
/* sidebar: 250 px, accent strip on top, toggle column on the right */
.muSide{width:250px;flex:none;display:grid;grid-template-columns:1fr;grid-template-rows:3px 1fr;overflow:hidden;background:var(--mside);transition:width .12s}
.muSideStrip{grid-column:1/-1;background:var(--macc)}
.muSideIn{overflow-y:auto;overflow-x:hidden;padding-bottom:16px;min-width:0}
.muSide.closed{width:0} .muSide.closed .muSideIn{visibility:hidden}
.muSideToggle{display:grid;place-items:center;color:var(--macc);font-size:20px;font-weight:bold} .muSideToggle:hover{background:var(--mcard);color:var(--mtext)}
.muHead{padding:14px 10px 6px 24px;color:var(--msub);font-weight:bold;font-size:14px;letter-spacing:.3px}
#muPlaylists{padding:0 0 0 14px}
.muPlBtn{display:flex;align-items:center;width:100%;margin:1px 0;color:var(--mtext);font-size:15px}
.muPlBtn i{width:3px;align-self:stretch;flex:none}
.muPlBtn .ic{width:16px;margin:0 8px 0 12px;flex:none;display:grid;place-items:center;font-size:14px;color:#fff} .muPlBtn .ic svg{display:block}
.muPlBtn span:last-of-type{flex:1;min-width:0;text-align:left;padding:8px 10px 8px 2px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;line-height:1.25;word-break:break-word} .muPlBtn em{display:none}
.muPlBtn:hover,.muPlBtn.on{background:var(--mcard);color:var(--macc)} .muPlBtn.on i{background:var(--macc)} .muPlBtn:active{background:var(--mpress)}
.muPills{display:flex;gap:8px;margin:6px 0 18px 14px}
.muPill{flex:1;text-align:center;padding:7px 4px;background:var(--mcard2);color:var(--macc2);font-weight:bold;font-size:13px}
.muPill:hover{background:var(--macc);color:#06110C} .muPill.danger{color:var(--mdanger)} .muPill.danger:hover{background:color-mix(in srgb,var(--mdanger) 24%,var(--mcard2));color:var(--mdanger)}
.muExtra>.muSideBtn:first-child{margin-top:0}
.muSideIn>.muExtra:last-child{padding:0 0 0 14px}
.muSideBtn{display:flex;align-items:center;gap:14px;width:100%;margin:2px 0;padding:9px 10px;color:var(--mtext);font-size:15px}
.muSideBtn svg{color:#fff;flex:none;image-rendering:pixelated;margin-right:2px} .muSideBtn:hover{background:var(--mcard);color:var(--macc)} .muSideBtn:active{background:var(--mpress)}
:where(.mu,.mu *,.muLayer,.muLayer *,.muWin,.muWin *,.muMenu,.muMenu *,.muMini,.muMini *){text-align:left}
/* main column: three cards */
.muMain{flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;padding:18px 18px 18px 0;margin-left:0}
.mu .muMain{margin:0;height:auto;overflow:hidden;z-index:auto}  /* NeoDex styles every <main> */
.muCard{background:var(--mcard);border:1px solid var(--mborder);flex:none;animation:muReveal .25s ease-out}
.mu{isolation:isolate} .muAmb{position:absolute;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none;image-rendering:pixelated}
.mu.amb{--mcA:color-mix(in srgb,var(--mcard) 64%,transparent);--mcB:color-mix(in srgb,var(--mcard) 44%,transparent)} .mu.amb.amb[data-ms] .muCard{background:var(--mcA)} .mu.amb.amb[data-ms] .muCard{backdrop-filter:none} .mu.amb.amb[data-ms] .muCard:is(.muNow,.muReco){background:var(--mcB)} .mu.amb.amb.amb[data-ms=rubis] .muCard{--mx:var(--mcA);background:linear-gradient(135deg,color-mix(in srgb,var(--macc) 14%,var(--mx)),var(--mx) 45%)} .mu.amb.amb[data-ms=rubis] .muCard:is(.muNow,.muReco){--mx:var(--mcB)} .mu.amb.amb.amb[data-ms=cuivre] .muCard{--mx:var(--mcA);background:radial-gradient(circle at 10px 10px,var(--macc) 0 2.5px,transparent 3.5px),radial-gradient(circle at calc(100% - 10px) 10px,var(--macc) 0 2.5px,transparent 3.5px),linear-gradient(180deg,color-mix(in srgb,var(--macc) 10%,var(--mx)),var(--mx))} .mu.amb.amb[data-ms=cuivre] .muCard:is(.muNow,.muReco){--mx:var(--mcB)}  /* l'ambiance se voit à travers le lecteur ; la liste reste bien lisible */ .mu.amb .muMain{background:none}
@keyframes muReveal{from{transform:translateY(6px)}}  /* no fade: a hidden window would leave it half-faded */
.muNow{display:flex;align-items:center;gap:18px;padding:18px 20px}
.muCoverWrap{flex:none;width:270px;height:200px;display:grid;place-items:center}
.muCoverWrap.rect{width:130px;height:130px}
.muCoverWrap canvas{width:100%;height:100%}
@media (max-width:900px){.muCoverWrap{width:200px;height:150px}}
.muInfo{flex:1;min-width:0;display:flex;flex-direction:column}
.muKick{color:var(--macc);font-weight:bold;font-size:14px;letter-spacing:.3px} .muKick.alt{color:var(--macc2)}
.muTitle{margin:4px 0 2px;font-size:20px;font-weight:bold;line-height:1.3;height:2.6em;overflow:hidden;word-break:break-word;user-select:text}
.muTime{color:var(--msub);font-size:14px}
.muProgress{width:100%;height:36px;margin:10px 0 14px;cursor:var(--cp,pointer);display:block}
.muSpectrum{height:64px;margin-bottom:10px;display:block;image-rendering:pixelated}  /* drawn at the size of the art pixels, scaled up crisp */
/* NeoMusic's portable player: pixel frame (notched corners, accent top), spinning record, pixel spectrum, pixel buttons */
.muMini{position:fixed;z-index:32;left:0;top:0;width:430px;display:none;grid-template-columns:92px 1fr;gap:14px;padding:12px 14px 10px;
  background:var(--mcard);color:var(--mtext);font:14px var(--mfont,Consolas),'Cascadia Mono',monospace;cursor:var(--cg,grab);touch-action:none;user-select:none;
  box-shadow:0 -3px 0 0 var(--macc),0 3px 0 0 var(--mborder),-3px 0 0 0 var(--mborder),3px 0 0 0 var(--mborder),0 -6px 0 -3px var(--macc),9px 9px 0 0 rgba(0,0,0,.45)}
.muMini.on{display:grid;animation:mmIn .2s steps(4)}
@keyframes mmIn{from{transform:translateY(12px);opacity:.3}}
#mmAmb{position:absolute;inset:0;width:100%;height:100%;z-index:0;image-rendering:pixelated;pointer-events:none;display:none} .muMini.amb #mmAmb{display:block} .muMini.amb>:not(#mmAmb){position:relative;z-index:1}
.muMini.drag{cursor:var(--cgg,grabbing)}
.muMini::before{content:"";position:absolute;left:0;right:0;top:0;height:3px;background:repeating-linear-gradient(90deg,var(--macc) 0 6px,var(--macc2) 6px 9px);opacity:.55}
#mmDisc{width:92px;height:92px;align-self:center} .muMini.deck{width:460px;grid-template-columns:130px 1fr} .muMini.deck #mmDisc{width:130px;height:96px}  /* 460 : la largeur maxi d’une frame flottante de NeoDex */
.mmBody{min-width:0;display:flex;flex-direction:column;gap:3px}
.mmTop{display:flex;align-items:center;gap:6px;height:20px}
.mmKick{color:var(--macc);font-weight:bold;font-size:12px;letter-spacing:2px} #mmState{flex:1;font-size:12px;font-weight:bold;letter-spacing:1px}
#mmTitle{font-size:15px;line-height:1.3;min-height:1.3em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#mmArtist{color:var(--msub);font-size:13px;line-height:1.3;min-height:1.3em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mmSpecBox{height:21px;margin-top:2px} .mmSpecBox.sup{height:39px} #mmSpec{display:block;image-rendering:pixelated}
.mmBar{display:flex;align-items:center;gap:8px}
#mmSeek{flex:1;height:6px;background:var(--mcard2);cursor:var(--cp,pointer);box-shadow:0 2px 0 rgba(0,0,0,.35)} #mmSeek:hover{height:8px}
#mmSeek i{display:block;height:100%;width:0;background:repeating-linear-gradient(90deg,var(--macc) 0 4px,color-mix(in srgb,var(--macc) 75%,#fff) 4px 6px)}
#mmTime{color:var(--msub);font-size:12px;white-space:nowrap}
.mmCtl{display:flex;align-items:center;gap:4px;margin-top:3px}
.mmBtn{all:unset;box-sizing:border-box;cursor:var(--cp,pointer);width:30px;height:26px;display:grid;place-items:center;color:var(--mtext);background:var(--mcard2);
  box-shadow:inset 0 2px 0 rgba(255,255,255,.08),0 2px 0 rgba(0,0,0,.4);transition:background .1s,color .1s}
.mmBtn:hover{background:color-mix(in srgb,var(--macc) 24%,var(--mcard2));color:var(--macc)} .mmBtn:active{transform:translateY(2px);box-shadow:none}
#mmPlay{width:38px;background:var(--macc);color:#06110C} #mmPlay:hover{background:var(--macc2);color:#06110C}
#mmFav.on{color:var(--mheart)}
.mmTop .mmBtn{width:22px;height:18px;background:transparent;box-shadow:none;color:var(--msub)} .mmTop .mmBtn:hover{background:var(--mcard2);color:var(--mtext)} #mmClose:hover{background:var(--mdanger);color:#fff}
#mmVol{margin-left:auto;color:var(--msub);font-size:12px;letter-spacing:1px}
body.vfs .muMini{display:none}
body.mmFloat>*:not(.muMini){display:none!important} body.mmFloat{overflow:hidden;background:transparent!important} body.mmFloat .muMini{left:0!important;top:0!important}
.mu.novis .muSpectrum{display:none}
.muControls{display:flex;align-items:center;justify-content:center;gap:24px}
.muSkip{width:40px;height:40px} .muSkip{position:relative;color:#fff;display:grid;place-items:center} .muSkip>svg+svg{width:24px!important;height:auto!important;position:absolute!important;inset:auto!important} .muSkip>svg:first-child{width:40px;height:40px;fill:var(--mtext);display:block} .muSkip:hover{color:var(--macc)} .muSkip>svg+svg{fill:none}
.muSkip .halo{fill:transparent;transition:fill .12s} .muSkip:hover .halo{fill:var(--mcard2)} .muSkip:hover>svg:first-child{fill:var(--macc)} .muSkip:active .halo{fill:var(--mpress)}
.muPlay{width:64px;height:64px;border-radius:50%;position:relative} .muPlay>svg{width:64px;height:64px;display:block} .muPlay>span{position:absolute;inset:0!important;display:grid!important;place-items:center;pointer-events:none} .muPlay>span svg{width:28px;height:auto;display:block}
.muPlay .fill{fill:var(--macc);transition:fill .12s} .muPlay:hover .fill{fill:var(--macc2)} .muPlay:active>svg{transform:scale(.95)}
.muNowSide{flex:none;width:150px;align-self:flex-start;display:flex;flex-direction:column;align-items:center}
.muNowSide .muBtn{margin-bottom:10px}
.muSmall{color:var(--msub);font-weight:bold;font-size:13px;margin-top:4px} .muNowSide .muSmall+.muSelect{margin-top:3px} .muNowSide .muRange+.muSmall{margin-top:12px}
.muBtn{display:inline-block;padding:8px 12px;background:var(--mcard2);color:var(--mtext);font-weight:bold;font-size:14px;white-space:nowrap;text-align:center}
.muBtn:hover{background:var(--mcard)} .muBtn:active{background:var(--mpress)} .muBtn.accent{color:var(--macc)} .muBtn.danger{color:var(--mdanger)}
.muRange{-webkit-appearance:none;appearance:none;width:130px;height:14px;background:transparent;margin:4px 0;cursor:var(--cp,pointer)}
.muRange::-webkit-slider-runnable-track{height:6px;background:var(--mcard2)}
.muRange::-webkit-slider-thumb{-webkit-appearance:none;width:10px;height:14px;margin-top:-4px;background:var(--macc);border:1px solid var(--mtext)}
.muRange:hover::-webkit-slider-thumb{background:var(--macc2)}
.muSelect{background:var(--mcard2);color:var(--macc);border:0;padding:5px 8px;font-size:13px;outline:none;cursor:var(--cp,pointer);max-width:100%}
.muSelect.sub{color:var(--msub)} .muSelect option{background:var(--mcard2);color:var(--mtext)}
.muNowSide .muSelect{width:130px}
/* recommendation */
.muReco{display:flex;align-items:center;gap:14px;padding:14px 20px}
#muRecoCover{width:54px;height:54px}
.muRecoText{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
#muReco{font-size:15px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
/* framed covers (ArtworkFrame): border, hard shadow, accent corner; "?" when there is none */
.muArt{position:relative;flex:none;background:var(--mcard2);border:2px solid var(--mborder);box-shadow:3px 3px 0 #090B12}
.muArt::before{content:"";position:absolute;left:-2px;top:-2px;width:45%;height:45%;border-top:2px solid var(--macc);border-left:2px solid var(--macc);pointer-events:none;z-index:1}
.muArt.alt::before{border-color:var(--macc2)}
.muArt img{width:100%;height:100%;object-fit:cover;display:block}
.muArt:not(:has(img))::after{content:"?";position:absolute;inset:0;display:grid;place-items:center;color:var(--macc);font-weight:bold;font-size:20px}
.muTile .muArt:not(:has(img))::after{font-size:44px}
.muArt.alt:not(:has(img))::after{color:var(--macc2)}
/* library */
.muLib{flex:1;min-height:120px;display:flex;flex-direction:column}
.muLibHead{display:flex;align-items:baseline;justify-content:space-between;gap:10px;padding:16px 20px 8px}
.muLibHead b{font-size:16px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .muLibHead #muWkInfo{flex:1;color:var(--msub);font-size:13px} .muWkBtn{padding:4px 10px;font-size:12px;align-self:center} .muWkBtn[hidden]{display:none} .muLibHead span{color:var(--msub);font-size:14px;flex:none}
.muFilters{display:flex;flex-wrap:wrap;gap:6px;padding:0 20px 10px}
.muFilter{width:190px;background:var(--mcard2);color:var(--mtext);border:0;padding:6px 8px;font-size:13px;outline:none;caret-color:var(--macc)}
.muFilter::placeholder{color:var(--msub)} .muFilter:focus{outline:1px solid var(--macc)}
.muList{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;margin:0 14px 14px;position:relative;outline:none;background:var(--mcard);overscroll-behavior:contain}
/* petit écran (PC portable) : toute la page défile, et la liste garde presque toute la hauteur une fois en bas */
@media (max-height:900px){.mu .muMain{overflow-y:auto;overscroll-behavior:contain} .mu .muLib{flex:none;height:calc(100% - 24px);min-height:340px} .mu .muList{overscroll-behavior:auto}}
#muSpacer{position:relative;width:100%}
.muRow{position:absolute;left:0;right:0;top:0;height:58px;display:flex;align-items:center;background:var(--mcard);cursor:var(--cp,pointer);backface-visibility:hidden}
.muRow:hover{background:color-mix(in srgb,var(--mcard) 70%,var(--mcard2))}
.muRow .muStrip{width:4px;align-self:stretch;flex:none}
.muRow .muArt{margin:0 12px 0 10px}
.muRowText{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.muRowText b{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.muRowText div{display:flex;align-items:baseline;gap:8px}
.muRowText span{flex:1;min-width:0;color:var(--msub);font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.muRowText em,.muTile em{font-style:normal;color:var(--macc2);font-weight:bold;font-size:14px;flex:none}
.muRowFav{padding:6px 8px;margin-left:8px;color:var(--msub);font-size:16px;transition:color .13s} .muRowFav.on{color:var(--mheart)} .muRowFav:hover{color:var(--mheart)}
.muRowDel{padding:6px 8px;margin-right:4px;color:var(--msub);font-size:15px;transition:color .13s} .muRowDel:hover{color:var(--mdanger)}
.muRow.sel,.muTile.sel{background:var(--mcard2);box-shadow:inset 0 0 0 1px var(--macc)}
.muRow.sel .muStrip,.muTile.sel .muStrip{background:var(--macc)}
.muRow.playing .muRowText b,.muTile.playing b{color:var(--macc)}
.muRow.playing .muRowText b::before,.muTile.playing b::before{content:"▶ ";font-size:12px}
.muRow.missing,.muTile.missing{opacity:.5}
.muTile{position:absolute;left:0;top:0;width:152px;height:196px;display:flex;flex-direction:column;align-items:center;background:var(--mcard);cursor:var(--cp,pointer);backface-visibility:hidden}
.muTile:hover{background:color-mix(in srgb,var(--mcard) 70%,var(--mcard2))}
.muTile .muStrip{height:3px;width:100%;flex:none}
.muTile .muArt{margin:8px 0 4px}
.muTile b,.muTile>span{width:100%;padding:0 8px;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.muTile b,.muTile>span,.muTile em{line-height:1.2} .muTile b{font-size:14px} .muTile>span{color:var(--msub);font-size:13px}
.muTileAct{display:flex;justify-content:space-around;width:100%;margin-top:auto}
.muTileAct .muRowFav,.muTileAct .muRowDel{margin:0;padding:1px 10px 3px}
.mu.mini .muExtra{display:none!important}
.mu.mini .muNow{padding:12px 16px} .mu.mini .muSpectrum{display:none}
/* context menu (Tk Menu colours) */
.muMenu{position:fixed;z-index:60;min-width:210px;padding:3px;background:var(--mcard2);border:1px solid var(--mborder);box-shadow:4px 4px 0 #090B12;display:flex;flex-direction:column;font-size:14px}
.muMenu button{padding:6px 12px;white-space:nowrap;color:var(--mtext)} .muMenu button:hover:not(:disabled){background:var(--macc);color:#17111F}
.muMenu hr{border:0;border-top:1px solid var(--mborder);margin:3px 2px}
.muDecks{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:6px 0} .muDecks .muSmall{margin:0 4px 0 0;width:52px} .muSw{display:inline-block;width:10px;height:10px;margin:0 7px -1px 0;box-shadow:0 0 0 2px #0008} .muDecks .muBtn.on{box-shadow:inset 0 0 0 2px var(--macc)} .muDecks .muBtn.locked{opacity:.45}
/* Interface Deluxe (niveau 200, settings.deluxe) : l'appli pixel en plus grand et plus riche, toujours aux couleurs du thème.
   Fond tramé, cadres doubles à coins crantés et ombre pleine, bandeaux en damier, platine et titre en vedette, liste rayée. */
.mu.lux{background-color:var(--mbg);background-image:conic-gradient(color-mix(in srgb,var(--mcard) 55%,transparent) 25%,transparent 0 50%,color-mix(in srgb,var(--mcard) 55%,transparent) 0 75%,transparent 0);background-size:6px 6px}
.mu.lux .muTop{height:56px;background:var(--mside);box-shadow:0 3px 0 var(--macc),0 6px 0 var(--mborder),0 12px 0 rgba(0,0,0,.35)}
.mu.lux .muSide{background:color-mix(in srgb,var(--mside) 92%,transparent);box-shadow:3px 0 0 var(--mborder),6px 0 0 rgba(0,0,0,.35)}
.mu.lux .muHead{color:var(--macc);letter-spacing:2px}
.mu.lux .muMain{gap:26px;padding:26px 26px 22px 10px}
.mu.lux .muCard{box-shadow:0 -3px 0 0 var(--macc),0 3px 0 0 var(--mborder),-3px 0 0 0 var(--mborder),3px 0 0 0 var(--mborder),0 -9px 0 -3px var(--mborder),0 9px 0 -3px var(--mborder),-9px 0 0 -3px var(--mborder),9px 0 0 -3px var(--mborder),12px 12px 0 0 rgba(0,0,0,.45);
  background-image:linear-gradient(color-mix(in srgb,var(--mcard2) 40%,transparent),transparent 40%)}
.mu.lux .muCard::before{height:6px;background:conic-gradient(var(--macc) 25%,var(--macc2) 0 50%,var(--macc) 0 75%,var(--macc2) 0) 0 0/6px 6px;opacity:.8}
.muLogo,.muBrandTag,.muEqPick{display:none}
.muKickRow{display:flex;align-items:center;justify-content:space-between;gap:10px} .muLuxLv{display:none}
/* Deluxe : la carte « lecture en cours » devient une chaîne hi-fi en pixels. La platine sur sa plaque gravée, un écran (titre, temps, spectre)
   à lignes de balayage, puis la rangée de touches sous l'écran. */
.mu.lux .muNow{padding:24px 26px;gap:26px;align-items:stretch}
.mu.lux .muCoverWrap{width:372px;height:276px;align-self:center} .mu.lux .muCoverWrap.rect{width:190px;height:190px}
.mu.lux .muInfo{padding:16px 20px 0;background:color-mix(in srgb,var(--mbg) 55%,#000);background-image:repeating-linear-gradient(0deg,rgba(255,255,255,.04) 0 1px,transparent 1px 4px);
  box-shadow:inset 0 0 0 3px var(--mborder),inset 0 0 0 6px color-mix(in srgb,var(--mbg) 40%,#000),inset 0 9px 0 6px rgba(0,0,0,.3);overflow:hidden}
.mu.lux .muKick{display:inline-block;align-self:flex-start;padding:4px 10px;background:var(--macc);color:var(--mbg);box-shadow:3px 3px 0 rgba(0,0,0,.45)} .mu.lux .muKick.alt{background:var(--macc2)}
.mu.lux .muLuxLv{display:inline-block;padding:4px 10px;font-size:13px;font-weight:bold;letter-spacing:2px;color:var(--macc2);box-shadow:inset 0 0 0 2px var(--macc2)}
.mu.lux .muTitle{font-size:24px;margin-top:12px;color:var(--mtext);text-shadow:2px 2px 0 #000}
.mu.lux .muTime{font-size:18px;font-weight:bold;letter-spacing:3px;color:var(--macc2);text-shadow:0 0 0 transparent,2px 2px 0 #000}
.mu.lux .muSpectrum{margin-bottom:12px;background:transparent;box-shadow:none}
.mu.lux .muControls{margin:auto 0 6px;padding:10px 0 14px;background:transparent;box-shadow:none}  /* dans l’écran, sur son fond noir */
.mu.lux .muNowSide{align-self:stretch;justify-content:center;padding:12px 10px;background:color-mix(in srgb,var(--mbg) 55%,#000);background-image:repeating-linear-gradient(0deg,rgba(255,255,255,.04) 0 1px,transparent 1px 4px);box-shadow:inset 0 0 0 3px var(--mborder),inset 0 0 0 6px color-mix(in srgb,var(--mbg) 40%,#000),inset 0 9px 0 6px rgba(0,0,0,.3)}  /* le même écran que celui du titre */
/* Deluxe : touches de chaîne hi-fi (carrées, en relief) */
.mu.px.lux .muControls{position:relative;gap:16px}
.mu.px.lux .muSkip{width:54px;height:44px;background:var(--mcard2);color:var(--mtext);box-shadow:inset 0 3px 0 rgba(255,255,255,.12),inset 0 -4px 0 rgba(0,0,0,.4),0 0 0 2px var(--mborder),4px 4px 0 2px rgba(0,0,0,.45)}
.mu.px.lux .muSkip>svg:first-child{display:none} .mu.px.lux .muSkip:hover{background:color-mix(in srgb,var(--macc) 22%,var(--mcard2))}
.mu.px.lux .muPlay{width:84px;height:52px;border-radius:0;background:var(--macc);filter:none;box-shadow:inset 0 4px 0 rgba(255,255,255,.35),inset 0 -5px 0 rgba(0,0,0,.3),0 0 0 2px var(--mborder),4px 4px 0 2px rgba(0,0,0,.45)}
.mu.px.lux .muPlay>svg{display:none} .mu.px.lux .muPlay:hover{background:var(--macc2)}
.mu.px.lux .muSkip:active,.mu.px.lux .muPlay:active{transform:translateY(4px);box-shadow:inset 0 -2px 0 rgba(0,0,0,.35),0 0 0 2px var(--mborder)}
/* Deluxe : le panneau des réglages, titré, en rangées */
.mu.px.lux .muNowSide{width:178px;align-self:stretch;justify-content:flex-start;align-items:stretch;gap:0;padding:16px 16px 16px}
.mu.px.lux .muNowSide::before{content:"RÉGLAGES";align-self:flex-start;margin:0 0 22px;padding:4px 10px;font-size:14px;font-weight:bold;color:var(--mbg);background:var(--macc);box-shadow:3px 3px 0 rgba(0,0,0,.45)}  /* comme « LECTURE EN COURS » */
.mu.px.lux .muNowSide .muBtn{width:100%;margin-bottom:16px;padding:10px 0}
.mu.px.lux .muNowSide .muBtn.on{color:var(--mheart);box-shadow:inset 0 0 0 2px var(--mheart),0 4px 0 rgba(0,0,0,.5)}
.mu.px.lux .muNowSide .muSmall{display:flex;align-items:center;gap:7px;margin:0 0 6px;color:var(--macc);letter-spacing:2px}
.mu.px.lux .muNowSide .muSmall::before{content:"";width:6px;height:6px;background:var(--macc2);box-shadow:2px 2px 0 rgba(0,0,0,.45)}
.mu.px.lux .muNowSide .muRange{width:100%;height:20px;margin:0 0 16px}
.mu.px.lux .muRange::-webkit-slider-runnable-track{height:12px;background:repeating-linear-gradient(90deg,transparent 0 5px,var(--mside) 5px 7px),linear-gradient(90deg,var(--macc) var(--v,50%),var(--mcard2) 0);box-shadow:0 0 0 2px var(--mborder)}
.mu.px.lux .muRange::-webkit-slider-thumb{width:10px;height:20px;margin-top:-4px;border:0;background:var(--mtext);box-shadow:inset 0 -3px 0 rgba(0,0,0,.3),2px 2px 0 rgba(0,0,0,.5)}
.mu.px.lux .muNowSide .muSelect{display:none}
.mu.px.lux .muEqPick{display:flex;align-items:stretch;height:32px;box-shadow:0 0 0 2px var(--mborder),3px 3px 0 2px rgba(0,0,0,.45)}
.mu.px.lux .muEqPick button{width:28px;flex:none;display:grid;place-items:center;background:var(--mcard2);color:var(--macc);box-shadow:inset 0 3px 0 rgba(255,255,255,.1),inset 0 -3px 0 rgba(0,0,0,.4)}
.mu.px.lux .muEqPick button:hover{background:var(--macc);color:var(--mbg)} .mu.px.lux .muEqPick button:active{transform:translateY(2px)}
.mu.px.lux #muEqName{flex:1;min-width:0;display:grid;place-items:center;padding:0 4px;font-size:13px;font-weight:bold;letter-spacing:1px;color:var(--mtext);background:color-mix(in srgb,var(--mbg) 55%,#000);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
/* Deluxe : la barre du haut (touche menu, logo, afficheur d'état) */
.mu.px.lux .muTop{height:58px;background:var(--mside);background-image:repeating-linear-gradient(0deg,transparent 0 3px,rgba(255,255,255,.03) 3px 4px);box-shadow:0 3px 0 var(--macc),0 6px 0 var(--mborder),0 10px 0 rgba(0,0,0,.35)}
.mu.px.lux .muMenuBtn{width:40px;height:36px;margin:0 6px 0 14px!important;background:var(--mcard2);box-shadow:inset 0 3px 0 rgba(255,255,255,.1),inset 0 -4px 0 rgba(0,0,0,.4),0 0 0 2px var(--mborder),3px 3px 0 2px rgba(0,0,0,.45)}
.mu.px.lux .muBrand{display:flex;align-items:center;gap:0;margin:0 18px 0 12px;padding:0;background:none;clip-path:none;box-shadow:none;color:var(--mtext);font-size:20px;letter-spacing:3px;text-shadow:2px 2px 0 #000}
.mu.px.lux .muLogo{display:block;margin-right:12px;color:var(--macc);filter:drop-shadow(2px 2px 0 #000)} .mu.px.lux .muLogo svg{display:block}
.mu.px.lux .muBrand2{color:var(--macc)}
.mu.px.lux .muBrandTag{display:block;margin-left:12px;padding:3px 7px;font-style:normal;font-size:12px;letter-spacing:2px;color:var(--macc2);text-shadow:none;box-shadow:inset 0 0 0 2px var(--macc2)}
.mu.px.lux .muStatus{padding:6px 14px;background:color-mix(in srgb,var(--mbg) 55%,#000);background-image:repeating-linear-gradient(0deg,rgba(255,255,255,.04) 0 1px,transparent 1px 3px);box-shadow:inset 0 0 0 2px var(--mborder);letter-spacing:2px}
/* Deluxe : les playlists en étiquettes (pastille d'icône, nom, nombre de titres) */
.mu.px.lux #muPlaylists{gap:9px}
.mu.px.lux .muPlBtn{min-height:42px;padding:0 10px 0 6px;border:0;background:var(--mcard);box-shadow:inset 0 0 0 2px var(--mborder),inset 0 4px 0 rgba(255,255,255,.04),3px 3px 0 1px rgba(0,0,0,.45);transition:transform .08s steps(2)}
.mu.px.lux .muPlBtn .ic{width:28px;height:28px;margin:0 10px 0 0;background:var(--mcard2);box-shadow:inset 0 0 0 2px var(--mborder);color:var(--macc)}
.mu.px.lux .muPlBtn em{display:block;flex:none;min-width:30px;padding:2px 6px;font-style:normal;font-size:12px;font-weight:bold;text-align:center;color:var(--msub);background:var(--mside);box-shadow:inset 0 0 0 1px var(--mborder)}
.mu.px.lux .muPlBtn:hover:not(.on){transform:translateX(3px);color:var(--macc);box-shadow:inset 0 0 0 2px var(--macc),3px 3px 0 1px rgba(0,0,0,.45)}
.mu.px.lux .muPlBtn.on{background:var(--macc);color:var(--mbg);box-shadow:inset 0 4px 0 rgba(255,255,255,.25),inset 0 -4px 0 rgba(0,0,0,.2),3px 3px 0 1px rgba(0,0,0,.45)}
.mu.px.lux .muPlBtn.on .ic{background:var(--mbg);color:var(--macc);box-shadow:none} .mu.px.lux .muPlBtn.on em{background:var(--mbg);color:var(--macc);box-shadow:none}
.mu.px.lux .muPills{gap:10px;margin:16px 12px 10px}
.mu.px.lux .muPill{padding:9px 4px;border:0;background:var(--mcard2);color:var(--macc2);box-shadow:inset 0 3px 0 rgba(255,255,255,.1),inset 0 -4px 0 rgba(0,0,0,.4),0 0 0 2px var(--mborder),3px 3px 0 2px rgba(0,0,0,.45)}
.mu.px.lux .muPill.danger{color:var(--mdanger)} .mu.px.lux .muPill:hover{background:var(--macc2);color:var(--mbg)} .mu.px.lux .muPill.danger:hover{background:var(--mdanger);color:#fff}
.mu.lux .muRow{box-shadow:inset 0 -2px 0 color-mix(in srgb,var(--mborder) 45%,transparent)} .mu.lux .muRow:nth-child(even){background:color-mix(in srgb,var(--mcard) 86%,var(--mcard2))}
.mu.lux .muRow.sel{background:color-mix(in srgb,var(--macc) 22%,var(--mcard));box-shadow:inset 6px 0 0 var(--macc)}
.mu.lux .muBtn,.mu.lux .muPill{box-shadow:inset 0 3px 0 rgba(255,255,255,.12),inset 0 -4px 0 rgba(0,0,0,.35),0 4px 0 rgba(0,0,0,.5)} .mu.lux .muBtn:active,.mu.lux .muPill:active{transform:translateY(4px);box-shadow:inset 0 -2px 0 rgba(0,0,0,.35)}
.mu.lux .muPlay{filter:drop-shadow(4px 4px 0 rgba(0,0,0,.45))}
/* Appli pixel (settings.pixelUi): the look of the portable player everywhere */
.mu.px{font-family:var(--mfont,Consolas),'Cascadia Mono',monospace;letter-spacing:.2px}
.mu,.muMini{font-size-adjust:.49}  /* la hauteur des lettres de Consolas, quelle que soit la police du thème */
.mu.px *{border-radius:0!important;transition-timing-function:steps(3)!important}
.mu.px .muCard,.mu.px .muWin,.mu.px .muMenu{border:0;box-shadow:0 -3px 0 0 var(--macc),0 3px 0 0 var(--mborder),-3px 0 0 0 var(--mborder),3px 0 0 0 var(--mborder),0 -6px 0 -3px var(--macc),9px 9px 0 0 rgba(0,0,0,.45)}
.mu.px .muMain{gap:22px;padding:24px 22px 20px 6px} .mu.px .muWin{margin:8px}
.mu.px .muCard::before{content:"";display:block;height:3px;background:repeating-linear-gradient(90deg,var(--macc) 0 6px,var(--macc2) 6px 9px);opacity:.55}
.mu.px .muBtn,.mu.px .muPill,.mu.px .muSelect,.mu.px .muTopBtn{box-shadow:inset 0 2px 0 rgba(255,255,255,.08),0 3px 0 rgba(0,0,0,.45)}
.mu.px .muBtn:hover,.mu.px .muPill:hover{background:color-mix(in srgb,var(--macc) 24%,var(--mcard2));color:var(--mtext)} .mu.px .muBtn:active,.mu.px .muPill:active{transform:translateY(3px);box-shadow:none}
.mu.px .muSideBtn,.mu.px .muPlBtn{box-shadow:none} .mu.px .muSideBtn:active,.mu.px .muPlBtn:active{transform:translateY(2px)}
.mu.px .muRow,.mu.px .muTile{box-shadow:none} .mu.px .muRow.sel,.mu.px .muTile.sel{box-shadow:inset 0 0 0 2px var(--macc)}
.mu.px .muFilter,.mu.px .muArtFilter,.mu.px .muSelect{border:2px solid var(--mborder);box-shadow:inset 0 2px 0 rgba(0,0,0,.35)}
.mu.px .muRange::-webkit-slider-runnable-track{height:8px;background:repeating-linear-gradient(90deg,var(--mcard2) 0 4px,var(--mborder) 4px 6px)}
.mu.px .muRange::-webkit-slider-thumb{width:10px;height:18px;margin-top:-5px;border:2px solid var(--mtext);box-shadow:0 3px 0 rgba(0,0,0,.45)}
.mu.px .muWinBar{background-image:repeating-linear-gradient(90deg,transparent 0 6px,rgba(255,255,255,.035) 6px 9px)}
.mu.px ::-webkit-scrollbar{width:10px;height:10px} .mu.px ::-webkit-scrollbar-track{background:var(--mcard2)} .mu.px ::-webkit-scrollbar-thumb{background:var(--mborder);box-shadow:inset -2px -2px 0 rgba(0,0,0,.4),inset 2px 2px 0 rgba(255,255,255,.15)}
.mu.px .muCheck input[type=checkbox]{-webkit-appearance:none;appearance:none;margin:1px 0 0;width:16px;height:16px;flex:none;cursor:var(--cp,pointer);background:var(--mbg);border:2px solid var(--mborder);display:grid;place-items:center;box-shadow:inset 0 2px 0 rgba(0,0,0,.35)}
.mu.px .muCheck input[type=checkbox]:hover{border-color:var(--macc)} .mu.px .muCheck input[type=checkbox]:checked{background:var(--macc);border-color:var(--macc)}
.mu.px .muCheck input[type=checkbox]:checked::after{content:"";width:8px;height:4px;border-left:3px solid var(--mbg);border-bottom:3px solid var(--mbg);transform:translateY(-1px) rotate(-45deg)}
.mu.px .muTop{height:48px;background:var(--mside);box-shadow:0 3px 0 var(--macc),0 6px 0 rgba(0,0,0,.4);position:relative;z-index:3}
.mu.px .muTopStrip{display:none}
.mu.px .muBrand{margin:0 14px 0 12px;padding:9px 16px;background:var(--macc);color:var(--mbg);font-weight:800;letter-spacing:2px;box-shadow:inset 0 2px 0 rgba(255,255,255,.3),inset 0 -3px 0 rgba(0,0,0,.25);clip-path:polygon(0 4px,4px 4px,4px 0,calc(100% - 4px) 0,calc(100% - 4px) 4px,100% 4px,100% calc(100% - 4px),calc(100% - 4px) calc(100% - 4px),calc(100% - 4px) 100%,4px 100%,4px calc(100% - 4px),0 calc(100% - 4px))}
.mu.px .muStatus{margin-left:0;padding:5px 4px;background:none;box-shadow:none;letter-spacing:1px}
.mu.px .muTopBtn{background:var(--mcard2);margin:8px 12px 8px auto;width:36px;align-self:auto;height:32px}
.mu.px .muSide{background:var(--mside);box-shadow:4px 0 0 rgba(0,0,0,.35);position:relative;z-index:2;grid-template-rows:6px 1fr;background-image:repeating-linear-gradient(0deg,transparent 0 3px,rgba(255,255,255,.025) 3px 4px)}
.mu.px .muSideStrip{background:repeating-linear-gradient(90deg,var(--macc) 0 6px,var(--macc2) 6px 9px)}
.mu.px .muHead{display:flex;align-items:center;gap:8px;padding:18px 12px 8px 14px;color:var(--macc);font-size:13px;letter-spacing:2px;text-transform:uppercase}
.mu.px .muHead::before{content:"";width:8px;height:8px;flex:none;background:var(--macc);box-shadow:3px 3px 0 rgba(0,0,0,.45)}
.mu.px .muHead::after{content:"";flex:1;height:2px;background:repeating-linear-gradient(90deg,var(--mborder) 0 4px,transparent 4px 7px)}
.mu.px #muPlaylists{padding:0 12px 0 12px;display:flex;flex-direction:column;gap:7px}
.mu.px .muPlBtn{margin:0;background:var(--mcard);border:2px solid var(--mborder);box-shadow:inset 0 2px 0 rgba(255,255,255,.06),0 3px 0 rgba(0,0,0,.45);position:relative}
.mu.px .muPlBtn i{display:none}
.mu.px .muPlBtn:hover:not(.on){border-color:var(--macc);color:var(--macc);background:var(--mcard)}
.mu.px .muPlBtn.on{background:var(--macc);border-color:var(--macc);color:var(--mbg);font-weight:700}
.mu.px .muPlBtn.on .ic{color:var(--mbg)}
.mu.px .muPlBtn.on::after{content:"";position:absolute;right:-12px;top:50%;margin-top:-6px;border-left:8px solid var(--macc);border-top:6px solid transparent;border-bottom:6px solid transparent}
.mu.px .muPlBtn:active{transform:translateY(3px);box-shadow:none}
.mu.px .muPills{margin:12px 12px 8px}
.mu.px .muSideIn>.muExtra:last-child{padding:0 12px}
.mu.px .muSideBtn{margin:0 0 6px;padding:5px 8px;gap:12px;background:transparent;border:2px solid transparent;box-shadow:none}
.mu.px .muSideBtn svg{padding:5px;box-sizing:content-box;background:var(--mcard2);border:2px solid var(--mborder);box-shadow:inset 0 2px 0 rgba(255,255,255,.08),0 3px 0 rgba(0,0,0,.45);margin:0 0 3px}
.mu.px .muSideBtn:hover{background:var(--mcard);border-color:var(--mborder);color:var(--macc)} .mu.px .muSideBtn:hover svg{border-color:var(--macc);background:color-mix(in srgb,var(--macc) 24%,var(--mcard2))}
.mu.px .muSideBtn:active svg{transform:translateY(3px);box-shadow:none}
.mu.px .muSide:not(.closed){width:276px} .mu.px .muSideBtn span{white-space:nowrap;font-size:12.5px} .mu.px .muSideBtn svg{padding:4px}

.mu.px .muWinBar{height:40px;background:var(--mside);box-shadow:0 3px 0 var(--macc)} .mu.px .muWinBar i{display:none}
.mu.px .muWinBar b{flex:none;margin:0 12px;padding:5px 12px;background:var(--macc);color:var(--mbg);letter-spacing:2px;text-transform:uppercase;clip-path:polygon(0 3px,3px 3px,3px 0,calc(100% - 3px) 0,calc(100% - 3px) 3px,100% 3px,100% calc(100% - 3px),calc(100% - 3px) calc(100% - 3px),calc(100% - 3px) 100%,3px 100%,3px calc(100% - 3px),0 calc(100% - 3px))}
.mu.px .muWinBar::after{content:"";flex:1;order:1;height:2px;margin:0 8px;background:repeating-linear-gradient(90deg,var(--mborder) 0 4px,transparent 4px 7px)} .mu.px .muWinBar button{order:2}
.mu.px .muWH{display:flex;align-items:center;gap:10px;letter-spacing:2px;text-transform:uppercase} .mu.px .muWH::after{content:"";flex:1;height:2px;background:repeating-linear-gradient(90deg,var(--macc) 0 4px,transparent 4px 7px);opacity:.6}
.mu.px .muWSec{display:flex;align-items:center;gap:8px;letter-spacing:2px} .mu.px .muWSec::before{content:"";width:7px;height:7px;background:var(--macc2);box-shadow:2px 2px 0 rgba(0,0,0,.45)}
.mu.px .muWRow,.mu.px .muArtRow,.mu.px .muTrashList button{box-shadow:none} .mu.px .muArtList{border:2px solid var(--mborder)} .mu.px .muArtHead{border-left-width:6px}
.mu.px .muMenu{padding:4px} .mu.px .muMenu button{padding:7px 12px;border-left:3px solid transparent} .mu.px .muMenu button:hover:not(:disabled){background:color-mix(in srgb,var(--macc) 24%,var(--mcard2));color:var(--mtext);border-left-color:var(--macc)}
.mu.px .muMode{border:2px solid transparent;box-shadow:0 3px 0 rgba(0,0,0,.35)} .mu.px .muMode:hover{border-color:var(--macc)}
/* secondary windows: borderless, title bar with accent strip, top-left like MuPlayer's, draggable */
.muLayer{position:absolute;inset:0;pointer-events:none;z-index:20}
.muWin{position:absolute;left:0;top:38px;max-width:100%;max-height:calc(100% - 38px);display:flex;flex-direction:column;background:var(--mcard);border:1px solid var(--mborder);box-shadow:6px 6px 0 rgba(0,0,0,.35);pointer-events:auto;animation:muReveal .18s ease-out}
.muWinBar{height:34px;flex:none;display:flex;align-items:center;background:var(--mside);cursor:move}
.muWinBar i{width:4px;align-self:stretch;background:var(--macc)} .muWinBar b{flex:1;padding:0 12px;color:var(--mwarn);font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.muWinBar button,.muDlgBar button{width:42px;align-self:stretch;display:grid;place-items:center;color:var(--mdanger);font-weight:bold;font-size:14px}
.muWinBar button:hover,.muDlgBar button:hover{background:var(--mdanger);color:var(--mtext)}
.muWinBody{overflow-y:auto;padding:4px 30px 22px;user-select:text}
.muWHx{display:none} .muWH{margin:20px 0 8px;color:var(--macc);font-weight:bold;font-size:17px}
.muWHead{display:flex;align-items:baseline;justify-content:space-between;gap:12px} .muWHead>span{color:var(--msub);font-size:14px}
.muWSec{margin:22px 0 8px;color:var(--macc2);font-weight:bold;font-size:14px;letter-spacing:.3px}
.muWNote{margin:4px 0;color:var(--msub);font-size:14px;line-height:1.45} .muWNote.ind{padding-left:24px}
.muWEnd{display:flex;justify-content:flex-end;gap:10px;margin-top:24px}
.muWBtns{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:10px 0}
.muWBtns>span{color:var(--msub);font-size:14px}
.muRows{display:flex;flex-direction:column;gap:6px;margin-top:8px}
.muWRow{display:flex;align-items:center;gap:12px;padding:8px 10px;background:var(--mcard2)}
.muWRow>div{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.muWRow b{font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .muWRow span{color:var(--msub);font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

.muWThumb{width:72px;height:40px;object-fit:cover;flex:none;border:1px solid var(--mborder)}
.muWin label.muCheck{display:flex;align-items:flex-start;gap:10px;margin:7px 0;cursor:var(--cp,pointer);font-size:14px;line-height:1.4}
.muWin label.muCheck input{accent-color:var(--macc);margin:1px 0 0;width:14px;height:14px;flex:none;cursor:inherit}
.muArtRow input[type=checkbox]{-webkit-appearance:none;appearance:none;margin:1px 0 0;width:16px;height:16px;flex:none;cursor:var(--cp,pointer);background:var(--mbg);border:2px solid var(--mborder);display:grid;place-items:center;transition:background .12s,border-color .12s,box-shadow .12s}
.muArtRow input[type=checkbox]:hover{border-color:var(--macc)}
.muArtRow input[type=checkbox]:checked{background:var(--macc);border-color:var(--macc);box-shadow:0 0 8px color-mix(in srgb,var(--macc) 60%,transparent)}
.muArtRow input[type=checkbox]:checked::after{content:"";width:8px;height:4px;border-left:3px solid var(--mbg);border-bottom:3px solid var(--mbg);transform:translateY(-1px) rotate(-45deg)}
.muArtHead .ph{width:72px;height:72px;flex:none;border-radius:50%;object-fit:cover;border:3px solid var(--macc);box-shadow:0 0 0 3px var(--mcard),0 0 18px color-mix(in srgb,var(--macc) 45%,transparent)}
.muArtHead .ic{width:72px;height:72px;font-size:30px}
.muRadios{display:flex;flex-wrap:wrap;gap:4px 18px;padding-left:24px}
.muBands{display:flex;justify-content:space-between;gap:6px;padding:12px 10px;background:var(--mcard2);margin:8px 0}
.muBand{display:flex;flex-direction:column;align-items:center;gap:6px;flex:1}
.muBand span{color:var(--macc);font-size:12px;font-weight:bold} .muBand b{color:var(--msub);font-size:12px}
.muBand input{writing-mode:vertical-lr;direction:rtl;width:18px;height:120px;accent-color:var(--macc);cursor:var(--cp,pointer)}
.muOpt{display:grid;grid-template-columns:140px 1fr;gap:24px;align-items:start}
.muOptNav{position:sticky;top:0;display:flex;flex-direction:column;gap:6px;padding-top:18px}
.muOptTab{text-align:left;padding:10px 12px;background:var(--mcard2);color:var(--msub);font:inherit;font-size:14px;font-weight:bold;border:0;border-left:3px solid transparent;cursor:var(--cp,pointer);transition:color .12s,background .12s}
.muOptTab:hover{color:var(--mtext)} .muOptTab.on{color:var(--mtext);border-left-color:var(--macc);background:color-mix(in srgb,var(--macc) 20%,var(--mcard2))}
.muOptPane>.muWSec:first-child,.muOptPane>div:first-child>.muWSec:first-child{margin-top:14px}
.muWin label.muCheck small{display:block;color:var(--msub);font-size:12px;margin-top:1px}
.muSoon{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:6px;margin:10px 0}
.muSoon div{display:flex;gap:10px;align-items:center;padding:7px 10px;background:var(--mcard2);color:var(--msub);font-size:13px} .muSoon b{color:var(--mwarn);flex:none;min-width:52px}
.muTh .pv{position:relative} .muTh .pv .dk{position:absolute;right:8px;bottom:8px;width:12px;height:12px;border-radius:50%}
.muTh .lk{position:absolute;inset:0;display:grid;place-items:center;background:rgba(0,0,0,.5);color:#fff} .muTh .nm em{font-style:normal;font-weight:400;font-size:12px;opacity:.85}
.muWinBody{container-type:inline-size}
@container (max-width:560px){.muOpt{grid-template-columns:1fr}.muOptNav{position:static;flex-direction:row;flex-wrap:wrap}}
.muEmpty{display:flex;flex-direction:column;align-items:center;gap:8px;padding:56px 20px;text-align:center;color:var(--msub);font-size:14px} .muEmpty b{color:var(--mtext);font-size:16px} .muEmpty .muWBtns{justify-content:center}
.muThemes{display:grid;grid-template-columns:repeat(auto-fill,minmax(132px,1fr));gap:10px}
.muTh{display:flex;flex-direction:column;gap:0;padding:0;border:2px solid transparent;background:none;cursor:pointer;font:inherit;text-align:left;overflow:hidden;transition:transform .12s,border-color .12s}
.muTh:hover{transform:translateY(-2px)} .muTh.on{transform:translateY(-1px)}
.muTh .pv{display:grid;grid-template-columns:22% 1fr;height:58px} .muTh .pv i{display:block} .muTh .pv .sd{display:flex;flex-direction:column;gap:5px;padding:7px 5px} .muTh .pv .sd u{display:block;height:4px;border-radius:2px;opacity:.7}
.muTh .pv .mn{display:flex;flex-direction:column;gap:5px;padding:7px} .muTh .pv .mn u{display:block;height:9px} .muTh .pv .mn s{display:block;height:4px;width:60%} .muTh .pv .mn em{display:block;height:5px;width:35%;margin-top:auto}
.muTh .nm{display:flex;justify-content:space-between;align-items:center;gap:6px;padding:6px 8px;font-size:13px;font-weight:600} .muTh .nm span{display:flex;gap:3px} .muTh .nm span u{display:block;width:8px;height:8px;border-radius:50%}
.muTh.locked{opacity:.75;cursor:default}
.muArtHead{display:flex;align-items:center;gap:14px;padding:14px 16px;margin-bottom:10px;background:linear-gradient(135deg,var(--mcard2),var(--mcard));border-left:4px solid var(--macc)}
.muArtHead .ic{width:46px;height:46px;border-radius:50%;display:grid;place-items:center;background:var(--macc);color:var(--mbg);font-size:22px;font-weight:800;flex:none}
.muArtHead b{display:block;font-size:19px} .muArtHead span{color:var(--msub);font-size:14px}
.muArtTools{display:flex;gap:8px;margin-bottom:8px} .muArtFilter{flex:1;padding:9px 12px;background:var(--mcard2);border:1px solid var(--mborder);color:var(--mtext);font:inherit;outline:none} .muArtFilter:focus{border-color:var(--macc)}
.muArtList{display:flex;flex-direction:column;max-height:46vh;overflow-y:auto;border:1px solid var(--mborder)}
.muArtRow{display:grid;grid-template-columns:30px 22px 1fr auto;align-items:center;gap:10px;padding:8px 12px;cursor:pointer;border-bottom:1px solid color-mix(in srgb,var(--mborder) 40%,transparent)}
.muArtRow:nth-child(even){background:color-mix(in srgb,var(--mcard2) 55%,transparent)} .muArtRow:hover{background:color-mix(in srgb,var(--macc) 14%,var(--mcard2))} .muArtRow.on{background:color-mix(in srgb,var(--macc) 22%,var(--mcard2))}
.muArtRow .n{color:var(--msub);font-size:13px;text-align:right}  .muArtRow div{min-width:0} .muArtRow b{display:block;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .muArtRow small{color:var(--msub);font-size:13px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .muArtRow .d{color:var(--msub);font-size:14px;font-variant-numeric:tabular-nums}
.muSwatch{padding:8px 14px;border:2px solid transparent;font-weight:bold;font-size:14px}
.muSwatch:hover{filter:brightness(1.2)} .muSwatch.locked{display:flex;align-items:center;gap:8px;background:var(--mcard2);color:var(--msub)}
.muKeyRow{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:3px 0;font-size:14px}
.muKey{width:220px;flex:none;background:var(--mcard2);color:var(--macc);border:0;padding:6px 8px;text-align:center;font-size:14px;outline:none;cursor:var(--cp,pointer)}
.muKey:focus{outline:1px solid var(--macc);color:var(--mwarn)}
.muLevel{height:10px;background:var(--mcard2);margin:6px 0} .muLevel i{display:block;height:100%;background:linear-gradient(90deg,var(--macc),var(--macc2))}
.muStats{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;margin-bottom:10px}
.muStat{background:var(--mcard2);padding:12px 14px;display:flex;flex-direction:column;gap:4px}
.muStat b{font-size:20px} .muStat span{color:var(--msub);font-size:13px}
.muChart{display:flex;align-items:flex-end;gap:6px;height:112px;padding:8px 10px 0;background:var(--mcard2)}
.muChart>div{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:4px;height:100%}
.muChart i{display:block;width:100%;max-width:26px} .muChart span{color:var(--msub);font-size:12px;padding-bottom:4px}
.muBarRow{display:grid;grid-template-columns:28px 1fr auto;align-items:center;gap:10px;margin:7px 0;font-size:14px}
.muBarRow>b{color:var(--msub)} .muBarRow>div{min-width:0;display:flex;flex-direction:column;gap:4px}
.muBarRow span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.muBarRow>div>i{display:block;height:6px;background:var(--mcard2)} .muBarRow>div>i>i{display:block;height:100%}
.muBarRow em{font-style:normal;color:var(--macc2);font-size:13px;font-weight:bold}
.muRecent{display:flex;justify-content:space-between;gap:12px;padding:7px 0;border-bottom:1px solid var(--mcard2);font-size:14px}
.muRecent span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .muRecent em{font-style:normal;color:var(--msub);flex:none}
.muRecent.total{border:0;font-weight:bold} .muRecent.total em{color:var(--macc)}
.muAchCount{color:var(--macc2);font-size:16px}
.muAch{display:flex;align-items:center;gap:16px;margin:6px 0;padding:10px 14px;background:var(--mcard2);border-left:3px solid var(--mborder)}
.muAch.on{border-left-color:var(--macc)}
.muAch>b{width:190px;flex:none;color:var(--macc);font-size:15px} .muAch .muLock{width:190px;flex:none;color:var(--msub);display:flex}
.muAch p{margin:0;font-size:14px} .muAch:not(.on) p{color:var(--msub)} .muAch em{font-style:normal;color:var(--msub);font-size:13px}
.muTrashList{display:flex;flex-direction:column;gap:3px;max-height:380px;overflow-y:auto;margin:8px 0}
.muTrashList button{padding:8px 10px;background:var(--mcard2);font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.muTrashList button:hover{background:color-mix(in srgb,var(--macc) 24%,var(--mcard2))} .muTrashList button.on{background:var(--macc);color:#06110C}
div.muCheck{margin:12px 0;padding:10px 14px;background:var(--mcard2)} div.muCheck b{font-size:15px}
div.muCheck pre,.muLogs{margin:6px 0 0;white-space:pre-wrap;word-break:break-word;font:13px/1.5 Consolas,monospace;color:var(--msub)}
.muLogs{background:var(--mbg);padding:12px;max-height:420px;overflow-y:auto}
.muImpStatus{display:block;margin-top:12px;font-size:15px;color:var(--mtext)}
.muImpBar{height:6px;background:var(--mcard2);margin:12px 0 4px} .muImpBar i{display:block;height:100%;width:0;background:var(--macc2);transition:width .25s}
/* small modal dialogs (ModernDialog / NotifyDialog / mode) */
.muShade{position:absolute;inset:0;z-index:40;background:rgba(3,4,10,.55);display:grid;place-items:center}
.muDlg{width:440px;max-width:calc(100% - 32px);background:var(--mbg);box-shadow:8px 8px 0 rgba(0,0,0,.4);animation:muReveal .15s ease-out}
.muDlgBar{height:34px;display:flex;align-items:center;background:var(--mcard2)}
.muDlgBar b{flex:1;padding:0 12px;color:var(--macc);font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.muDlgCard{margin:6px;padding:18px 22px;background:var(--mcard);border:1px solid var(--macc);border-radius:18px;display:flex;flex-direction:column;gap:6px}
.muDlgTitle{font-size:17px} .muDlgTitle.small{font-size:15px;margin-bottom:6px}
.muDlgCard p{margin:0 0 6px;color:var(--msub);font-size:15px;line-height:1.4}
.muDlgIn{background:var(--mbg);color:var(--mtext);border:0;padding:8px 10px;font-size:15px;outline:none;caret-color:var(--macc);width:100%}
.muDlgIn:focus{outline:1px solid var(--macc)}
.muDlgBtns{display:flex;justify-content:flex-end;gap:10px;margin-top:12px}
.muDlgMsg{margin:0;white-space:pre-wrap;word-break:break-word;font:15px/1.5 Consolas,monospace;color:var(--mtext);max-height:50vh;overflow:auto;user-select:text}
.muMode{display:flex;flex-direction:column;gap:4px;padding:12px 14px;background:var(--mcard2);margin-top:4px}
.muMode b{color:var(--macc);font-size:15px} .muMode.alt b{color:var(--macc2)} .muMode span{color:var(--msub);font-size:14px;line-height:1.4;white-space:normal}
.muMode:hover{background:color-mix(in srgb,var(--macc) 24%,var(--mcard2))}
/* buttons: soft relief (light top edge, dark base), rounded, a glow of the accent on hover, pressed on click */
.muBtn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:8px 14px;border-radius:7px;letter-spacing:.4px;
  background:linear-gradient(180deg,color-mix(in srgb,var(--mcard2) 88%,#fff),var(--mcard2));border:1px solid color-mix(in srgb,var(--mborder) 75%,transparent);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.07),0 2px 0 rgba(0,0,0,.35);transition:background .14s,border-color .14s,box-shadow .14s,transform .08s,color .14s}
.muBtn:hover,.muCard .muBtn:hover,.muWRow .muBtn:hover{background:linear-gradient(180deg,color-mix(in srgb,var(--mcard2) 80%,#fff),color-mix(in srgb,var(--mcard2) 92%,#fff));border-color:var(--macc);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 2px 0 rgba(0,0,0,.35),0 0 0 3px color-mix(in srgb,var(--macc) 20%,transparent)}
.muBtn:active:not(:disabled){transform:translateY(2px);box-shadow:inset 0 2px 4px rgba(0,0,0,.35);background:var(--mpress)}
.muBtn.accent{background:linear-gradient(180deg,color-mix(in srgb,var(--macc) 26%,var(--mcard2)),color-mix(in srgb,var(--macc) 14%,var(--mcard2)));border-color:color-mix(in srgb,var(--macc) 55%,transparent)}
.muBtn.accent:hover{background:linear-gradient(180deg,color-mix(in srgb,var(--macc) 85%,#fff),var(--macc));color:#06110C;border-color:var(--macc)}
.muBtn.danger{background:linear-gradient(180deg,color-mix(in srgb,var(--mdanger) 22%,var(--mcard2)),color-mix(in srgb,var(--mdanger) 12%,var(--mcard2)));border-color:color-mix(in srgb,var(--mdanger) 50%,transparent)}
.muBtn.danger:hover{background:linear-gradient(180deg,color-mix(in srgb,var(--mdanger) 85%,#fff),var(--mdanger));color:#2A0A0E;border-color:var(--mdanger);box-shadow:0 2px 0 rgba(0,0,0,.35),0 0 0 3px color-mix(in srgb,var(--mdanger) 22%,transparent)}
.muPill{border-radius:7px;padding:8px 4px;letter-spacing:.3px;background:color-mix(in srgb,var(--macc2) 12%,var(--mcard2));border:1px solid color-mix(in srgb,var(--macc2) 40%,transparent);box-shadow:0 2px 0 rgba(0,0,0,.3);transition:background .14s,color .14s,transform .08s}
.muPill.danger{background:color-mix(in srgb,var(--mdanger) 12%,var(--mcard2));border-color:color-mix(in srgb,var(--mdanger) 40%,transparent)}
.muPill:hover{background:var(--macc2);color:#06110C} .muPill.danger:hover{background:var(--mdanger);color:#2A0A0E} .muPill:active{transform:translateY(2px);box-shadow:none}
.muSideBtn{border-radius:7px;transition:background .12s,color .12s,box-shadow .12s}
.muSideBtn:hover{box-shadow:inset 3px 0 0 var(--macc)} .muSideBtn svg{transition:transform .15s} .muSideBtn:hover svg{transform:scale(1.15);color:var(--macc)}
.muPlBtn{border-radius:0 7px 7px 0;transition:background .12s,color .12s}
.muPlay svg{filter:drop-shadow(0 0 8px color-mix(in srgb,var(--macc) 45%,transparent));transition:filter .15s,transform .1s}
.muPlay:hover svg{filter:drop-shadow(0 0 14px color-mix(in srgb,var(--macc2) 60%,transparent));transform:scale(1.05)} .muPlay:active svg{transform:scale(.95)}
.muSkip svg{transition:transform .1s} .muSkip:active svg{transform:scale(.9)}
.muRowDur{flex:none;align-self:center;min-width:44px;text-align:right;margin-left:8px;font-variant-numeric:tabular-nums} .muRowFav,.muRowDel{border-radius:50%;width:30px;height:30px;padding:0;display:grid;place-items:center}
.mu.px .muRowFav,.mu.px .muRowDel{border-radius:0;width:32px;height:30px;background:var(--mcard2);box-shadow:inset 0 2px 0 rgba(255,255,255,.08);margin:0 4px 0 6px} .mu.px .muRowFav:hover,.mu.px .muRowDel:hover{background:color-mix(in srgb,var(--macc) 24%,var(--mcard2))} .mu.px .muRowFav:active,.mu.px .muRowDel:active{transform:translateY(2px);box-shadow:none} .mu.px .muRowFav{color:var(--mborder)} .mu.px .muRowFav.on{color:var(--mheart)} .mu.px .muRowDel:hover{color:var(--mdanger)} .muRowFav:hover,.muRowDel:hover{background:var(--mcard2)}
.muTopBtn{border-radius:6px;margin:5px 6px 5px auto;width:36px}
.muSelect,.muFilter,.muKey,.muDlgIn{border-radius:6px;border:1px solid color-mix(in srgb,var(--mborder) 60%,transparent);transition:border-color .12s}
.muSelect:hover,.muFilter:hover,.muKey:hover{border-color:var(--mborder)}
.muFilter:focus,.muKey:focus,.muDlgIn:focus{outline:0;border-color:var(--macc);box-shadow:0 0 0 3px color-mix(in srgb,var(--macc) 18%,transparent)}
.muSwatch{border-radius:7px;box-shadow:0 2px 0 rgba(0,0,0,.35);transition:transform .1s,filter .12s} .muSwatch:hover{transform:translateY(-1px)}
.muMode{border-radius:9px;border:1px solid transparent;transition:border-color .12s,background .12s} .muMode:hover{border-color:var(--macc)} .muMode.alt:hover{border-color:var(--macc2)}
.muTrashList button{border-radius:6px} .muMenu{border-radius:8px} .muMenu button{border-radius:5px}
.muWinBar button,.muDlgBar button{transition:background .12s,color .12s}
@media (max-width:900px){.muNowSide{display:none}.muSide{width:200px}}
/* 3.3.3 : chaque thème a son décor (fond, cartes, bordures, boutons), comme les thèmes NeoDex ; en Deluxe, le fond et les titres du thème sur le style pixel (3.3.5) */
.mu:not(.lux)[data-ms] .muCard{transition:box-shadow .2s}
.mu[data-ms=nova]{background:radial-gradient(circle,#ffffff12 0 1px,transparent 1.5px) 0 0/48px 48px,var(--mbg)}
.mu:not(.lux)[data-ms=nova] .muCard{border-radius:4px;border-color:color-mix(in srgb,var(--macc) 35%,var(--mborder))}
.mu[data-ms=onyx]{background:linear-gradient(90deg,#ffffff07 1px,transparent 1px) 0 0/40px 40px,linear-gradient(#ffffff07 1px,transparent 1px) 0 0/40px 40px,var(--mbg)}
.mu:not(.lux)[data-ms=onyx] .muCard{border:0;border-left:4px solid var(--macc);border-radius:0;box-shadow:6px 6px 0 #000}
.mu[data-ms=onyx] :is(.muHead,.muBtn){text-transform:uppercase;letter-spacing:2px} .mu:not(.lux)[data-ms=onyx] .muBtn{border-radius:0}
.mu[data-ms=grenat]{background:linear-gradient(160deg,color-mix(in srgb,var(--macc) 10%,var(--mbg)),var(--mbg) 55%)}
.mu:not(.lux)[data-ms=grenat] .muCard{border-radius:10px;background:color-mix(in srgb,var(--mcard) 78%,transparent);border-color:#ffffff1c;box-shadow:inset 0 1px 0 #ffffff14,0 10px 30px #0006}
.mu:not(.lux)[data-ms=grenat] .muSide{background:color-mix(in srgb,var(--mside) 80%,transparent);border-right:1px solid #ffffff12}
.mu[data-ms=aube]{background:linear-gradient(180deg,var(--mbg) 30%,color-mix(in srgb,var(--macc) 22%,var(--mbg)) 100%)}
.mu:not(.lux)[data-ms=aube] .muCard{border-radius:18px;border:0;box-shadow:0 8px 28px #0005,inset 0 1px 0 color-mix(in srgb,var(--macc) 30%,transparent)}
.mu:not(.lux)[data-ms=aube] .muBtn{border-radius:999px}
.mu[data-ms=ambre]{background:repeating-linear-gradient(45deg,transparent 0 22px,color-mix(in srgb,var(--macc) 6%,transparent) 22px 24px),var(--mbg)}
.mu:not(.lux)[data-ms=ambre] .muCard{border-radius:0;border:1px solid var(--macc);outline:1px solid color-mix(in srgb,var(--macc) 45%,transparent);outline-offset:3px;margin:4px}
.mu:not(.lux)[data-ms=ambre] .muTop{background:repeating-linear-gradient(90deg,var(--mside) 0 14px,color-mix(in srgb,var(--macc) 12%,var(--mside)) 14px 16px)}
.mu[data-ms=ambre] :is(.muTitle,.muHead){font-family:Georgia,'Times New Roman',serif;letter-spacing:1px}
.mu[data-ms=abyme]{background:linear-gradient(180deg,var(--mbg),color-mix(in srgb,var(--mbg) 70%,#000)),var(--mbg)}
.mu:not(.lux)[data-ms=abyme] .muCard{border-radius:12px;border-color:color-mix(in srgb,var(--macc) 25%,transparent);box-shadow:0 0 0 1px #0006}
.mu[data-ms=sakura]{background:radial-gradient(circle at 15% 25%,color-mix(in srgb,var(--macc) 14%,transparent) 0 3px,transparent 4px) 0 0/90px 90px,radial-gradient(circle at 60% 70%,color-mix(in srgb,var(--mheart) 12%,transparent) 0 2px,transparent 3px) 0 0/130px 130px,var(--mbg)}
.mu:not(.lux)[data-ms=sakura] .muCard{border-radius:20px;border:2px dashed color-mix(in srgb,var(--macc) 40%,transparent)}
.mu:not(.lux)[data-ms=sakura] .muBtn{border-radius:14px}
.mu[data-ms=crepuscule]{background:linear-gradient(180deg,var(--mbg) 0 40%,color-mix(in srgb,var(--macc2) 12%,var(--mbg)) 40% 60%,color-mix(in srgb,var(--macc) 18%,var(--mbg)) 60% 80%,color-mix(in srgb,var(--mdanger) 18%,var(--mbg)) 80%)}
.mu:not(.lux)[data-ms=crepuscule] .muCard{border-radius:12px;border:0;border-bottom:3px solid var(--macc2);box-shadow:0 6px 20px #0006}
.mu[data-ms=menthe]{background:repeating-linear-gradient(-45deg,transparent 0 10px,color-mix(in srgb,var(--macc) 5%,transparent) 10px 11px),var(--mbg)}
.mu:not(.lux)[data-ms=menthe] .muCard{border-radius:16px;border-color:color-mix(in srgb,var(--macc) 30%,transparent)}
.mu:not(.lux)[data-ms=menthe] .muBtn{border-radius:999px} .mu:not(.lux)[data-ms=menthe] .muRow{border-radius:10px}
.mu[data-ms=rubis]{background:conic-gradient(from 45deg at 50% 50%,color-mix(in srgb,var(--macc) 7%,transparent) 25%,transparent 0 50%,color-mix(in srgb,var(--macc) 7%,transparent) 0 75%,transparent 0) 0 0/60px 60px,var(--mbg)}
.mu:not(.lux)[data-ms=rubis] .muCard{border:0;border-radius:0;clip-path:polygon(14px 0,calc(100% - 14px) 0,100% 14px,100% calc(100% - 14px),calc(100% - 14px) 100%,14px 100%,0 calc(100% - 14px),0 14px);background:linear-gradient(135deg,color-mix(in srgb,var(--macc) 14%,var(--mcard)),var(--mcard) 45%)}
.mu:not(.lux)[data-ms=rubis] .muBtn{clip-path:polygon(8px 0,100% 0,calc(100% - 8px) 100%,0 100%);border-radius:0}
.mu[data-ms=glacier]{background:radial-gradient(circle,#fff6 0 1px,transparent 1.5px) 0 0/34px 34px,var(--mbg)}
.mu:not(.lux)[data-ms=glacier] .muCard{border-radius:12px;background:color-mix(in srgb,var(--mcard) 70%,transparent);border:1px solid #ffffff30}
.mu[data-ms=cuivre]{background:repeating-linear-gradient(90deg,#ffffff04 0 1px,transparent 1px 3px),var(--mbg)}
.mu:not(.lux)[data-ms=cuivre] .muCard{border-radius:6px;border:2px solid color-mix(in srgb,var(--macc) 55%,#000);background:radial-gradient(circle at 10px 10px,var(--macc) 0 2.5px,transparent 3.5px),radial-gradient(circle at calc(100% - 10px) 10px,var(--macc) 0 2.5px,transparent 3.5px),linear-gradient(180deg,color-mix(in srgb,var(--macc) 10%,var(--mcard)),var(--mcard));box-shadow:inset 0 1px 0 #fff2,inset 0 -2px 0 #0006}
.mu:not(.lux)[data-ms=cuivre] .muBtn{background:linear-gradient(180deg,color-mix(in srgb,var(--macc) 45%,var(--mcard2)),color-mix(in srgb,var(--macc) 15%,var(--mcard2)));border-radius:4px}
.mu[data-ms=lavande]{background:radial-gradient(60% 50% at 20% 20%,color-mix(in srgb,var(--macc) 14%,transparent),transparent),radial-gradient(60% 50% at 80% 90%,color-mix(in srgb,var(--macc2) 12%,transparent),transparent),var(--mbg)}
.mu:not(.lux)[data-ms=lavande] .muCard{border-radius:22px;border:2px dotted color-mix(in srgb,var(--macc) 45%,transparent);box-shadow:0 14px 40px #0005}
.mu:not(.lux)[data-ms=lavande] .muBtn{border-radius:12px}
.mu[data-ms=foret]{background:radial-gradient(ellipse 18px 9px at 50% 50%,color-mix(in srgb,var(--macc) 9%,transparent) 60%,transparent 62%) 0 0/70px 50px,radial-gradient(ellipse 12px 6px at 50% 50%,color-mix(in srgb,var(--macc2) 8%,transparent) 60%,transparent 62%) 35px 25px/70px 50px,var(--mbg)}
.mu:not(.lux)[data-ms=foret] .muCard{border-radius:4px 22px 4px 22px;border:0;border-left:5px solid var(--macc)}
.mu[data-ms=ocean]{background:repeating-radial-gradient(circle at 50% 120%,transparent 0 26px,color-mix(in srgb,var(--macc) 7%,transparent) 26px 28px),var(--mbg)}
.mu:not(.lux)[data-ms=ocean] .muCard{border-radius:16px;border:0;border-top:3px solid var(--macc);box-shadow:0 10px 26px #0007}
.mu:not(.lux)[data-ms=ocean] .muBtn{border-radius:999px}
.mu[data-ms=soleil]{background:repeating-conic-gradient(from 0deg at 100% 0%,color-mix(in srgb,var(--macc) 6%,transparent) 0 4deg,transparent 4deg 12deg),var(--mbg)}
.mu:not(.lux)[data-ms=soleil] .muCard{border-radius:10px;border-color:color-mix(in srgb,var(--macc) 40%,transparent)}
.mu[data-ms=cyber]{background:linear-gradient(color-mix(in srgb,var(--macc) 14%,transparent) 1px,transparent 1px) 0 0/100% 28px,linear-gradient(90deg,color-mix(in srgb,var(--macc2) 10%,transparent) 1px,transparent 1px) 0 0/28px 100%,var(--mbg)}
.mu:not(.lux)[data-ms=cyber] .muCard{border-radius:0;border:1px solid var(--macc);clip-path:polygon(0 0,calc(100% - 18px) 0,100% 18px,100% 100%,18px 100%,0 calc(100% - 18px))}
.mu[data-ms=cyber] :is(.muHead,.muBtn,.muTitle){text-transform:uppercase;letter-spacing:2px} .mu:not(.lux)[data-ms=cyber] .muBtn{border-radius:0}
.mu[data-ms=neon]{background:var(--mbg)}
.mu:not(.lux)[data-ms=neon] .muCard{border-radius:0;border:2px solid var(--macc);box-shadow:3px 3px 0 color-mix(in srgb,var(--macc2) 55%,transparent)}
.mu[data-ms=neon] .muTitle{color:var(--macc)}
.mu:not(.lux)[data-ms=neon] .muBtn{border-radius:0}
`;
export default async function (ctx) {
  const view = ctx.view;
  // le côté système de NeoMusic (yt-dlp, fichiers, raccourcis globaux) vit dans le main.js du plugin : « neo.musicXxx » y est redirigé
  const MU_ID = 'neodex.music', MU_EV = { onMusicHotkey: 'music:hotkey', onMusicProgress: 'music:progress' };
  const MU_DOC = cb => ctx.neo.onPluginDataChanged(e => { if (e.id === MU_ID && e.name === 'library') cb('music'); });  // un autre PC a changé la bibliothèque
  const neo = new Proxy({}, { get: (_, k) => { const n = ctx.neo;  // cible vide : contextBridge fige les propriétés de neo
    if (typeof k !== 'string') return n[k];
    if (k === 'onDataChanged') return cb => { n.onDataChanged?.(cb); MU_DOC(cb); };
    if (MU_EV[k]) return cb => n.onPluginMain(e => { if (e.id === MU_ID && e.name === MU_EV[k]) cb(e.data); });
    const m = /^music([A-Z]\w*)$/.exec(k);
    return m ? (...a) => n.pluginMain(MU_ID, 'music:' + m[1][0].toLowerCase() + m[1].slice(1), ...a) : n[k];
  } });
  if (!ctx.host) { view.textContent = "Ce plugin doit être approuvé par NeoDex pour s'ouvrir."; return; }
  const { el, toast, sfx, ask, newTab, pixIcon, PIX, WX } = ctx.host;
  const host = ctx.host;
  const folder = ctx.folder, legacy = ctx.legacy || {};
  if (!document.getElementById('muStyle')) { const st = document.createElement('style'); st.id = 'muStyle'; st.textContent = MU_CSS; document.head.append(st); }  // le style de NeoMusic vit dans le plugin
  view.innerHTML = HTML;
  const $ = id => id === "musicApp" ? view : (view.querySelector('#' + id) || document.getElementById(id));  // les identifiants de ta vue, sans toucher à ceux du reste de NeoDex
  const doc = async n => { try { return await folder.read(n); } catch { return null; } };
  const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  // ---- ton code d'origine ----
  /* NeoMusic: MuPlayer (NDesumeur) rebuilt inside NeoDex. Same layout, themes, vinyl, spectrum, waveform, playlists online / offline,
     imports, recommendations, stats, achievements, levels. The whole library lives in music.json (synced between PCs and in the backups);
     music files and covers are a cache on each PC (music-main.js), fetched again from their URL when a PC does not have them. Part 2: music2.js. */

  const MU_THEMES = {
    'Nova': {BG: '#101425', SIDEBAR: '#171B2E', CARD: '#202642', CARD_ALT: '#2B3154', BORDER: '#59658F', TEXT: '#F7F1FF', SUBTEXT: '#A6ADD1', ACCENT: '#C084FC', ACCENT_2: '#7DE2D1', DANGER: '#FF78A8', WARN: '#FFD166', HEART: '#FF8BD4'},
    'Onyx': {BG: '#0A0A0C', SIDEBAR: '#121214', CARD: '#1B1B1F', CARD_ALT: '#26262C', BORDER: '#4A4A54', TEXT: '#F5F5F7', SUBTEXT: '#9A9AA4', ACCENT: '#39FF88', ACCENT_2: '#FF3EA5', DANGER: '#FF4D4D', WARN: '#FFD166', HEART: '#FF6FA8'},
    'Grenat': {BG: '#14161C', SIDEBAR: '#1A1D24', CARD: '#20232C', CARD_ALT: '#2A2E38', BORDER: '#454A56', TEXT: '#F0F1F3', SUBTEXT: '#9CA1AD', ACCENT: '#6FA8FF', ACCENT_2: '#A9C6FF', DANGER: '#FF6B6B', WARN: '#FFD166', HEART: '#8FB8FF'},
    'Aube': {BG: '#0B1130', SIDEBAR: '#111A42', CARD: '#182458', CARD_ALT: '#22317A', BORDER: '#5A6FBE', TEXT: '#FFF6F0', SUBTEXT: '#B7C0EF', ACCENT: '#FF8B6B', ACCENT_2: '#FFD66B', DANGER: '#FF5C6C', WARN: '#FFD166', HEART: '#FFA6C0'},
    'Ambre': {BG: '#191310', SIDEBAR: '#211A15', CARD: '#2B221B', CARD_ALT: '#3A2F25', BORDER: '#6B5640', TEXT: '#F5ECE0', SUBTEXT: '#C2AB8F', ACCENT: '#E0A65C', ACCENT_2: '#4FBFAE', DANGER: '#E8756B', WARN: '#E0BE7F', HEART: '#FF9E7A'},
    'Abyme': {BG: '#030A12', SIDEBAR: '#061019', CARD: '#0B1A29', CARD_ALT: '#12283D', BORDER: '#1F5C7A', TEXT: '#E7FBFF', SUBTEXT: '#7FC4D9', ACCENT: '#29DDBF', ACCENT_2: '#FF8F6B', DANGER: '#FF5D7A', WARN: '#FFD166', HEART: '#FFA487'},
    'Sakura': {BG: '#1A0E1E', SIDEBAR: '#22132A', CARD: '#2E1A38', CARD_ALT: '#3F2249', BORDER: '#7A3E86', TEXT: '#FFF0F8', SUBTEXT: '#DCA9D0', ACCENT: '#FF6FC4', ACCENT_2: '#7FE0B0', DANGER: '#FF5477', WARN: '#FFD166', HEART: '#FFA0D6'},
    'Crépuscule': {BG: '#160B22', SIDEBAR: '#1F1030', CARD: '#2A1640', CARD_ALT: '#3A2058', BORDER: '#8A4A9A', TEXT: '#FFF1E6', SUBTEXT: '#D2A9C2', ACCENT: '#FF7A59', ACCENT_2: '#FFC857', DANGER: '#FF4D6D', WARN: '#FFC857', HEART: '#FF9EC0'},
    'Menthe': {BG: '#07161A', SIDEBAR: '#0C2126', CARD: '#122E34', CARD_ALT: '#1B4048', BORDER: '#2F7F80', TEXT: '#EAFFF8', SUBTEXT: '#8FD1C2', ACCENT: '#3DF2B5', ACCENT_2: '#7AD7FF', DANGER: '#FF6B7A', WARN: '#FFE07A', HEART: '#7DF0D0'},
    'Rubis': {BG: '#16060C', SIDEBAR: '#200A12', CARD: '#2E1019', CARD_ALT: '#421826', BORDER: '#96304A', TEXT: '#FFEFF2', SUBTEXT: '#D79AA8', ACCENT: '#FF3D63', ACCENT_2: '#FFB84D', DANGER: '#FF3D63', WARN: '#FFC857', HEART: '#FF7C98'},
    'Glacier': {BG: '#0A1420', SIDEBAR: '#101D2E', CARD: '#172A40', CARD_ALT: '#223C58', BORDER: '#5F8FB8', TEXT: '#F2FAFF', SUBTEXT: '#9DBBD6', ACCENT: '#7CD4FF', ACCENT_2: '#C8F1FF', DANGER: '#FF7B8A', WARN: '#FFE08A', HEART: '#A8E4FF'},
    'Cuivre': {BG: '#170D08', SIDEBAR: '#20130C', CARD: '#2D1B11', CARD_ALT: '#40271A', BORDER: '#9A5A34', TEXT: '#FFF0E4', SUBTEXT: '#CFA68A', ACCENT: '#E8793A', ACCENT_2: '#5FD3B8', DANGER: '#E5585A', WARN: '#F2C14E', HEART: '#FF9A6A'},
    'Lavande': {BG: '#13102A', SIDEBAR: '#1B1738', CARD: '#251F4A', CARD_ALT: '#352C66', BORDER: '#7E6FC8', TEXT: '#F5F1FF', SUBTEXT: '#B9B0E6', ACCENT: '#B79CFF', ACCENT_2: '#FFB3E6', DANGER: '#FF6F91', WARN: '#FFD98A', HEART: '#FFA8E0'},
    'Forêt': {BG: '#08140C', SIDEBAR: '#0E1E13', CARD: '#15291B', CARD_ALT: '#1F3B28', BORDER: '#3F8A55', TEXT: '#EEFBEF', SUBTEXT: '#98C9A2', ACCENT: '#6BE585', ACCENT_2: '#E6D36A', DANGER: '#F0645A', WARN: '#E6D36A', HEART: '#B5F08F'},
    'Océan': {BG: '#04101F', SIDEBAR: '#071A30', CARD: '#0B2642', CARD_ALT: '#123A5E', BORDER: '#2A78B5', TEXT: '#EAF6FF', SUBTEXT: '#8DB9DE', ACCENT: '#2BA8FF', ACCENT_2: '#2EE6C9', DANGER: '#FF6B81', WARN: '#FFD36B', HEART: '#6FD8FF'},
    'Soleil': {BG: '#1C1405', SIDEBAR: '#271C07', CARD: '#352709', CARD_ALT: '#4A360E', BORDER: '#B8861C', TEXT: '#FFF8E0', SUBTEXT: '#DCC27A', ACCENT: '#FFC93C', ACCENT_2: '#FF7A3C', DANGER: '#F25C54', WARN: '#FFD65A', HEART: '#FFB05A'},
    'Cyber': {BG: '#0C0C0F', SIDEBAR: '#131318', CARD: '#1C1C24', CARD_ALT: '#2A2A36', BORDER: '#FFE600', TEXT: '#F8F8F2', SUBTEXT: '#A6A6B8', ACCENT: '#FFE600', ACCENT_2: '#00F0FF', DANGER: '#FF2E63', WARN: '#FFE600', HEART: '#FF2E93'},
    'Néon': {BG: '#05010D', SIDEBAR: '#0B0316', CARD: '#140626', CARD_ALT: '#1E0A38', BORDER: '#4B3480', TEXT: '#F3ECFF', SUBTEXT: '#B39DDB', ACCENT: '#9C82F2', ACCENT_2: '#B8DE6E', DANGER: '#FF3B5C', WARN: '#FFD166', HEART: '#FF6FB8'},
  };
  // chaque thème a sa police, comme les styles de NeoDex (polices de NeoDex, fonts.css) ; « Police » dans les options en impose une autre
  const MU_FONTS = {classique: ['Classique', 'Consolas'], vt: ['Terminal', "'X VT323'"], pixel: ['Ronde', "'Pixelify Sans'"], jersey: ['Arcade', "'Jersey 10'"], dot: ['Grimoire', "'DotGothic16'"]};
  const MU_THEME_FONT = {Onyx: 'vt', Aube: 'pixel', Ambre: 'vt', Abyme: 'dot', Sakura: 'pixel', 'Crépuscule': 'pixel', Menthe: 'vt', Rubis: 'pixel', Glacier: 'pixel', Cuivre: 'vt', Lavande: 'dot', 'Forêt': 'dot', Soleil: 'pixel', Cyber: 'vt', 'Néon': 'vt'};  // Arcade (très serrée, minuscule en petit) n'est plus la police d'un thème, seulement un choix
  const muFont = (theme = mu.settings.theme) => (MU_FONTS[mu.settings.font] || MU_FONTS[MU_THEME_FONT[theme]] || MU_FONTS.classique)[1];
  const MU_THEME_LEVEL = {Onyx: 3, Grenat: 6, Aube: 10, Ambre: 16, Abyme: 24, Sakura: 35, 'Néon': 50};
  const MU_BANDS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  const MU_PRESETS = {
    'Normal': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 'Bass boost': [3, 5, 6, 3, 1, 0, 0, 0, 0, 0], 'Bass extreme': [4, 8, 7, 3, 1, 0, 0, 0, 0, 0], 'Treble': [0, 0, 0, 0, 0, 0, 1, 2, 5, 6],
    'Rock': [0, 2, 4, 1, -1, -2, 0, 3, 2, 0], 'Electronic': [3, 5, 3, 1, 0, 0, 0, 1, 4, 5], 'Vocal': [0, 0, 0, -2, -3, -1, 3, 2, 0, 0], 'Custom': null,
  };
  const MU_SYSTEM = ['Favoris', 'Radar des sorties', 'Découvertes de la semaine'];
  const MU_SHORTCUTS = [  // [setting, label, action, default]
    ['play', 'Lecture / pause', 'toggle', 'Ctrl+Alt+Space'], ['previous', 'Morceau précédent', 'prev', 'Ctrl+Alt+Left'], ['next', 'Morceau suivant', 'next', 'Ctrl+Alt+Right'],
    ['volumeUp', 'Volume +', 'volUp', 'Ctrl+Alt+Up'], ['volumeDown', 'Volume -', 'volDown', 'Ctrl+Alt+Down'], ['mute', 'Muet / rétablir le son', 'mute', 'Ctrl+Alt+M'],
    ['seekForward', 'Avancer de 10 s', 'fwd', 'Ctrl+Alt+Shift+Right'], ['seekBackward', 'Reculer de 10 s', 'back', 'Ctrl+Alt+Shift+Left'], ['shuffle', 'Lecture aléatoire', 'shuffle', 'Ctrl+Alt+S'],
    ['favorite', 'Favori (morceau en cours)', 'fav', 'Ctrl+Alt+F'], ['fullscreen', 'Plein écran', 'fullscreen', 'F11'], ['mini', 'Mode petit lecteur', 'mini', 'Ctrl+Alt+P'],
  ];
  const MU_ACHIEVEMENTS = [
    ['first_play', 'Premier pas', 'Écoute ta toute première musique.'], ['hundred_plays', 'Centurion', 'Écoute 100 morceaux au total (lectures cumulées).'],
    ['five_hundred_unique', '500 nuances de son', 'Écoute 500 morceaux différents.'], ['thousand_plays', 'Millénaire sonore', 'Atteins 1000 lectures au total.'],
    ['marathon', 'Marathonien', 'Cumule 24h de temps d\'écoute réel.'], ['full_week', 'Semaine complète', 'Cumule 168h (une semaine) de temps d\'écoute réel.'],
    ['insomniac', 'Insomniaque mélomane', 'Écoute une musique entre 2h et 5h du matin.'], ['streak_3', '3 jours d\'affilée', 'Écoute au moins une musique 3 jours de suite.'],
    ['streak_7', '7 jours d\'affilée', 'Écoute au moins une musique 7 jours de suite.'], ['streak_30', '30 jours d\'affilée', 'Écoute au moins une musique 30 jours de suite.'],
    ['streak_100', '100 jours d\'affilée', 'Écoute au moins une musique 100 jours de suite.'], ['weekend_warrior', 'Weekend warrior', 'Écoute de la musique chaque samedi et dimanche d\'un mois complet.'],
    ['explorer_50_artists', 'Explorateur', 'Découvre 50 artistes différents.'], ['fresh_out', 'Petit nouveau', 'Écoute un morceau ajouté à ta bibliothèque il y a moins de 24h.'],
    ['first_favorite', 'Coup de cœur', 'Ajoute ton tout premier favori.'], ['fifty_favorites', 'Grand collectionneur', 'Ajoute 50 favoris.'],
    ['loyal_fan', 'Fidèle', 'Écoute le même morceau 50 fois.'], ['obsession', 'Obsession', 'Écoute le même morceau 10 fois dans la même journée.'],
    ['architect', 'Architecte', 'Crée ta première playlist.'], ['dj_in_training', 'DJ en herbe', 'Crée 10 playlists.'], ['mega_playlist', 'Méga playlist', 'Construis une playlist de 100 morceaux ou plus.'],
    ['early_bird', 'Lève-tôt', 'Écoute une musique avant 7h du matin.'], ['night_owl', 'Oiseau de nuit', 'Écoute une musique après minuit.'],
    ['sunday_ritual', 'Rituel du dimanche', 'Écoute de la musique chaque dimanche d\'un mois complet.'], ['one_year', 'Un an ensemble', 'Utilise NeoMusic pendant 1 an depuis sa première utilisation.'],
    ['new_years_eve', 'Réveillon musical', 'Écoute de la musique un 31 décembre.'], ['christmas', 'Musique de Noël', 'Écoute de la musique un 25 décembre.'],
    ['customizer', 'Personnalisation', 'Change le thème de l\'application.'], ['hidden_font', 'Police cachée', 'Débloque la police bonus via le code Discord.'],
    ['shortcut_pro', 'Raccourcis pro', 'Utilise un raccourci clavier 10 fois.'], ['lucky', 'Chanceux', 'Retombe deux fois de suite sur le même morceau en lecture aléatoire.'],
    ['friday_13', 'Vendredi 13', 'Écoute de la musique un vendredi 13.'], ['palindrome', 'Palindrome', 'Écoute de la musique à une heure miroir (ex: 12:12, 21:21).'],
    ['grand_prince', 'Grand prince', 'Reviens après 30 jours d\'absence, ou écoute 30 jours d\'affilée.'],
  ];
  const MU_ROW = 58, MU_TILE_W = 152, MU_TILE_H = 196, MU_GAP = 10;

  /* ---------- helpers ---------- */
  function mh(sel, props, ...kids) {  // mh('div.a#b', {text, onclick, style, ...attrs}, children...)
    const m = /^([a-z0-9]*)(.*)$/i.exec(sel), e = document.createElement(m[1] || 'div');
    for (const x of m[2].matchAll(/([.#])([\w-]+)/g)) x[1] === '.' ? e.classList.add(x[2]) : e.id = x[2];
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
      else if (k === 'text') e.textContent = v; else if (k === 'html') e.innerHTML = v;
      else if (k.startsWith('on') || k === 'value' || k === 'checked' || k === 'disabled') e[k] = v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    e.append(...kids.flat().filter(k => k != null && k !== false));
    return e;
  }
  const muTime = s => { s = Math.max(0, Math.floor(+s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = String(s % 60).padStart(2, '0'); return h ? `${h}:${String(m).padStart(2, '0')}:${x}` : `${m}:${x}`; };
  const muClock = s => { s = Math.max(0, Math.floor(+s || 0)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };  // "00:00 / 03:45" like MuPlayer's progress
  const muParse = t => String(t || '').split(':').reduce((a, p) => a * 60 + (+p || 0), 0);
  const muId = t => t ? (t.url ? 'url:' + t.url : 'file:' + (t.file || '')) : '';
  const muDur = t => +t.duration || muParse(t.song_length);
  const muToday = (d = new Date()) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const muStamp = (d = new Date()) => muToday(d) + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  const muWeek = (d = new Date()) => { const y0 = new Date(d.getFullYear(), 0, 1), yday = Math.floor((d - y0) / 864e5), wd = (d.getDay() + 6) % 7; return d.getFullYear() + '-W' + String(Math.floor((yday + 7 - wd) / 7)).padStart(2, '0'); };  // Python's %Y-W%W
  // platine:début (recopié tel quel dans widget.js par tools/widget-sync.js)
  const muHex = h => [1, 3, 5].map(i => parseInt(h.substr(i, 2), 16));
  const muShade = (h, f) => '#' + muHex(h).map(c => Math.round(f >= 0 ? c + (255 - c) * f : c * (1 + f)).toString(16).padStart(2, '0')).join('');
  const muBlend = (a, b, k) => { const x = muHex(a), y = muHex(b); return '#' + x.map((c, i) => Math.round(c + (y[i] - c) * k).toString(16).padStart(2, '0')).join(''); };
  // platine:fin
  const muLog = [];
  const muWarn = (where, e) => { muLog.push(muStamp() + '  ' + where + ' : ' + (e?.message || e)); if (muLog.length > 300) muLog.shift(); };

  /* ---------- the library (music.json) ---------- */
  const MU_DEFAULT_SETTINGS = {theme: 'Nova', volume: .5, equalizer: 'Normal', eqBands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], limiter: false, balance: 0, visualizer: true, waveform: true, vinyl: true,
    replaygain: true, dateAdded: false, releaseDate: false, mini: false, gallery: false, noImages: false, weeklyWeek: '', superVis: false, deckLuxe: true, deckStyle: '', deckBase: '', deckArm: '', deluxe: false, recoSeen: [], pixelUi: true, shortcuts: {}};
  function muBlank() {
    return {v: 1, settings: {...MU_DEFAULT_SETTINGS}, playlists: MU_SYSTEM.map(name => ({name, mode: 'offline', tracks: []})),
      stats: {plays: 0, seconds: 0, songs: {}, songs_time: {}, artists: {}, artists_time: {}, daily: {}, history: [], xp_level_seen: 1},
      achievements: {unlocked: {}, progress: {unique_songs: [], unique_artists: [], streak_count: 0, last_active_date: null, first_seen_date: muToday(), obsession_date: null, obsession_counts: {},
        weekend_month: null, weekend_days: [], sunday_month: null, sunday_days: [], playlists_created: 0, shortcut_uses: 0, last_shuffle_identity: null}},
      trash: [], session: null};
  }
  function muRepair(d) {  // older or partial saves: every field exists, the 3 system playlists come first
    const b = muBlank();
    d = d && typeof d === 'object' ? d : b;
    d.settings = {...b.settings, ...d.settings}; d.settings.shortcuts ||= {};
    if (!Array.isArray(d.settings.eqBands) || d.settings.eqBands.length !== 10) d.settings.eqBands = [...b.settings.eqBands];
    d.playlists = Array.isArray(d.playlists) ? d.playlists.filter(p => p?.name) : [];
    for (const p of d.playlists) { p.tracks = Array.isArray(p.tracks) ? p.tracks.filter(t => t && (t.url || t.file)) : []; p.mode = p.mode === 'online' ? 'online' : 'offline'; }
    const sys = MU_SYSTEM.map(n => d.playlists.find(p => p.name.normalize('NFC').trim() === n) || {name: n, mode: 'offline', tracks: []});
    d.playlists = [...sys, ...d.playlists.filter(p => !MU_SYSTEM.includes(p.name.normalize('NFC').trim()))];
    d.stats = {...b.stats, ...d.stats}; d.achievements = {unlocked: {...d.achievements?.unlocked}, progress: {...b.achievements.progress, ...d.achievements?.progress}};
    d.trash = Array.isArray(d.trash) ? d.trash : [];
    return d;
  }
  let mu = null, muCache = {}, muSaveTimer = null, muCacheDirty = false, muLoaded = null;
  const muSave = (ms = 1200) => { clearTimeout(muSaveTimer); muSaveTimer = setTimeout(() => { muSaveTimer = null; neo.musicSave(mu).catch(e => muWarn('sauvegarde', e)); }, ms); };
  function muLoad() {
    return muLoaded ??= Promise.all([neo.musicLoad(), neo.musicCacheLoad()]).then(([d, c]) => {
      mu = muRepair(d); muCache = c || {};
      muHotkeys(); muCleanupTrash();
      setTimeout(muSyncFiles, 8000);  // once the launch has settled
      setInterval(() => { if (muCacheDirty) { muCacheDirty = false; neo.musicCacheSave(muCache).catch(() => {}); } }, 30000);
    });
  }
  const muPl = name => mu.playlists.find(p => p.name === name);
  const muFavIds = () => new Set(muPl('Favoris').tracks.map(muId));
  const muIsFav = t => muFavIds().has(muId(t));
  const muOnline = name => muPl(name)?.mode === 'online';

  /* ---------- state of the player ---------- */
  const mp = {pl: 'Favoris', view: [], queue: [], cur: null, sel: new Set(), anchor: null, paused: false, resume: 0, length: 0, gain: 1, lastTick: 0, saveAt: 0, skipAt: 0, debounce: null,
    sleepTracks: null, sleepAt: null, wakeAt: null, wakeTimer: null, status: '', statusTimer: null, built: false, exists: {}, cover: '', recoUrl: '', recoReq: 0, busyQueue: Promise.resolve()};
  let muAudio = null, muCtx = null, muNodes = null, T = MU_THEMES.Nova;

  /* ---------- icons (vector, like MuPlayer's PIL-drawn ones) ---------- */
  const MU_PX = {
    disc: ['.....######.....', '...##########...', '..############..', '.#####....#####.', '.####......####.', '####...##...####', '###...####...###', '###..##..##..###', '###..##..##..###', '###...####...###', '####...##...####', '.####......####.', '.#####....#####.', '..############..', '...##########...', '.....######.....'],
    left: ['........##......', '......####......', '....######......', '..########......', '..########......', '....######......', '......####......', '........##......'],
    right: ['......##........', '......####......', '......######....', '......########..', '......########..', '......######....', '......####......', '......##........'],
    menu: ['................', '................', '................', '..############..', '..############..', '................', '................', '..############..', '..############..', '................', '................', '..############..', '..############..'],
    mini: ['................', '................', '..############..', '..############..', '..##........##..', '..##........##..', '..##........##..', '..##...#####.##.', '..##...#####.##.', '..##........##..', '..############..', '..############..'],search:['................','....######......','...##....##.....','..##......##....','..#........#....','..#........#....','..#........#....','..#........#....','..##......##....','...##....###....','....######.##...','............###.','.............###','..............##'],
    note:['................','.....#########..','.....#########..','.....##.....##..','.....##.....##..','.....##.....##..','.....##.....##..','.....##.....##..','..#####..#####..','.######.######..','.######.######..','..####...####...'],
    compass:['.....######.....','...###....###...','..##........##..','.##....##....##.','.#....#..#....#.','#....#....#....#','#...#..##..#...#','#..#..####..#..#','#...#..##..#...#','#....#....#....#','.#....#..#....#.','.##....##....##.','..##........##..','...###....###...','.....######.....'],
    shuffle:['................','................','...........#....','...........##...','###......#####..','...#....#..##...','....#..#...#....','.....##.........','.....##.........','....#..#...#....','...#....#..##...','###......#####..','...........##...','...........#....'],
    moon:['................','......####......','....######......','...#####........','..#####.........','..#####.........','.#####..........','.#####..........','.#####..........','..#####.....##..','..######..#####.','...###########..','....#########...','......#####.....'],
    clock:['.....######.....','...###....###...','..##........##..','.##....##....##.','.#.....##.....#.','#......##......#','#......##......#','#......#####...#','#..............#','#..............#','.#............#.','.##..........##.','..##........##..','...###....###...','.....######.....'],
    bars:['................','................','...........###..','...........###..','...........###..','...........###..','......###..###..','......###..###..','......###..###..','......###..###..','.###..###..###..','.###..###..###..','.###..###..###..','.###..###..###..','.###..###..###..'],
    trophy:['................','..############..','###.########.###','#.#.########.#.#','#.#..######..#.#','.##...####...##.','......####......','.......##.......','.......##.......','.......##.......','....########....','....########....','...##########...'],
    trash:['................','......####......','......#..#......','..############..','..############..','................','...###.##.###...','...###.##.###...','...###.##.###...','...###.##.###...','...###.##.###...','...###.##.###...','...###.##.###...','...##########...','....########....'],
    gear:['................','......####......','..##..####..##..','.####.####.####.','..############..','..####....####..','######....######','######....######','..####....####..','..############..','.####.####.####.','..##..####..##..','......####......'],
    globe:['.....######.....','...###.##.###...','..##..#..#..##..','.##...#..#...##.','.#....#..#....#.','#.....#..#.....#','#.....#..#.....#','################','#.....#..#.....#','#.....#..#.....#','.#....#..#....#.','.##...#..#...##.','..##..#..#..##..','...###.##.###...','.....######.....'],
    heart:['................','................','..####....####..','.######..######.','################','################','################','################','.##############.','..############..','...##########...','....########....','.....######.....','......####......','.......##.......'],
    heartO:['................','................','..####....####..','.#....#..#....#.','#......##......#','#..............#','#..............#','#..............#','.#............#.','..#..........#..','...#........#...','....#......#....','.....#....#.....','......#..#......','.......##.......'],
    close:['................','................','................','..##........##..','...##......##...','....##....##....','.....##..##.....','......####......','......####......','.....##..##.....','....##....##....','...##......##...','..##........##..'],
    play:['................','................','...##...........','...####.........','...######.......','...########.....','...##########...','...############.','...############.','...##########...','...########.....','...######.......','...####.........','...##...........'],
    pause:['................','................','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...','...####..####...'],
    next:['................','................','..##.........##.','..####.......##.','..######.....##.','..########...##.','..##########.##.','..##########.##.','..########...##.','..######.....##.','..####.......##.','..##.........##.'],
    prev:['................','................','.##.........##..','.##.......####..','.##.....######..','.##...########..','.##.##########..','.##.##########..','.##...########..','.##.....######..','.##.......####..','.##.........##..']};
  // one pixel-art drawing = one path of unit squares (rows merged), white (currentColor), never smoothed
  const muPx = (rows, size) => { let d = ''; rows.forEach((r, y) => { for (const m of r.matchAll(/#+/g)) d += 'M' + m.index + ' ' + y + 'h' + m[0].length + 'v1h-' + m[0].length + 'z'; });
    return `<svg viewBox="0 0 16 ${rows.length}" width="${size}" height="${size * rows.length / 16}" shape-rendering="crispEdges" aria-hidden="true"><path d="${d}" fill="currentColor"/></svg>`; };
  const muIcon = (k, size = 16) => muPx(MU_PX[k], size);
  const muLock = (size = 34, open = false) => `<svg viewBox="0 0 34 34" width="${size}" height="${size}" aria-hidden="true">${open
    ? '<path d="M15 16v-5a6 6 0 0 1 12 0" fill="none" stroke="currentColor" stroke-width="3.6"/>' : '<path d="M10.5 16v-4.5a6.5 6.5 0 0 1 13 0V16" fill="none" stroke="currentColor" stroke-width="3.6"/>'}<rect x="7" y="16" width="20" height="15" rx="4" fill="currentColor"/><circle cx="17" cy="22" r="2.2" fill="var(--mcard2)"/><path d="M16 23h2l.6 4.6h-3.2z" fill="var(--mcard2)"/></svg>`;

  /* ---------- the interface, built once like MuPlayer's build_ui ---------- */
  function muBuild() {
    if (mp.built) return;
    mp.built = true;
    const root = $('musicApp');
    const sideBtn = (icon, text, fn) => mh('button.muSideBtn', {onclick: fn, html: muIcon(icon) + '<span>' + text + '</span>'});
    root.replaceChildren(mh('div.mu#mu', {},
      mh('canvas.muAmb#muAmb'),
      mh('div.muTop', {}, mh('i.muTopStrip'), mh('button.muTopBtn.muMenuBtn', {title: 'Masquer / afficher le menu', html: muIcon('menu', 16), onclick: () => $('muSide').classList.toggle('closed')}), mh('b.muBrand', {html: '<span class="muLogo">' + muPx(MU_PX.disc, 26) + '</span><span>NEO</span><span class="muBrand2">MUSIC</span><em class="muBrandTag">DELUXE</em>'}), mh('span.muStatus#muStatus', {text: '●  Prêt'}),
        mh('div.muDl', {}, mh('i#muDl')), mh('span.muInd#muSleep'), mh('span.muInd#muWake')),
      mh('div.muBody', {},
        mh('aside.muSide#muSide', {}, mh('i.muSideStrip'),
          mh('div.muSideIn', {},
            mh('div.muHead', {text: 'PLAYLISTS'}), mh('div#muPlaylists'),
            mh('div.muPills.muExtra', {}, mh('button.muPill', {text: '＋ Nouvelle', onclick: () => muNewPlaylist()}), mh('button.muPill.danger', {text: '－ Supprimer', onclick: () => muDeletePlaylist()})),
            mh('div.muHead.muExtra', {text: 'BIBLIOTHÈQUE'}),
            mh('div.muExtra', {},
              sideBtn('search', 'Rechercher / importer', () => muSearchDialog()), sideBtn('compass', 'Chercher un artiste', () => muArtistDialog()), sideBtn('note', 'Importer une playlist', () => $('muFile').click()),
              sideBtn('shuffle', 'Lecture aléatoire', () => muShuffle()),
              sideBtn('moon', 'Mode sommeil', () => muSleepDialog()), sideBtn('clock', 'Réveil musical', () => muWakeDialog()),
              sideBtn('bars', 'Statistiques', () => muStats()), sideBtn('trophy', 'Succès', () => muAchievements()),
              sideBtn('trash', 'Corbeille', () => muTrash()), sideBtn('gear', 'Options', () => muOptions()))),
          ),
        mh('main.muMain', {},
          mh('section.muCard.muNow', {},
            mh('div.muCoverWrap#muCoverWrap', {}, mh('canvas#muCover', {width: 540, height: 400})),
            mh('div.muInfo', {},
              mh('div.muKickRow', {}, mh('span.muKick', {text: 'LECTURE EN COURS'}), mh('span.muLuxLv#muLuxLv')), mh('div.muTitle#muTitle', {text: 'Aucune musique sélectionnée'}), mh('span.muTime#muTime', {text: '00:00 / 00:00'}),
              mh('canvas.muProgress#muProgress', {height: 36}), mh('canvas.muSpectrum#muSpectrum', {height: 64}),
              mh('div.muControls', {},
                mh('button.muSkip#muPrev', {title: 'Morceau précédent', html: '<svg viewBox="0 0 40 40"><circle class="halo" cx="20" cy="20" r="19.5"/></svg>' + muPx(MU_PX.prev, 28).replace('<svg', '<svg style="position:absolute;inset:6px"'), onclick: () => muPrev()}),
                mh('button.muPlay#muPlay', {title: 'Lecture / pause', onclick: () => muToggle()}),
                mh('button.muSkip#muNext', {title: 'Morceau suivant', html: '<svg viewBox="0 0 40 40"><circle class="halo" cx="20" cy="20" r="19.5"/></svg>' + muPx(MU_PX.next, 28).replace('<svg', '<svg style="position:absolute;inset:6px"'), onclick: () => muNext()}))),
            mh('div.muNowSide.muExtra', {},
              mh('button.muBtn#muFav', {text: '♡ FAVORI', onclick: () => muToggleFav()}),
              mh('span.muSmall', {text: 'VOLUME'}), mh('input.muRange#muVol', {type: 'range', min: 0, max: 100, oninput: e => muSetVolume(e.target.value / 100)}),
              mh('span.muSmall', {text: 'PROFIL AUDIO'}), mh('select.muSelect#muEq', {onchange: e => muSetEq(e.target.value)}), mh('div.muEqPick', {}, mh('button', {title: 'Profil précédent', html: muPx(MU_PX.left, 16), onclick: () => muEqStep(-1)}), mh('span#muEqName'), mh('button', {title: 'Profil suivant', html: muPx(MU_PX.right, 16), onclick: () => muEqStep(1)})))),
          mh('section.muCard.muReco.muExtra', {},
            mh('div.muArt.alt#muRecoCover'), mh('div.muRecoText', {}, mh('span.muKick.alt', {text: 'RECOMMANDÉ POUR TOI'}), mh('span#muReco', {text: 'Écoute ou ajoute quelques musiques : des idées apparaîtront ici.'})),
            mh('button.muBtn', {text: '↻ AUTRE', title: 'Proposer une autre musique', onclick: () => muScheduleReco()}), mh('button.muBtn.accent', {text: '＋ AJOUTER', onclick: () => muAddReco()})),
          mh('section.muCard.muLib', {},
            mh('div.muLibHead', {}, mh('b#muLibTitle', {text: 'Favoris'}), mh('span#muWkInfo'), mh('button.muBtn.muWkBtn#muWkBtn', {text: 'METTRE À JOUR', title: 'Chercher les sorties et les découvertes maintenant', onclick: () => muWeekly(true)}), mh('span#muCount', {text: '0 titres'})),
            mh('div.muFilters.muExtra', {},
              mh('input.muFilter#muFilter', {placeholder: 'Titre ou artiste...', spellcheck: 'false', oninput: () => { clearTimeout(mp.ft); mp.ft = setTimeout(muRefresh, 220); }}),
              mh('select.muSelect.sub#muDurFilter', {onchange: () => muRefresh()}, ...['Toutes durées', 'Moins de 3 min', '3 à 5 min', 'Plus de 5 min'].map(t => mh('option', {text: t}))),
              mh('select.muSelect.sub#muSort', {onchange: () => muSort()}, ...['Ajout récent', 'Lecture récente', 'Alphabétique', 'Artiste', 'Date de publication'].map(t => mh('option', {text: t})))),
            mh('div.muList#muList', {tabindex: 0}, mh('div#muSpacer'))))),
      mh('div.muLayer#muLayer'),
      mh('input#muFile', {type: 'file', accept: '.json,.csv,.txt', hidden: true, onchange: e => { const f = e.target.files[0]; e.target.value = ''; if (f) muImportFile(f); }})));
    $('muEq').replaceChildren(...Object.keys(MU_PRESETS).map(k => mh('option', {text: k})));
    $('muList').onscroll = () => muDraw();
    new ResizeObserver(() => { muDraw(); muDrawProgress(true); }).observe($('muList'));
    new ResizeObserver(() => muDrawProgress(true)).observe($('muProgress'));
    muProgressEvents();
    $('muList').onkeydown = e => { if (e.key === 'Enter' && mp.sel.size) muRequest(Math.min(...mp.sel)); if (e.key === 'Delete' && mp.sel.size) muDeleteSelection(); };
    muMiniBuild();
    muApplyTheme(); muApplySettingsUi();
    muLoadPlaylist(mu.session?.playlist && muPl(mu.session.playlist) ? mu.session.playlist : 'Favoris');
    muRestoreSession();
    requestAnimationFrame(muFrame);
    setInterval(muClockTick, 250);
    muWeekly();
    muStartupAchievements();
  }
  function muApplyTheme() {
    T = MU_THEMES[mu.settings.theme] || MU_THEMES.Nova;
    const v = {bg: 'BG', side: 'SIDEBAR', card: 'CARD', card2: 'CARD_ALT', border: 'BORDER', text: 'TEXT', sub: 'SUBTEXT', acc: 'ACCENT', acc2: 'ACCENT_2', danger: 'DANGER', warn: 'WARN', heart: 'HEART'};
    for (const s of [$('mu').style, $('muMini').style]) {  // the portable player wears the theme too
      for (const [k, c] of Object.entries(v)) s.setProperty('--m' + k, T[c]);
      s.setProperty('--mpress', muShade(T.CARD, -.18)); s.setProperty('--mfont', muFont());
    }
    $('mu').dataset.ms = (MU_THEMES[mu.settings.theme] ? mu.settings.theme : 'Nova').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();  // le décor du thème (CSS data-ms)
    mp.disc = null; mp.discKey = ''; mp.specKey = '';
    muPlayIcon();
  }
  function muApplySettingsUi() {
    const st = mu.settings;
    $('muVol').value = Math.round(st.volume * 100); $('muVol').style.setProperty('--v', $('muVol').value + '%');
    $('muEq').value = st.equalizer in MU_PRESETS ? st.equalizer : 'Normal'; $('muEqName').textContent = st.equalizer || 'Normal';
    $('mu').classList.toggle('mini', !!st.mini); const lux = !!st.deluxe && muLevel().level >= 200; $('mu').classList.toggle('lux', lux); $('mu').classList.toggle('px', !!st.pixelUi || lux);  // Deluxe s'appuie sur l'appli pixel
    $('mu').classList.toggle('novis', !st.visualizer);
    $('mu').classList.toggle('gallery', !!st.gallery);
    $('muCoverWrap').classList.toggle('rect', !st.vinyl);
    $('muLuxLv').textContent = '★ NIVEAU ' + muLevel().level;
    muAudioSettings();
  }

  /* ---------- playlists in the sidebar ---------- */
  function muSidebar() {
    $('muPlaylists').replaceChildren(...mu.playlists.map(p => {
      const icon = muIcon(p.name === 'Favoris' ? 'heart' : p.mode === 'online' ? 'globe' : 'note', 13);
      const b = mh('button.muPlBtn' + (p.name === mp.pl ? '.on' : ''), {html: `<i></i><span class="ic">${icon}</span><span>${mhEsc(p.name)}</span><em>${p.tracks.length}</em>`, onclick: () => muLoadPlaylist(p.name)});
      b.oncontextmenu = e => { e.preventDefault(); muLoadPlaylist(p.name); };
      return b;
    }));
  }
  const mhEsc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'})[c]);
  function muLoadPlaylist(name) {
    if (!muPl(name)) name = 'Favoris';
    mp.pl = name; mp.sel.clear(); mp.anchor = null;
    $('muLibTitle').textContent = name;
    muSidebar(); muRefresh(); muWkUi();
    $('muList').scrollTop = 0;
    muCheckFiles(muPl(name).tracks);
  }
  // on a PC that got the library through the sync, offline files may be missing here: known once per file
  async function muCheckFiles(tracks) {
    const names = [...new Set(tracks.map(t => t.file).filter(f => f && !(f in mp.exists)))];
    if (!names.length) return;
    Object.assign(mp.exists, await neo.musicExists(names));
    muDraw();
  }

  /* ---------- the list: filters, sort, virtual rows (only what is on screen exists), list or cover wall ---------- */
  function muRefresh() {
    const p = muPl(mp.pl); if (!p) return;
    const em = $('muPlaylists').querySelectorAll('.muPlBtn em'); mu.playlists.forEach((x, i) => { if (em[i]) em[i].textContent = x.tracks.length; });  // les nombres de titres à jour (ajout, suppression)
    const q = $('muFilter').value.trim().toLowerCase(), d = $('muDurFilter').value;
    mp.view = p.tracks.filter(t => {
      if (q && !((t.display_title || '').toLowerCase().includes(q) || (t.author || '').toLowerCase().includes(q))) return false;
      const s = muDur(t);
      return d === 'Moins de 3 min' ? s < 180 : d === '3 à 5 min' ? s >= 180 && s <= 300 : d === 'Plus de 5 min' ? s > 300 : true;
    });
    const n = p.tracks.length;
    $('muCount').textContent = n + ' ' + (n > 1 ? 'titres' : 'titre');
    mp.favs = muFavIds();
    mp.drawn = new Map(); $('muSpacer').replaceChildren();
    $('muList').querySelector('.muEmpty')?.remove();
    if (!mp.view.length) $('muList').prepend(n ? mh('div.muEmpty', {}, mh('b', {text: 'Aucune musique ne correspond au filtre.'}), muButton('EFFACER LE FILTRE', () => { $('muFilter').value = ''; $('muDurFilter').selectedIndex = 0; muRefresh(); }))
      : MU_WEEKLY.includes(mp.pl) ? mh('div.muEmpty', {}, mh('b', {text: mp.pl === 'Radar des sorties' ? 'Les nouvelles sorties de tes artistes arrivent ici.' : 'Des artistes proches de tes goûts arrivent ici.'}), mh('span', {text: 'Elle se remplit toute seule chaque semaine, d\'après tes écoutes et tes favoris.'}), mh('div.muWBtns', {}, muButton('METTRE À JOUR MAINTENANT', () => muWeekly(true), 'accent')))
      : mh('div.muEmpty', {}, mh('b', {text: 'Cette playlist est vide.'}), mh('span', {text: mp.pl === 'Favoris' ? 'Clique sur le cœur d\'une musique pour la garder ici.' : 'Cherche une musique ou un artiste pour la remplir.'}),
        mh('div.muWBtns', {}, muButton('RECHERCHER / IMPORTER', () => muSearchDialog(), 'accent'), muButton('CHERCHER UN ARTISTE', () => muArtistDialog()))));
    muDraw();
  }
  function muGeometry() {
    const list = $('muList'), gal = mu.settings.gallery;
    const cols = gal ? Math.max(1, Math.floor((list.clientWidth - 8 + MU_GAP) / (MU_TILE_W + MU_GAP))) : 1;
    const rowH = gal ? MU_TILE_H + MU_GAP : MU_ROW;
    return {cols, rowH, rows: Math.ceil(mp.view.length / cols)};
  }
  function muDraw() {
    if (!mp.built) return;
    const list = $('muList'), sp = $('muSpacer'), g = muGeometry();
    sp.style.height = g.rows * g.rowH + 'px';
    const first = Math.max(0, Math.floor(list.scrollTop / g.rowH) - 4), last = Math.min(g.rows - 1, Math.ceil((list.scrollTop + list.clientHeight) / g.rowH) + 4);
    const want = new Set();
    for (let r = first; r <= last; r++) for (let c = 0; c < g.cols; c++) { const i = r * g.cols + c; if (i < mp.view.length) want.add(i); }
    mp.drawn ||= new Map();
    for (const [i, node] of mp.drawn) if (!want.has(i) || node._t !== mp.view[i] || node._g !== mu.settings.gallery) { node.remove(); mp.drawn.delete(i); }
    for (const i of want) {
      let node = mp.drawn.get(i);
      if (!node) { node = muRowNode(i); mp.drawn.set(i, node); sp.append(node); }
      const r = Math.floor(i / g.cols), c = i % g.cols;
      node.style.transform = mu.settings.gallery ? `translate(${c * (MU_TILE_W + MU_GAP) + 4}px, ${r * g.rowH}px)` : `translateY(${r * MU_ROW}px)`;
      muRowState(node, i);
    }
  }
  function muArt(t, size, cls = '') {  // ArtworkFrame: framed cover, or the "?" placeholder; a cover missing on this PC is fetched again
    const box = mh('div.muArt' + cls, {style: {width: size + 'px', height: size + 'px'}});
    if (t?.cover && !mu.settings.noImages) {
      const img = mh('img', {src: 'neoplugin://neodex.music/cover/' + encodeURIComponent(t.cover), loading: 'lazy', draggable: 'false', alt: ''});
      img.onerror = () => { img.remove(); muFetchCover(t).then(ok => { if (ok) box.append(mh('img', {src: 'neoplugin://neodex.music/cover/' + encodeURIComponent(t.cover) + '?r=' + Date.now(), alt: ''})); }); };
      box.append(img);
    }
    return box;
  }
  const muCoverJobs = new Map();
  function muFetchCover(t) {
    if (!t.thumbnail_url) return Promise.resolve(false);
    if (!muCoverJobs.has(t.thumbnail_url)) muCoverJobs.set(t.thumbnail_url, neo.musicCover(t.thumbnail_url).then(name => { if (name) { if (t.cover !== name) { t.cover = name; muSave(); } return true; } return false; }).catch(() => false));
    return muCoverJobs.get(t.thumbnail_url);
  }
  function muRowNode(i) {
    const t = mp.view[i], gal = mu.settings.gallery, fav = mp.favs.has(muId(t));
    let sub = t.author || 'Artiste inconnu';
    const extra = [];
    if (mu.settings.dateAdded && t.date_added) extra.push('Ajouté le ' + new Date(t.date_added * 1000).toLocaleDateString('fr-FR'));
    if (mu.settings.releaseDate && /^\d{8}$/.test(t.publish_date || '')) extra.push('Sorti le ' + t.publish_date.replace(/(\d{4})(\d\d)(\d\d)/, '$3/$2/$1'));
    if (extra.length) sub += '  ·  ' + extra.join('  ·  ');
    const missing = t.file && mp.exists[t.file] === false && !t.url;
    const favBtn = mh('button.muRowFav' + (fav ? '.on' : ''), {html: muIcon(fav || mu.settings.pixelUi ? 'heart' : 'heartO', 16), title: fav ? 'Retirer des favoris' : 'Ajouter aux favoris', onclick: e => { e.stopPropagation(); muFlash(e.currentTarget, T.HEART); muToggleFav(t); }});
    const del = mh('button.muRowDel', {html: muIcon('close', 16), title: 'Supprimer', onclick: e => { e.stopPropagation(); muFlash(e.currentTarget, T.DANGER); muDeleteTracks([t]); }});
    const node = gal
      ? mh('div.muTile', {}, mh('i.muStrip'), muArt(t, 120), mh('b', {text: t.display_title || t.file}), mh('span', {text: sub}), mh('em', {text: muTime(muDur(t))}), mh('div.muTileAct', {}, favBtn, del))
      : mh('div.muRow' + (missing ? '.missing' : ''), {}, mh('i.muStrip'), muArt(t, 42), mh('div.muRowText', {}, mh('b', {text: t.display_title || t.file}),
        mh('div', {}, mh('span', {text: sub}))), mh('em.muRowDur', {text: muTime(muDur(t))}), favBtn, del);
    node._t = t; node._g = gal;
    node.onclick = e => muRowClick(i, e);
    node.ondblclick = () => muRequest(i);
    node.oncontextmenu = e => { e.preventDefault(); muContext(e, i); };
    return node;
  }
  function muRowState(node, i) {
    const t = mp.view[i], sel = mp.sel.has(i), playing = mp.cur && muId(mp.cur) === muId(t);
    node.classList.toggle('sel', sel); node.classList.toggle('playing', !!playing);
    const fav = mp.favs.has(muId(t)), fb = node.querySelector('.muRowFav');
    if (fb && fb.classList.contains('on') !== fav) { fb.classList.toggle('on', fav); fb.innerHTML = muIcon(fav || mu.settings.pixelUi ? 'heart' : 'heartO', 16); }
    node.classList.toggle('missing', !!(t.file && mp.exists[t.file] === false));
  }
  function muFlash(b, color) { const c = b.style.color; b.style.color = color; setTimeout(() => b.style.color = c, 130); }
  function muRowClick(i, e) {  // Ctrl: toggle, Shift: range from the anchor, plain click: one
    if (e.shiftKey && mp.anchor != null) { mp.sel = new Set(); const [a, b] = [mp.anchor, i].sort((x, y) => x - y); for (let k = a; k <= b; k++) mp.sel.add(k); }
    else if (e.ctrlKey) { mp.sel.has(i) ? mp.sel.delete(i) : mp.sel.add(i); mp.anchor = i; }
    else { mp.sel = new Set([i]); mp.anchor = i; }
    muDraw();
  }
  function muContext(e, i) {
    const multi = mp.sel.size > 1 && mp.sel.has(i);
    if (!multi) { mp.sel = new Set([i]); mp.anchor = i; muDraw(); }
    const t = mp.view[i], sel = multi ? [...mp.sel].sort((a, b) => a - b).map(k => mp.view[k]) : [t];
    const targets = mu.playlists.filter(p => p.name !== mp.pl);
    const sub = targets.length ? targets.map(p => [(p.mode === 'online' ? '🌐 ' : '') + p.name, () => muAddTracksTo(sel, p.name)]) : [['Aucune autre playlist', null]];
    const items = multi
      ? [['▶  Lire', () => muRequest(i)], ['➕  Ajouter les ' + sel.length + ' sélectionnées à...', sub], null, ['✕  Supprimer les ' + sel.length + ' sélectionnées', () => muDeleteTracks(sel)]]
      : [['▶  Lire', () => muRequest(i)], muIsFav(t) ? ['♡  Retirer des favoris', () => muToggleFav(t)] : ['♥  Ajouter aux favoris', () => muToggleFav(t)], ['➕  Ajouter à...', sub],
        t.file ? ['📂  Afficher le fichier', () => neo.musicReveal(t.file)] : null, null, ['✕  Supprimer', () => muDeleteTracks([t])]];
    muMenu(e.clientX, e.clientY, items.filter(x => x !== undefined));
  }
  function muMenu(x, y, items) {
    document.querySelectorAll('.muMenu').forEach(m => m.remove());
    const build = (list, px, py) => {
      const m = mh('div.muMenu');
      for (const it of list) {
        if (!it) { m.append(mh('hr')); continue; }
        const [label, act] = it, b = mh('button', {text: label + (Array.isArray(act) ? '   ›' : ''), disabled: !act});
        if (Array.isArray(act)) b.onmouseenter = () => { m.querySelectorAll('.muMenu').forEach(s => s.remove()); const r = b.getBoundingClientRect(); const s = build(act, r.right - 4, r.top - 4); s.classList.add('sub'); m.append(s); };
        else if (act) b.onclick = () => { document.querySelectorAll('.muMenu').forEach(m => m.remove()); act(); };
        m.append(b);
      }
      m.style.left = px + 'px'; m.style.top = py + 'px';
      return m;
    };
    const m = build(items, x, y); $('mu').append(m);  // inside #mu: it needs the theme colours
    const r = m.getBoundingClientRect(); if (r.right > innerWidth) m.style.left = innerWidth - r.width - 6 + 'px'; if (r.bottom > document.body.clientHeight) m.style.top = document.body.clientHeight - r.height - 6 + 'px';
    setTimeout(() => addEventListener('pointerdown', function close(ev) { if (!ev.target.closest('.muMenu')) { document.querySelectorAll('.muMenu').forEach(m => m.remove()); removeEventListener('pointerdown', close, true); } }, true));
  }
  function muSort() {
    const p = muPl(mp.pl), o = $('muSort').value, k = (t, f) => (t[f] || '').toLowerCase();
    const cmp = {'Ajout récent': (a, b) => (b.date_added || 0) - (a.date_added || 0), 'Lecture récente': (a, b) => (b.last_played || 0) - (a.last_played || 0), 'Alphabétique': (a, b) => k(a, 'display_title').localeCompare(k(b, 'display_title')),
      'Artiste': (a, b) => k(a, 'author').localeCompare(k(b, 'author')) || k(a, 'display_title').localeCompare(k(b, 'display_title')), 'Date de publication': (a, b) => String(b.publish_date || '').localeCompare(String(a.publish_date || ''))}[o];
    p.tracks.sort(cmp); muSave(); mp.sel.clear(); muRefresh();
  }

  /* ---------- audio: <audio> through Web Audio (10-band equaliser, balance, limiter, analyser for the spectrum) ---------- */
  function muEngine() {
    if (muAudio) return;
    muAudio = new Audio(); muAudio.crossOrigin = 'anonymous'; muAudio.preload = 'auto';
    muCtx = new AudioContext();
    const src = muCtx.createMediaElementSource(muAudio);
    const eq = MU_BANDS.map((f, i) => { const b = muCtx.createBiquadFilter(); b.type = i === 0 ? 'lowshelf' : i === 9 ? 'highshelf' : 'peaking'; b.frequency.value = f; b.Q.value = f <= 62 ? .7 : 1.1; return b; });
    const pan = muCtx.createStereoPanner(), comp = muCtx.createDynamicsCompressor(), analyser = muCtx.createAnalyser(), gain = muCtx.createGain(), dry = muCtx.createGain();
    comp.threshold.value = -6; comp.knee.value = 4; comp.ratio.value = 12; comp.attack.value = .005; comp.release.value = .08;
    analyser.fftSize = 4096; analyser.smoothingTimeConstant = 0;  // smoothed like MuPlayer instead, see muSpectrumBlock
    src.connect(eq[0]); eq.reduce((a, b) => (a.connect(b), b)).connect(pan);
    pan.connect(dry); dry.connect(analyser); comp.connect(analyser); analyser.connect(gain); gain.connect(muCtx.destination);
    muNodes = {eq, pan, comp, analyser, gain, dry};
    muAudio.onended = () => muNext(true);
    muAudio.onerror = () => { if (!muAudio.src) return; muStatus('Erreur audio', T.DANGER); muWarn('lecture', muAudio.error?.message || 'flux illisible'); };
    muAudio.onplaying = () => { mp.paused = false; mp.lastTick = performance.now(); muPlayIcon(); muMiniSync(); };
    muAudio.onpause = () => { muPlayIcon(); muMiniPaint(); };
    muAudioSettings();
  }
  function muAudioSettings() {
    if (!muNodes) return;
    const st = mu.settings, gains = st.equalizer === 'Custom' ? st.eqBands : MU_PRESETS[st.equalizer] || MU_PRESETS.Normal;
    muNodes.eq.forEach((b, i) => b.gain.value = gains[i] || 0);
    muNodes.pan.pan.value = Math.max(-1, Math.min(1, +st.balance || 0));
    muNodes.pan.disconnect();
    muNodes.pan.connect(st.limiter || gains.some(g => g > 0) ? muNodes.comp : muNodes.dry);  // boosting profiles get a limiter, like MuPlayer's ffmpeg chains
    muVolumeApply();
  }
  function muVolumeApply() { if (muNodes) muNodes.gain.gain.value = Math.max(0, mu.settings.volume * (mu.settings.replaygain ? mp.gain : 1)); }
  function muSetVolume(v) { mu.settings.volume = Math.max(0, Math.min(1, v)); if ($('muVol')) { $('muVol').value = Math.round(mu.settings.volume * 100); $('muVol').style.setProperty('--v', $('muVol').value + '%'); } muVolumeApply(); muSave(2000); }
  function muSetEq(name) { mu.settings.equalizer = name; $('muEq').value = name; $('muEqName').textContent = name; muAudioSettings(); muSave(); }
  const muEqStep = d => { const k = Object.keys(MU_PRESETS), i = k.indexOf(mu.settings.equalizer); muSetEq(k[(i < 0 ? 0 : i + d + k.length) % k.length]); };  // « Custom » n'est pas dans la liste : on repart du premier
  const muSrc = t => t.file && mp.exists[t.file] !== false ? 'neoplugin://neodex.music/file/' + encodeURIComponent(t.file) : t.url ? 'neoplugin://neodex.music/stream/?u=' + encodeURIComponent(t.url) : '';

  /* ---------- play, pause, next, previous (anti-bounce 120 ms + 0.5 s between manual changes, like MuPlayer) ---------- */
  function muRequest(i, opts = {}) {
    if (performance.now() - mp.skipAt < 500) return false;
    mp.skipAt = performance.now();
    clearTimeout(mp.debounce);
    const queue = mp.view.slice();
    mp.debounce = setTimeout(() => muPlay(queue, i, opts), 120);
    return true;
  }
  async function muPlay(queue, i, {record = true, start = 0} = {}) {
    const t = queue[i]; if (!t) return;
    muEngine();
    if (muCtx.state === 'suspended') muCtx.resume();
    if (t.file && !(t.file in mp.exists)) Object.assign(mp.exists, await neo.musicExists([t.file]));
    if (t.file && mp.exists[t.file] === false && t.url && !muOnline(mp.pl) && muPlaylistOf(t)?.mode !== 'online') {  // synced from another PC: download the file here first
      muStatus('Téléchargement pour cet appareil...', T.ACCENT_2);
      try { await muDownloadInto(t); } catch (e) { muWarn('téléchargement', e); }
    }
    const src = muSrc(t);
    if (!src) return muNotify('error', 'Lecture', 'Cette musique n\'a pas de source disponible.');
    mp.queue = queue; mp.cur = t; mp.length = muDur(t); mp.resume = 0;
    mp.gain = muCache[muId(t)]?.g ?? 1; muVolumeApply();
    muAudio.src = src;
    if (start > 0) muAudio.addEventListener('loadedmetadata', () => { try { muAudio.currentTime = start; } catch {} }, {once: true});
    muAudio.play().catch(e => { if (e.name !== 'AbortError') { muStatus('Erreur audio', T.DANGER); muWarn('lecture', e); } });
    mp.paused = false; mp.lastTick = performance.now();
    muStatus(t.file && mp.exists[t.file] !== false ? 'Lecture' : 'Chargement du flux...', T.ACCENT_2);
    muAudio.addEventListener('playing', () => muStatus('Lecture', T.ACCENT_2), {once: true});
    $('muTitle').textContent = t.display_title || t.file; muFitTitle();
    muSetCover(t); muFavButton(); muDraw(); muDrawProgress(true);
    muAnalyse(t);
    if (record) muRecordPlay(t);
    muMiniPaint();
    muScheduleReco();
    muSaveSession();
  }
  const muPlaylistOf = t => mu.playlists.find(p => p.tracks.includes(t));
  function muToggle() {
    muEngine();
    if (mp.cur && !muAudio.paused) return muPause();
    if (mp.cur && muAudio.src && muAudio.paused && !muAudio.ended && mp.paused) { muCtx.resume(); muAudio.play(); mp.paused = false; mp.lastTick = performance.now(); muStatus('Lecture', T.ACCENT_2); muPlayIcon(); return; }
    const i = mp.sel.size ? Math.min(...mp.sel) : Math.max(0, mp.view.findIndex(t => muId(t) === muId(mp.cur)));
    if (!mp.view.length) return;
    const same = mp.cur && muId(mp.view[i]) === muId(mp.cur);
    muPlay(mp.view.slice(), i, {start: same ? mp.resume : 0});
  }
  function muPause() { if (!muAudio) return; muAudio.pause(); mp.paused = true; mp.lastTick = 0; muStatus('Pause', T.WARN); muPlayIcon(); muSaveSession(); }
  function muStop() { if (!muAudio) return; muAudio.pause(); muAudio.currentTime = 0; mp.paused = true; mp.lastTick = 0; muPlayIcon(); muStatus('Stop', T.SUBTEXT); }
  function muStep(d, auto) {
    const q = mp.queue.length ? mp.queue : mp.view; if (!q.length) return false;
    let i = q.findIndex(t => muId(t) === muId(mp.cur));
    i = i < 0 ? 0 : (i + d + q.length) % q.length;
    if (auto) { muPlay(q, i); return true; }
    if (performance.now() - mp.skipAt < 500) return false;
    mp.skipAt = performance.now(); clearTimeout(mp.debounce); mp.debounce = setTimeout(() => muPlay(q, i), 120);
    muSkipCooldown();
    return true;
  }
  function muNext(auto) { if (muSleepCountdown()) return false; return muStep(1, auto); }
  function muPrev() { return muStep(-1); }
  function muSkipCooldown() { for (const id of ['muPrev', 'muNext']) { const b = $(id); b.disabled = true; setTimeout(() => b.disabled = false, 500); } }
  function muSeek(sec) { if (!muAudio || !mp.cur) return; const d = muAudio.duration || mp.length; try { muAudio.currentTime = Math.max(0, Math.min(d - .2, sec)); } catch {} muDrawProgress(); }
  function muShuffle() {
    const p = muPl(mp.pl); if (!p.tracks.length) return;
    for (let i = p.tracks.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [p.tracks[i], p.tracks[j]] = [p.tracks[j], p.tracks[i]]; }
    muSave(); mp.sel.clear(); muRefresh();
    muShuffleAchievement(muId(p.tracks[0]));
    mp.skipAt = 0; muRequest(0);
  }
  // le widget de l'accueil de NeoDex (widget.js, son petit lecteur) : le morceau en cours, la suite, les couleurs du thème ;
  // envoyé quand quelque chose change (la progression, il la fait avancer lui-même ; renvoyée toutes les 15 s contre la dérive)
  let muWLast = '', muWAt = 0;
  function muWidget() {
    mp.wAt = performance.now();
    const t = mp.cur; if (!ctx.widget?.set || !T) return;
    const playing = !!muAudio && !muAudio.paused, q = mp.queue.length ? mp.queue : mp.view, i = t ? q.findIndex(x => muId(x) === muId(t)) : -1;
    const s = mu.settings, look = { T, deck: { vinyl: s.vinyl, deckBase: s.deckBase, deckArm: s.deckArm, deckStyle: s.deckStyle, deckLuxe: s.deckLuxe }, level: muLevel().level, vol: s.volume, ms: $('mu').dataset.ms || 'nova', amb: muAmbSmallOn() };  // le visuel choisi du petit lecteur
    const w = t ? { title: t.display_title || t.file || '', artist: t.author || muPlaylistOf(t)?.name || '', cover: s.noImages ? '' : t.cover || '', playing, fav: mp.favs.has(muId(t)), dur: muAudio?.duration || muDur(t) || 0, ...look } : look;
    muPresence();
    const k = JSON.stringify(w); if (k === muWLast && Date.now() - muWAt < 15e3) return; muWLast = k; muWAt = Date.now(); mp.wData = w;
    ctx.widget.set({ data: { ...w, pos: muAudio?.currentTime || 0, at: Date.now() } }).catch(() => {});
  }
  // le statut Discord « Écoute NeoMusic » (Options → Discord) : le morceau et sa barre de temps ; effacé en pause ou à l'arrêt.
  // Envoyé seulement quand quelque chose change (morceau, pause, saut dans le morceau de plus de 3 s)
  // l'application Discord « NeoMusic » de NeoDex : la même pour tout le monde (un identifiant public, pas un secret)
  const MU_DISCORD_APP = '1572986824257839216';
  // 1.x (NeoDex 3.3.9) : en pause, le statut reste 10 min avec « En pause » (puis s'efface) ; la playlist et la place du morceau (3 sur 12),
  // le niveau d'écoute dans le petit logo
  let muPrLast = '', muPrPauseAt = 0, muPrTimer = 0;
  function muPresence(force) {
    const s = mu.settings, t = mp.cur, id = MU_DISCORD_APP, on = !!(s.discord && id), playing = on && !!t && !!muAudio && !muAudio.paused;
    if (playing) muPrPauseAt = 0; else if (on && t && muAudio && !muPrPauseAt) { muPrPauseAt = Date.now(); clearTimeout(muPrTimer); muPrTimer = setTimeout(() => muPresence(), 600e3 + 500); }
    const paused = on && !playing && !!t && !!muAudio && !!muPrPauseAt && Date.now() - muPrPauseAt < 600e3;
    const dur = muAudio?.duration || (t ? muDur(t) : 0) || 0, start = playing ? Date.now() - (muAudio.currentTime || 0) * 1000 : 0;
    const q = mp.queue.length ? mp.queue : mp.view, pos = t ? q.findIndex(x => muId(x) === muId(t)) + 1 : 0;
    const act = playing || paused ? { title: t.display_title || t.file || 'Musique', artist: t.author || '', image: s.noImages ? '' : t.thumbnail_url || '', url: t.url || '', start, end: playing && dur > 0 && isFinite(dur) ? start + dur * 1000 : 0,
      paused, list: muPlaylistOf(t)?.name || mp.pl || '', pos, total: q.length, level: muLevel().level } : null;
    const k = JSON.stringify([on && id, act && [act.title, act.artist, act.image, act.paused, act.pos, Math.round(act.start / 3000)]]);
    if (k === muPrLast && !force) return; muPrLast = k;
    if (!on && !force) return;
    neo.musicPresence?.(on ? id : '', act)?.catch?.(() => {});
  }
  function muWidgetSpec(now) {  // le spectre du widget, comme celui du petit lecteur (le widget le lisse lui-même entre deux envois)
    if (!mp.wData?.title || !ctx.widget?.set || now - (mp.wsAt || 0) < 120) return; mp.wsAt = now;
    ctx.widget.set({ data: { ...mp.wData, spec: muSpec.levels.map(v => Math.round(v * 100) / 100), pos: muAudio?.currentTime || 0, at: Date.now() } }).catch(() => {});
  }
  function muPlayIcon() {
    muWidget();
    const b = $('muPlay'); if (!b) return;
    const pause = muAudio && !muAudio.paused;
    b.innerHTML = `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="31" fill="none" stroke="var(--mcard2)" stroke-width="2"/><circle class="fill" cx="32" cy="32" r="28"/></svg><span style="color:#06110C">${muPx(MU_PX[pause ? 'pause' : 'play'], 28)}</span>`;
  }
  function muFitTitle() {  // two lines at most, then an ellipsis (MuPlayer's set_song_title)
    const el = $('muTitle'), full = mp.cur?.display_title || el.textContent;
    el.textContent = full;
    if (el.scrollHeight <= el.clientHeight + 2) return;
    let lo = 0, hi = full.length;
    while (lo < hi) { const m = (lo + hi + 1) >> 1; el.textContent = full.slice(0, m).trimEnd() + '…'; el.scrollHeight <= el.clientHeight + 2 ? lo = m : hi = m - 1; }
    el.textContent = full.slice(0, lo).trimEnd() + '…';
  }
  function muFavButton() {
    const fav = mp.cur && muIsFav(mp.cur), b = $('muFav');
    b.textContent = fav ? '♥ FAVORI' : '♡ FAVORI'; b.style.color = fav ? T.HEART : '';
  }

  /* ---------- waveform + ReplayGain of a track: decoded once in the page, kept on this PC ---------- */
  let muAnalysing = Promise.resolve();
  function muAnalyse(t) {
    const id = muId(t);
    if (muCache[id]?.w) return;
    muAnalysing = muAnalysing.then(async () => {
      if (muCache[id]?.w || muId(mp.cur) !== id) return;
      try {
        const buf = await (await fetch(muSrc(t))).arrayBuffer();
        const audio = await new OfflineAudioContext(1, 1, 22050).decodeAudioData(buf);
        const ch = audio.getChannelData(0), n = 200, step = Math.floor(ch.length / n) || 1, w = [];
        let sum = 0, cnt = 0;
        for (let b = 0; b < n; b++) { let s = 0; for (let i = b * step, e = Math.min(ch.length, i + step); i < e; i += 4) { s += ch[i] * ch[i]; sum += ch[i] * ch[i]; cnt++; } w.push(Math.sqrt(s / (step / 4))); }
        const mx = Math.max(...w) || 1, rms = Math.sqrt(sum / Math.max(1, cnt));
        muCache[id] = {w: w.map(v => Math.round(v / mx * 1e4) / 1e4), g: rms > 0 ? Math.max(.4, Math.min(1.6, .11 / rms)) : 1};
        muCacheDirty = true;
        if (muId(mp.cur) === id) { mp.gain = muCache[id].g; muVolumeApply(); muDrawProgress(true); }
      } catch (e) { muWarn('forme d\'onde', e); }
    });
  }

  /* ---------- the "now playing" visuals: vinyl (or square cover) with inertia, waveform progress, spectrum ---------- */
  function muSetCover(t) {
    mp.coverOld = mp.coverImg ? {img: mp.coverImg, disc: mp.disc} : null;
    mp.fadeAt = performance.now();
    mp.coverImg = null; mp.disc = null;
    if (!t?.cover || mu.settings.noImages) return;
    const img = new Image(); img.crossOrigin = 'anonymous';
    img.onload = () => { if (mp.cur === t) { mp.coverImg = img; mp.disc = null; mp.fadeAt = performance.now(); } };
    img.onerror = () => muFetchCover(t).then(ok => { if (ok && mp.cur === t) img.src = 'neoplugin://neodex.music/cover/' + encodeURIComponent(t.cover) + '?r=' + Date.now(); });
    img.src = 'neoplugin://neodex.music/cover/' + encodeURIComponent(t.cover);
  }
  /* ---------- la platine en pixel art : tout est posé pixel par pixel dans une petite image, agrandie ensuite sans lissage.
     Le disque tourne pour de vrai : chaque pixel va chercher sa couleur dans la pochette (réduite en gros pixels) à l'angle du moment.
     Le bras se pose quand la musique joue, avance vers le centre avec le morceau et se relève à la pause. ---------- */
  // platine:début (recopié tel quel dans widget.js par tools/widget-sync.js)
  const MU_RPM = 200;  // 33 tours ⅓ par minute = 200° par seconde
  /* les platines du niveau 150 et plus, en deux parties qu'on combine librement :
     le socle (sa matière : aux couleurs du thème, bois ou pierre) et le bras (son métal, qui fait aussi le bord du plateau et le liseré).
     'A' / 'B' : les couleurs d'accent du thème. */
  const MU_BASES = {
    'Thème': {lv: 150, note: 'aux couleurs du thème'},
    Noyer: {lv: 150, note: 'bois brun', mat: ['#7a4a26', '#5e3519', '#8f5a30']},
    'Ébène': {lv: 160, note: 'bois sombre', mat: ['#3a2418', '#2c1a10', '#4a2e1c']},
    'Érable': {lv: 170, note: 'bois clair', mat: ['#c8995e', '#b3844c', '#d6aa70']},
    Ardoise: {lv: 180, note: 'pierre grise', mat: ['#4b4f59', '#3f434c', '#565b66']},
    Marbre: {lv: 190, note: 'pierre blanche veinée', mat: ['#d9d7d1', '#c6c4bd', '#e7e5df']},
  };
  const MU_ARMS = {
    'Thème': {lv: 150, note: 'argent teinté du thème'},
    Argent: {lv: 150, note: 'argent', rim: ['#ffffff', '#a4a7b4'], metal: ['#ffffff', '#b8bcc8', '#5a5e6c']},
    Or: {lv: 150, note: 'or', rim: ['#ffe9a8', '#c99a3e'], metal: ['#ffe9a8', '#c99a3e', '#6e4a12'], band: '#c99a3e'},
    Noir: {lv: 160, note: 'métal noir mat', rim: ['#8a8d98', '#45474f'], metal: ['#8a8d98', '#3a3c45', '#16171c'], band: '#45474f'},
    Cuivre: {lv: 180, note: 'cuivre', rim: ['#ffc89a', '#c8743a'], metal: ['#ffc89a', '#c8743a', '#6e3412'], band: '#c8743a'},
    Platine: {lv: 190, note: 'platine, liseré à la 2e couleur du thème', rim: ['#ffffff', '#c9ccd6'], metal: ['#ffffff', '#dfe1e8', '#7b7e8a'], band: 'B'},
  };
  const MU_DECK_OLD = {Classique: ['Thème', 'Thème'], Collection: ['Noyer', 'Or'], 'Ébène': ['Ébène', 'Argent'], 'Érable': ['Érable', 'Or'], Cuivre: ['Thème', 'Cuivre'], Platine: ['Thème', 'Platine']};  // l'ancien réglage « deckStyle » (une platine toute faite)
  const muDeckParts = () => {  // [socle, bras] choisis, chacun ramené au thème si le niveau ne le permet pas
    const st = mu.settings, old = MU_DECK_OLD[st.deckStyle || (st.deckLuxe ? 'Collection' : 'Classique')] || MU_DECK_OLD.Classique, lv = muLevel().level;
    const b = st.deckBase || old[0], a = st.deckArm || old[1];
    return [MU_BASES[b]?.lv <= lv ? b : 'Thème', MU_ARMS[a]?.lv <= lv ? a : 'Thème'];
  };
  const muDeckNew = lv => {  // le message du niveau qui débloque des pièces de platine ('' si aucune)
    if (lv === 150) return 'socles et bras à combiner débloqués';
    const got = [['socle', MU_BASES], ['bras', MU_ARMS]].flatMap(([k, m]) => Object.keys(m).filter(n => m[n].lv === lv).map(n => k + ' « ' + n + ' »'));
    return got.length ? got.join(' et ') + ' débloqué' + (got.length > 1 ? 's' : '') : '';
  };
  const muDeckKit = () => { const [b, a] = muDeckParts(); return {...MU_BASES[b], ...MU_ARMS[a]}; };
  const muCol = c => { const [r, g, b] = muHex(c.length === 4 ? '#' + [...c.slice(1)].map(x => x + x).join('') : c); return (0xff000000 | b << 16 | g << 8 | r) >>> 0; };  // une couleur → un pixel d'ImageData
  function muPixLabel(img, d) {  // l'étiquette : la pochette réduite à d×d pixels, en peu de couleurs (ou une étiquette aux couleurs du thème)
    const cache = mp.pxLabels ??= new WeakMap(), k = img || muPixLabel, hit = cache.get(k);
    if (hit && hit.d === d && hit.t === T) return hit.p;
    const c = document.createElement('canvas'); c.width = c.height = d;
    const g = c.getContext('2d', {willReadFrequently: true});
    g.fillStyle = T.ACCENT; g.fillRect(0, 0, d, d); g.fillStyle = muShade(T.ACCENT_2 || T.ACCENT, -.35); g.fillRect(0, d >> 1, d, d - (d >> 1));
    if (img) { const s = Math.min(img.width, img.height); g.imageSmoothingQuality = 'high'; g.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, d, d); }
    let p; try { p = new Uint32Array(g.getImageData(0, 0, d, d).data.buffer); } catch { p = new Uint32Array(d * d).fill(muCol(T.ACCENT)); }
    for (let i = 0; i < p.length; i++) p[i] = (p[i] & 0xffe0e0e0 | 0xff101010) >>> 0;  // 8 niveaux par couleur : l'aspect pixel art
    cache.set(k, {d, t: T, p}); return p;
  }
  function muPixBuf(key, W, H) {  // une petite image réutilisée d'une image à l'autre
    let b = mp[key]; if (!b || b.W !== W || b.H !== H) { const c = document.createElement('canvas'); c.width = W; c.height = H; const id = c.getContext('2d').createImageData(W, H); b = mp[key] = {W, H, c, id, P: new Uint32Array(id.data.buffer)}; }
    b.P.fill(0); return b;
  }
  function muPixKit(b) {
    const {W, H, P} = b, put = (x, y, c) => { x = Math.round(x); y = Math.round(y); if (x >= 0 && y >= 0 && x < W && y < H) P[y * W + x] = c; };
    const rect = (x, y, w, h, c) => { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) put(x + i, y + j, c); };
    const disc = (cx, cy, r, c) => { for (let y = -r; y <= r; y++) for (let x = -r; x <= r; x++) if (x * x + y * y <= r * r + r * .8) put(cx + x, cy + y, c); };
    const line = (x0, y0, x1, y1, c, t = 1) => { const n = Math.max(1, Math.round(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)))); for (let i = 0; i <= n; i++) rect(Math.round(x0 + (x1 - x0) * i / n) - (t >> 1), Math.round(y0 + (y1 - y0) * i / n) - (t >> 1), t, t, c); };
    return {put, rect, disc, line};
  }
  function muPixRecord(b, cx, cy, R, angle, img) {  // le disque : étiquette = pochette qui tourne, sillons en deux tons, reflet fixe tramé
    const {put} = muPixKit(b), a = angle * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a), lr = muLabelR(R), d = lr * 2, L = muPixLabel(img, d);
    const base = muBlend('#0e0b14', muBlend(T.CARD, T.ACCENT, .3), .22), c0 = muCol(base), c1 = muCol(muShade(base, .08)), cGap = muCol(muShade(base, -.4)), cHi = muCol(muShade(base, .3)), cRim = muCol(muShade(base, .22)), cLip = muCol(muShade(base, -.3));
    for (let y = -R; y <= R; y++) for (let x = -R; x <= R; x++) {
      const d2 = x * x + y * y; if (d2 > R * R + R * .8) continue;
      const r = Math.sqrt(d2); let c;
      if (r <= lr - .5) { const u = Math.max(0, Math.min(d - 1, Math.round(x * ca + y * sa + lr - .5))), v = Math.max(0, Math.min(d - 1, Math.round(-x * sa + y * ca + lr - .5))); c = L[v * d + u]; }
      else if (r < lr + 1) c = cLip;
      else if (r > R - 1) c = cRim;
      else {
        const k = Math.round(r); c = k % 2 ? c0 : c1;
        if (k === Math.round(lr + (R - lr) * .45) || k === Math.round(lr + (R - lr) * .75)) c = cGap;  // les silences entre les plages
        const th = Math.atan2(y, x), sec = Math.min(Math.abs(th + 2.3), Math.abs(th - .84));  // la lumière ne tourne pas avec le disque
        if (sec < .12 || (sec < .24 && (x + y & 1))) c = cHi;
      }
      put(cx + x, cy + y, c);
    }
    put(cx, cy, muCol('#e8eaf0'));  // l'axe
  }
  function muPixShow(g, b, w, h, s) {  // la petite image, agrandie d'un facteur entier, au centre
    b.c.getContext('2d').putImageData(b.id, 0, 0);
    const ox = Math.floor((w - b.W * s) / 2), oy = Math.floor((h - b.H * s) / 2);
    g.imageSmoothingEnabled = false; g.drawImage(b.c, ox, oy, b.W * s, b.H * s);
    return [ox, oy];
  }
  function muSharpLabel(g, x, y, r, angle, img, s) {  // la pochette au centre du disque : nette (pas en pixels), elle tourne avec lui
    if (!img) return;
    const k = Math.min(img.width, img.height);
    g.save(); g.translate(x, y); g.rotate(angle * Math.PI / 180); g.beginPath(); g.arc(0, 0, r, 0, 7); g.clip();
    g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high'; g.drawImage(img, (img.width - k) / 2, (img.height - k) / 2, k, k, -r, -r, r * 2, r * 2);
    g.restore();
    g.fillStyle = '#0b0a10'; g.fillRect(Math.round(x - s * 1.5), Math.round(y - s * 1.5), s * 3, s * 3); g.fillStyle = '#e8eaf0'; g.fillRect(Math.round(x - s / 2), Math.round(y - s / 2), s, s);  // l'axe
  }
  const muLabelR = R => Math.max(3, Math.round(R * .42));
  function muDeck(g, w, h, now, playing) {
    const s = Math.max(2, Math.round(h / 80)), W = Math.floor(w / s), H = Math.floor(h / s), b = muPixBuf('pxDeck', W, H), {put, rect, disc, line} = muPixKit(b);
    const DK = muDeckKit(), tc = c => c === 'A' ? T.ACCENT : c === 'B' ? T.ACCENT_2 || T.ACCENT : c;
    mp.coverOld = null;
    // le socle : bloc plat, liseré clair en haut, bande de couleur en bas, coins coupés ; la matière dépend de la platine
    const base = (DK.mat ? DK.mat[0] : muShade(muBlend(T.CARD, T.ACCENT, .2), -.3)), cB = muCol(base), cBd = muCol(muShade(base, -.5));
    const OL = muCol(muShade(T.CARD, -.88));
    rect(1, 0, W - 2, H, OL); rect(0, 1, W, H - 2, OL);  // le contour
    rect(1, 1, W - 2, H - 2, cB);
    if (DK.mat) { const C = DK.mat.map(muCol); for (let y = 1; y < H - 4; y++) for (let x = 1; x < W - 1; x++) put(x, y, C[Math.abs(Math.floor(y / 2 + Math.sin(x * .07 + y * .9) * 1.3)) % 3]); }  // les veines du bois ou de la pierre
    rect(2, 1, W - 4, 1, muCol(muShade(base, .3)));
    rect(1, H - 4, W - 2, 1, muCol(tc(DK.band || T.ACCENT)));
    rect(1, H - 3, W - 2, 2, cBd);
    // le plateau : ombre, bord métallique, points stroboscopiques qui tournent
    const pad = Math.round(H * .08), Rp = Math.floor(H / 2 - pad), cx = pad + Rp + 2, cy = Math.floor((H - 3) / 2), R = Rp - 2;
    const rim = DK.rim ? DK.rim.map(tc) : [muBlend('#d4d7e0', T.ACCENT, .25), muBlend('#7d808e', T.ACCENT, .25)];
    disc(cx + 1, cy + 2, Rp + 1, cBd); disc(cx, cy, Rp + 1, OL); disc(cx, cy, Rp, muCol(rim[1])); disc(cx, cy, Rp - 1, muCol(muShade(T.CARD, -.78)));
    for (let i = 0; i < 24; i++) { const t = (mp.deckAng + i * 15) * Math.PI / 180; put(cx + Math.cos(t) * Rp, cy + Math.sin(t) * Rp, muCol(i % 2 ? rim[0] : muShade(rim[1], -.4))); }
    muPixRecord(b, cx, cy, R, mp.deckAng, mp.coverImg);
    // le bras : pivot à droite, il se pose sur le bord et avance vers l'étiquette avec le morceau
    const pvx = Math.round(Math.min(W - pad - 5, cx + Rp + (W - cx - Rp) * .55)), pvy = Math.round(pad + H * .14), dx = cx - pvx, dy = cy - pvy, D = Math.hypot(dx, dy), Lr = D * .93;
    const at = rho => { const c = Math.max(-1, Math.min(1, (D * D + Lr * Lr - rho * rho) / (2 * D * Lr))); return Math.atan2(dy, dx) - Math.acos(c); };
    const dur = muAudio?.duration || mp.length || 0, pos = muAudio?.currentTime || mp.resume || 0, prog = dur ? Math.max(0, Math.min(1, pos / dur)) : 0;
    const target = mp.cur ? at(R * .94 - (R * .94 - R * .45) * prog) : at(R * 1.25);
    const dt = Math.min(64, now - (mp.armAt || now)); mp.armAt = now;
    mp.arm = mp.arm == null ? at(R * 1.25) : mp.arm + (target - mp.arm) * Math.min(1, dt * .006);
    mp.lift = (mp.lift ?? 1) + ((playing ? 0 : 1) - (mp.lift ?? 1)) * Math.min(1, dt * .008);
    const metal = DK.metal ? DK.metal.map(tc) : ['#f2f3f7', '#a4a7b4', '#4a4d5c'];
    const arm = sh => {
      const o = sh ? 1 + Math.round(mp.lift * 2) : 0, A = mp.arm, ax = pvx + o, ay = pvy + o, sx = pvx + Math.cos(A) * Lr + o, sy = pvy + Math.sin(A) * Lr + o;
      const hx = sx - Math.cos(A) * 4, hy = sy - Math.sin(A) * 4;
      line(ax - Math.cos(A) * 2, ay - Math.sin(A) * 2, ax - Math.cos(A) * 5, ay - Math.sin(A) * 5, muCol(sh ? '#000' : metal[2]), 4);  // contrepoids
      line(ax, ay, hx, hy, muCol(sh ? '#000' : metal[1]), 2); if (!sh) line(ax, ay - 1, hx, hy - 1, muCol(metal[0]), 1);  // le tube, éclairé dessus
      line(hx, hy, sx, sy, muCol(sh ? '#000' : '#1d1d24'), 3); if (!sh) put(hx + (sx - hx) * .5, hy + (sy - hy) * .5, muCol(T.ACCENT));  // la tête de lecture
    };
    { const A = mp.arm, sx = pvx + Math.cos(A) * Lr, sy = pvy + Math.sin(A) * Lr, hx = sx - Math.cos(A) * 4, hy = sy - Math.sin(A) * 4;  // le contour du bras
      if (mp.lift > .05) arm(true);
      line(pvx - Math.cos(A) * 2, pvy - Math.sin(A) * 2, pvx - Math.cos(A) * 5, pvy - Math.sin(A) * 5, OL, 6); line(pvx, pvy, hx, hy, OL, 4); line(hx, hy, sx, sy, OL, 5); }
    arm(false);
    disc(pvx + 1, pvy + 1, 4, cBd); disc(pvx, pvy, 4, OL); disc(pvx, pvy, 3, muCol(metal[1])); put(pvx - 1, pvy - 1, muCol(metal[0])); put(pvx - 2, pvy, muCol(metal[0])); rect(pvx, pvy, 1, 1, muCol('#23232b'));  // le pivot
    // le voyant et la vitesse en points
    const lx = W - pad - 3, ly = H - pad - 4;
    rect(lx - 1, ly - 1, 4, 4, OL); rect(lx, ly, 2, 2, muCol(playing ? T.ACCENT_2 || T.ACCENT : '#3a3a44'));
    for (let i = 0; i < 3; i++) put(lx - 4 - i * 2, ly + 1, muCol(i ? '#4a4d5c' : '#c9ccd6'));
    const [ox, oy] = muPixShow(g, b, w, h, s), lr = muLabelR(R);
    muSharpLabel(g, ox + (cx + .5) * s, oy + (cy + .5) * s, (lr - .5) * s, mp.deckAng, mp.coverImg, s);
  }
  function muSpin(now) {  // the record speeds up fast and slows down like a real turntable (shared by the big cover and the portable player)
    const playing = muAudio && !muAudio.paused;
    mp.spin = playing ? Math.min(1.4, (mp.spin || 0) + .35) : (mp.spin || 0) * .9 < .01 ? 0 : (mp.spin || 0) * .9;
    const dt = now - (mp.coverAt || now);
    mp.angle = ((mp.angle || 0) + (mp.spin || 0) * dt / 70) % 360; mp.coverAt = now;
    mp.deckAng = ((mp.deckAng || 0) + (mp.spin || 0) / 1.4 * MU_RPM * dt / 1000) % 360;
  }
  // platine:fin
  function muDrawCover(now) {
    const cv = $('muCover'), r = cv.getBoundingClientRect(), k = devicePixelRatio || 1, w = Math.round(r.width * k), h = Math.round(r.height * k);
    if (!w || !h) return;
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    const g = cv.getContext('2d'); g.imageSmoothingEnabled = true; g.clearRect(0, 0, w, h);
    if (mu.settings.vinyl && muLevel().level >= 150) return muDeck(g, w, h, now, !!(muAudio && !muAudio.paused));
    if (mu.settings.vinyl) {  // le disque seul, cerclé de la couleur du thème, comme dans le petit lecteur
      const s = Math.max(2, Math.round(h / 80)), n = Math.floor(h / s) | 1, c = n >> 1, b = muPixBuf('pxRec', n, n), {disc} = muPixKit(b);
      mp.coverOld = null; disc(c, c, c, muCol(T.ACCENT)); muPixRecord(b, c, c, c - 2, mp.deckAng || 0, mp.coverImg);
      const [ox, oy] = muPixShow(g, b, w, h, s); return muSharpLabel(g, ox + (c + .5) * s, oy + (c + .5) * s, (muLabelR(c - 2) - .5) * s, mp.deckAng || 0, mp.coverImg, s);
    }
    const W = Math.min(w, h), fade = mp.coverOld ? Math.min(1, (now - mp.fadeAt) / 180) : 1;
    const paint = (img, alpha) => {
      g.globalAlpha = alpha;
      if (img) { const s = Math.min(img.width, img.height); g.imageSmoothingQuality = 'high'; g.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, W * .03, W * .03, W * .94, W * .94); }
      else { g.fillStyle = T.CARD_ALT; g.fillRect(W * .03, W * .03, W * .94, W * .94); g.fillStyle = T.ACCENT; g.font = `bold ${Math.round(W * .3)}px Consolas`; g.textAlign = 'center'; g.fillText('?', W / 2, W / 2 + W * .1); }
      g.globalAlpha = 1;
    };
    if (fade < 1 && mp.coverOld) paint(mp.coverOld.img, 1 - fade); else mp.coverOld = null;
    paint(mp.coverImg, fade);
  }
  function muProgressEvents() {
    const cv = $('muProgress'), at = e => { const r = cv.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * (muAudio?.duration || mp.length); };
    cv.onpointerdown = e => { if (!mp.cur) return; cv.setPointerCapture(e.pointerId); mp.seeking = at(e); muDrawProgress(); };
    cv.onpointermove = e => { if (!mp.cur || !(muAudio?.duration || mp.length)) return; mp.preview = at(e); if (mp.seeking != null) mp.seeking = mp.preview; muDrawProgress(); };
    cv.onpointerup = e => { if (mp.seeking == null) return; const s = at(e); mp.seeking = null; muSeek(s); };
    cv.onpointerleave = () => { mp.preview = null; muDrawProgress(); };
  }
  function muDrawProgress(geom) {
    const cv = $('muProgress'); if (!cv) return;
    const w = Math.round(cv.clientWidth * devicePixelRatio), h = Math.round(36 * devicePixelRatio);
    if (geom || cv.width !== w) { cv.width = w; cv.height = h; }
    const g = cv.getContext('2d'), dur = muAudio?.duration || mp.length || 0, pos = mp.seeking ?? mp.preview ?? (muAudio?.currentTime || mp.resume || 0);
    const ratio = dur ? Math.max(0, Math.min(1, pos / dur)) : 0, k = devicePixelRatio;
    g.clearRect(0, 0, w, h);
    $('muTime').textContent = muClock(pos) + ' / ' + muClock(dur);
    const levels = mu.settings.waveform && mp.cur ? muCache[muId(mp.cur)]?.w : null;
    if (mu.settings.pixelUi) {  // pixel mode: blocks snapped to a 3-px grid, stepped heights, light cap on the played part, a blinking playhead block
      const P = 3 * k, rows = Math.floor(h / P), cols = Math.floor(w / (2 * P)), mid = rows / 2, done = Math.floor(cols * ratio);
      if (!levels) {  // no waveform: a chunky bar of 4-row blocks with a lit top row, a dark foot row and a white playhead block
        const y0 = Math.round((rows - 4) / 2 * P);
        for (let i = 0; i < cols; i++) {
          const played = i < done, x = i * 2 * P;
          for (let r = 0; r < 4; r++) { g.fillStyle = played ? (r === 0 ? muBlend(T.ACCENT, '#ffffff', .55) : r === 3 ? muShade(T.ACCENT, -.35) : T.ACCENT) : (r === 0 ? muBlend(T.CARD_ALT, T.ACCENT, .3) : r === 3 ? muShade(T.CARD_ALT, -.3) : T.CARD_ALT); g.fillRect(x, y0 + r * P, P * 2, P); }
        }
        if (dur) { g.fillStyle = '#ffffff'; g.fillRect(Math.min(cols - 1, done) * 2 * P - P / 2, y0 - P, 2 * P, 6 * P); }
        return;
      }
      for (let i = 0; i < cols; i++) {
        const lv = levels ? levels[Math.min(levels.length - 1, Math.floor(i * levels.length / cols))] : .12, half = Math.max(1, Math.round(lv * mid)), x = i * 2 * P, played = i < done;
        for (let r = 0; r < half * 2; r++) {
          const edge = r === 0 || r === half * 2 - 1;
          g.fillStyle = played ? (edge ? muBlend(T.ACCENT, '#ffffff', .55) : r < half ? T.ACCENT : muShade(T.ACCENT, -.25)) : (edge ? muBlend(T.CARD_ALT, T.ACCENT, .35) : T.CARD_ALT);
          g.fillRect(x, Math.round((mid - half + r) * P), P, P);
        }
      }
      if (dur && (Math.floor(Date.now() / 450) & 1 || !muAudio || muAudio.paused)) { g.fillStyle = '#ffffff'; g.fillRect(Math.min(cols - 1, done) * 2 * P - P / 2, 0, P, rows * P); }
      return;
    }
    if (!levels) {  // a plain bar, like MuPlayer without a waveform
      g.fillStyle = T.CARD_ALT; g.fillRect(0, h / 2 - 3 * k, w, 6 * k); g.fillStyle = T.ACCENT; g.fillRect(0, h / 2 - 3 * k, w * ratio, 6 * k); return;
    }
    const bw = 3 * k, gap = 2 * k, n = Math.max(1, Math.floor(w / (bw + gap)));
    for (let i = 0; i < n; i++) {
      const lv = levels[Math.min(levels.length - 1, Math.floor(i * levels.length / n))], bh = 3 * k + lv * (h - 3 * k), x = i * (bw + gap);
      g.fillStyle = x <= w * ratio ? T.ACCENT : T.CARD_ALT; g.fillRect(x, (h - bh) / 2, bw, bh);
    }
  }
  /* ---------- spectrum: 24 bands spread evenly over the octaves (40 Hz - 14 kHz), compared to the loudest one (MuPlayer's AGC) ---------- */
  const MU_SPEC_N = 24, MU_SPEC_EDGES = Array.from({length: MU_SPEC_N + 1}, (_, i) => 40 * 350 ** (i / MU_SPEC_N));
  const muSpec = {levels: Array(MU_SPEC_N).fill(0), ref: 1e-6, blockAt: 0, db: null};
  // every 64 ms like MuPlayer's spectrum_worker: the energy of each band (power summed over its bins, so the wide high bands are not
  // starved), +1.5 dB per octave because music carries less energy up high, divided by a slowly falling reference = the loudest band;
  // then fast attack / soft release (old * .6 + new * .4). Only the bands that really sound rise.
  function muSpectrumBlock() {
    const a = muNodes.analyser, db = muSpec.db ||= new Float32Array(a.frequencyBinCount), hz = muCtx.sampleRate / a.fftSize;
    a.getFloatFrequencyData(db);
    const mags = [];
    for (let b = 0; b < MU_SPEC_N; b++) {
      const lo = MU_SPEC_EDGES[b], hi = MU_SPEC_EDGES[b + 1], j0 = Math.max(1, Math.round(lo / hz)), j1 = Math.max(j0 + 1, Math.round(hi / hz));
      let p = 0;
      for (let j = j0; j < j1; j++) p += 10 ** (db[j] / 10) || 0;
      mags.push(Math.sqrt(p) * 1.19 ** Math.log2(Math.sqrt(lo * hi) / 40));
    }
    muSpec.ref = Math.max(muSpec.ref * .995, ...mags, 1e-6);
    // hearing-like curve (quiet bands still show) with a gate: under 6 % of the loudest band a bar stays down, so nothing rises for nothing
    muSpec.levels = mags.map((m, i) => { const r = m / muSpec.ref, n = r < .06 ? 0 : Math.min(1, ((r - .06) / .94) ** .55), o = muSpec.levels[i]; return n > o ? n : o * .6 + n * .4; });
  }
  // pixel-art bars, drawn at the size of the art pixels then scaled up without smoothing: each bar has 4 colour tiers from its foot to
  // its top (dithered where they meet), a light left edge and a dark right edge for the relief, a bright cap, a peak marker that holds
  // then falls, a hard pixel drop shadow (1 then 2 pixels down-right, the second fainter), and a faint dotted grid behind.
  // Hue sweeps ACCENT -> DANGER -> ACCENT_2 like MuPlayer.
  // SUPER VISUALISER (level 100): taller, hue that drifts along the bars, light-to-bright bars with a bright cap, glow, a mirrored fading reflection,
  // a floor line that pulses with the bass and sparks that fly off the peaks
  function muSuperSpectrum(cv, cssH, now) {
    const avail = muInner(cv.parentElement); if (!avail) return;
    const P = Math.max(2, Math.round(3 * devicePixelRatio)) / devicePixelRatio, cols = Math.floor(avail / P), rows = Math.floor(cssH / P);
    if (cv.width !== cols || cv.height !== rows) { cv.width = cols; cv.height = rows; cv.style.width = cols * P + 'px'; cv.style.height = rows * P + 'px'; }
    const g = cv.getContext('2d'), playing = muAudio && !muAudio.paused, t = now / 1000, L = muSpec.levels;
    const N = Math.max(16, Math.min(64, Math.floor(cols / 5))), bw = Math.floor(cols / N), inner = Math.max(2, bw - 1), off = Math.floor((cols - N * bw) / 2) + Math.floor((bw - inner) / 2);
    const Hb = Math.floor(rows * .66), base = 2 + Hb, refl = rows - base - 1;
    const s = cv._sup ||= {}; if (s.n !== N) Object.assign(s, {n: N, display: Array(N).fill(0), peaks: Array(N).fill(0), sparks: [], pulse: 0});
    const dt = Math.min(.1, (now - (s.at || now)) / 1000); s.at = now;
    s.pulse = Math.max(playing && (L[0] + L[1] + L[2]) / 3 > .55 ? 1 : 0, s.pulse - dt * 4);
    const down = 1 - .0005 ** dt, hue = f => { f = (f % 1 + 1) % 1; return f < 1 / 3 ? muBlend(T.ACCENT, T.DANGER, f * 3) : f < 2 / 3 ? muBlend(T.DANGER, T.ACCENT_2, f * 3 - 1) : muBlend(T.ACCENT_2, T.ACCENT, f * 3 - 2); };
    g.clearRect(0, 0, cols, rows);
    g.fillStyle = muBlend(T.CARD_ALT, T.ACCENT, .3 + .6 * s.pulse); g.fillRect(0, base, cols, 1);
    for (let i = 0; i < N; i++) {
      const pos = i / Math.max(1, N - 1) * (L.length - 1), lo = Math.floor(pos), hi = Math.min(L.length - 1, lo + 1);
      const raw = playing ? Math.max(0, Math.min(1, L[lo] * (1 - (pos - lo)) + L[hi] * (pos - lo))) : 0, target = playing ? raw : .04 + .03 * Math.sin(t * 2 + i * .45);
      s.display[i] = target > s.display[i] ? target : s.display[i] + (target - s.display[i]) * down; if (!(s.display[i] >= 0)) s.display[i] = 0;
      s.peaks[i] = Math.max(raw, s.peaks[i] - dt * .8);
      const x = off + i * bw, h = Math.max(1, Math.min(Hb, Math.round(s.display[i] * Hb))), col = hue(i / Math.max(1, N - 1) * .9 + t * .06);
      if (raw > .45 && raw >= s.peaks[i] - 1e-4 && s.sparks.length < 140 && Math.random() < .3) s.sparks.push({x: x + inner / 2, y: base - h, vx: (Math.random() - .5) * 14, vy: -(8 + Math.random() * 18), life: 1, c: muBlend(col, '#ffffff', .6)});
      g.globalAlpha = .13 + .1 * s.pulse; g.fillStyle = col; g.fillRect(x - 1, base - h - 1, inner + 2, h + 2); g.globalAlpha = 1;
      for (let r = 0; r < h; r++) { g.fillStyle = muBlend(col, '#ffffff', r / Hb * .45); g.fillRect(x, base - 1 - r, inner, 1); }
      if (inner > 2) { g.fillStyle = muBlend(col, '#ffffff', .5); g.fillRect(x, base - h, 1, h); g.fillStyle = muShade(col, -.35); g.fillRect(x + inner - 1, base - h, 1, h); }
      g.fillStyle = muBlend(col, '#ffffff', .85); g.fillRect(x, base - h - 1, inner, 1);
      const py = base - 2 - Math.round(s.peaks[i] * Hb); if (py < base - h - 3) { g.fillStyle = muBlend(col, '#ffffff', .6); g.fillRect(x, py, inner, 1); }
      for (let r = 0; r < Math.min(h, refl); r++) { g.globalAlpha = .34 * (1 - r / Math.max(1, refl)) ** 1.6; g.fillStyle = muBlend(col, '#ffffff', r / Hb * .3); g.fillRect(x, base + 1 + r, inner, 1); }
      g.globalAlpha = 1;
    }
    s.sparks = s.sparks.filter(p => (p.life -= dt * 1.5) > 0 && p.y < base + 1);
    for (const p of s.sparks) { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 38 * dt; g.globalAlpha = Math.max(0, p.life); g.fillStyle = p.c; g.fillRect(Math.round(p.x), Math.round(p.y), 1, 1); }
    g.globalAlpha = 1;
  }
  const muSuperOn = now => { if (now - (mp.supAt || -1e9) > 2000) { mp.supAt = now; mp.supOn = !!mu.settings.superVis && muLevel().level >= 100; } return mp.supOn; };
  // platine:début (recopié tel quel dans widget.js par tools/widget-sync.js)
  const muInner = e => { if (!e) return 0; const cs = getComputedStyle(e); return e.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight); };  // largeur sans le rembourrage (l'écran du Deluxe en a)
  function muPixSpectrum(cv, cssH, now) {
    const avail = muInner(cv.parentElement); if (!avail) return;
    const P = Math.max(2, Math.round(3 * devicePixelRatio)) / devicePixelRatio, cols = Math.floor(avail / P), rows = Math.floor(cssH / P);
    if (cv.width !== cols || cv.height !== rows) { cv.width = cols; cv.height = rows; cv.style.width = cols * P + 'px'; cv.style.height = rows * P + 'px'; }
    const s = cv._s ||= {}, g = cv.getContext('2d'), playing = muAudio && !muAudio.paused;
    const N = Math.max(12, Math.min(48, Math.floor(cols / 6))), bw = Math.floor(cols / N), inner = Math.max(2, bw - (bw > 4 ? 2 : 1)), off = Math.floor((cols - N * bw) / 2) + Math.floor((bw - inner) / 2);
    const base = rows - 2, Hb = base;  // the 2 last rows hold the shadow
    if (s.n !== N) { s.n = N; s.display = Array(N).fill(0); s.peaks = Array(N).fill(0); s.peakAt = Array(N).fill(0); s.key = ''; }
    if (s.key !== T.ACCENT + T.DANGER + T.ACCENT_2) {
      s.key = T.ACCENT + T.DANGER + T.ACCENT_2;
      s.cols = Array.from({length: N}, (_, i) => {
        const f = i / Math.max(1, N - 1), hue = f < .5 ? muBlend(T.ACCENT, T.DANGER, f * 2) : muBlend(T.DANGER, T.ACCENT_2, f * 2 - 1);
        const tiers = [muShade(hue, -.38), muShade(hue, -.15), hue, muBlend(hue, '#ffffff', .3)];
        return {tiers: tiers.map(c => [c, muBlend(c, '#ffffff', .25), muShade(c, -.38)]), cap: muBlend(hue, '#ffffff', .7), peak: muBlend(hue, '#ffffff', .5)};
      });
    }
    const dt = Math.min(.25, (now - (s.at || now)) / 1000); s.at = now;
    const per = r => 1 - (1 - r) ** (dt / .25), up = per(.92), down = per(.25), fall = .55 ** (dt / .25), t = now / 1000, L = muSpec.levels;
    g.clearRect(0, 0, cols, rows);
    g.fillStyle = T.CARD_ALT;
    for (const q of [.25, .5, .75]) { const y = base - 1 - Math.round(q * (Hb - 1)); for (let x = (y & 1) * 2; x < cols; x += 4) g.fillRect(x, y, 1, 1); }  // dotted grid
    for (let i = 0; i < N; i++) {
      const pos = i / Math.max(1, N - 1) * (L.length - 1), lo = Math.floor(pos), hi = Math.min(L.length - 1, lo + 1);
      const raw = playing ? Math.max(0, Math.min(1, L[lo] * (1 - (pos - lo)) + L[hi] * (pos - lo))) : 0;
      const target = playing ? raw : .05 + .04 * (1 + Math.sin(t * 2.2 + i * .5)) / 2;  // at rest: a slow breathing wave instead of a flat line
      s.display[i] = target > s.display[i] ? target : s.display[i] + (target - s.display[i]) * down; if (!(s.display[i] >= 0)) s.display[i] = 0;
      if (raw >= s.peaks[i]) { s.peaks[i] = raw; s.peakAt[i] = t; } else if (t - s.peakAt[i] > .12) s.peaks[i] *= fall;
      const c = s.cols[i], x = off + i * bw, h = Math.max(1, Math.min(Hb, Math.round(s.display[i] * Hb)));
      const top = base - h, py = s.peaks[i] > .06 ? base - 1 - Math.min(Hb - 1, Math.round(s.peaks[i] * Hb)) : -1, peak = py >= 0 && py < top;
      g.fillStyle = 'rgba(0, 0, 0, .2)'; g.fillRect(x + 2, top + 2, inner, h); if (peak) g.fillRect(x + 2, py + 2, inner, 1);  // drop shadow
      g.fillStyle = 'rgba(0, 0, 0, .42)'; g.fillRect(x + 1, top + 1, inner, h); if (peak) g.fillRect(x + 1, py + 1, inner, 1);
      for (let r = 0; r < h; r++) {
        const y = base - 1 - r, tier = Math.min(3, Math.floor(r / Hb * 4)), edge = tier > 0 && Math.floor((r - 1) / Hb * 4) < tier;
        const [main, light, dark] = c.tiers[tier];
        if (r === h - 1 && h > 1) { g.fillStyle = c.cap; g.fillRect(x, y, inner, 1); continue; }
        g.fillStyle = main; g.fillRect(x, y, inner, 1);
        if (edge) { g.fillStyle = c.tiers[tier - 1][0]; for (let k = (y & 1); k < inner; k += 2) g.fillRect(x + k, y, 1, 1); }  // dither between tiers
        if (inner > 2) { g.fillStyle = light; g.fillRect(x, y, 1, 1); g.fillStyle = dark; g.fillRect(x + inner - 1, y, 1, 1); }
      }
      if (peak) { g.fillStyle = c.peak; g.fillRect(x, py, inner, 1); }
    }
  }
  // platine:fin

  /* ---------- portable player: when NeoMusic's tab is left while a song plays, a small player stays in a corner of NeoDex ---------- */
  const MU_PIX = {
    prevt: ['##....#', '##...##', '##..###', '##.####', '##..###', '##...##', '##....#'],
    heart: ['.##.##.', '#######', '#######', '#######', '.#####.', '..###..', '...#...'],
  };
  const muPixIcon = k => pixIcon(MU_PIX[k] || PIX[k]);
  function muMiniBuild() {
    const btn = (id, icon, title, fn) => mh('button.mmBtn#' + id, {title, html: muPixIcon(icon), onclick: e => { e.stopPropagation(); fn(); setTimeout(muMiniPaint, 80); }});
    const box = mh('div.muMini#muMini', {title: 'Glisser : déplacer · Clic : pause / lecture · Double-clic : revenir à NeoMusic · Molette : volume'},
      mh('canvas#mmAmb'), mh('canvas#mmDisc', {width: 184, height: 184}),
      mh('div.mmBody', {},
        mh('div.mmTop', {}, mh('span.mmKick', {text: 'NEOMUSIC'}), mh('span#mmState'),
          btn('mmBack', 'ext', 'Revenir à NeoMusic', () => muShowTab()), btn('mmClose', 'close', 'Fermer (met la musique en pause)', () => { muPause(); mp.miniOff = true; muMiniSync(); })),
        mh('b#mmTitle'), mh('span#mmArtist'),
        mh('div.mmSpecBox', {}, mh('canvas#mmSpec')),
        mh('div.mmBar', {}, mh('div#mmSeek', {title: 'Aller à ce moment'}, mh('i')), mh('span#mmTime')),
        mh('div.mmCtl', {}, btn('mmPrev', 'prevt', 'Morceau précédent', () => muPrev()), btn('mmPlay', 'pause', 'Lecture / pause', () => muToggle()), btn('mmNext', 'next', 'Morceau suivant', () => muNext()),
          btn('mmFav', 'heart', 'Favori', () => muToggleFav()), mh('span#mmVol'))));
    box.querySelector('#mmSeek').onclick = e => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); muSeek((e.clientX - r.left) / r.width * (muAudio?.duration || mp.length)); };
    box.onwheel = e => { e.preventDefault(); muSetVolume(mu.settings.volume + (e.deltaY < 0 ? .05 : -.05)); muMiniPaint(); };
    box.ondblclick = e => { if (!e.target.closest('button, #mmSeek')) muShowTab(); };
    box.onpointerdown = e => {  // drag to move (remembered), a plain click = pause / play, like the video mini player
      if (e.button || e.target.closest('button, #mmSeek')) return;
      const sx = e.screenX, sy = e.screenY, o = {...mp.miniPos}; let moved = false;
      box.setPointerCapture(e.pointerId);
      box.onpointermove = m => { if (!moved && Math.hypot(m.screenX - sx, m.screenY - sy) < 4) return; moved = true; box.classList.add('drag'); mp.miniPos = {x: o.x + m.screenX - sx, y: o.y + m.screenY - sy}; muMiniPlace(); };
      box.onpointerup = () => { box.onpointermove = box.onpointerup = null; box.classList.remove('drag'); if (moved) { try { localStorage.neoMusicMini = JSON.stringify(mp.miniPos); } catch {} } else { muToggle(); setTimeout(muMiniPaint, 80); } };
    };
    try { mp.miniPos = JSON.parse(localStorage.neoMusicMini || 'null'); } catch {}
    document.body.append(box);
    addEventListener('resize', () => mp.miniOn && muMiniPlace());
  }
  function muShowTab() { newTab('plugin:neodex.music'); }
  function muMiniPlace() {
    const box = $('muMini'), w = box.offsetWidth || 430, h = box.offsetHeight || 118;
    if (host.float) {  // dans le bac à sable de NeoDex : c'est la frame entière qui flotte dans un coin de NeoDex, NeoDex la garde dans la fenêtre
      const at = mp.miniPos; host.float({w, h, x: at?.x, y: at?.y}).then(p => { if (p && mp.miniOn) mp.miniPos = p; }).catch(() => {}); return;
    }
    if (!mp.miniPos) {  // first time: bottom right, above the video mini player if one is shown
      const vid = document.body.classList.contains('hasMini') ? parseFloat(getComputedStyle(document.body).getPropertyValue('--my')) : NaN;
      mp.miniPos = {x: innerWidth - w - 24, y: (isFinite(vid) ? vid - 18 : document.body.clientHeight - 24) - h};
    }
    mp.miniPos = {x: Math.round(Math.min(Math.max(mp.miniPos.x, 0), innerWidth - w)), y: Math.round(Math.min(Math.max(mp.miniPos.y, 46), document.body.clientHeight - h))};
    box.style.left = mp.miniPos.x + 'px'; box.style.top = mp.miniPos.y + 'px';
  }
  // shown when NeoMusic's tab is not the one on screen and a song plays (then it stays while paused); its X pauses and hides it until NeoMusic is shown again
  function muMiniSync() {
    const box = $('muMini'); if (!box) return;
    const away = !view.classList.contains('on'), playing = muAudio && !muAudio.paused && muAudio.currentTime > 0;  // sound really came out: a song still loading or that never started is no reason to appear
    if (!away) mp.miniOff = false;
    const homeW = document.body.classList.contains('homeW');  // l'accueil est affiché avec le widget de NeoMusic : il fait déjà le petit lecteur
    const show = away && !homeW && !!mp.cur && !mp.miniOff && host.pref('pip') !== false && (playing || mp.miniOn);
    const appear = show && !mp.miniOn;
    box.classList.toggle('on', show);
    if (host.float && show !== mp.miniOn) { document.body.classList.toggle('mmFloat', show); if (!show) host.float(null).catch(() => {}); }
    mp.miniOn = show;
    if (appear) { muMiniPaint(); muMiniPlace(); }  // filled first: its height is only known with its text
    if (show) muMiniPaint();
  }
  function muMiniPaint() {
    if (!mp.miniOn || !mp.cur) return;
    const t = mp.cur, playing = muAudio && !muAudio.paused, fav = muIsFav(t);
    $('muMini').classList.toggle('deck', !!mu.settings.vinyl && muLevel().level >= 150);  // avant muMiniPlace : sa taille en dépend
    $('mmTitle').textContent = t.display_title || t.file; $('mmArtist').textContent = t.author || muPlaylistOf(t)?.name || '';
    $('mmState').textContent = playing ? '· LECTURE' : '· PAUSE'; $('mmState').style.color = playing ? T.ACCENT_2 : T.WARN;
    $('mmPlay').innerHTML = muPixIcon(playing ? 'pause' : 'play');
    $('mmFav').classList.toggle('on', fav); $('mmFav').title = fav ? 'Retirer des favoris' : 'Ajouter aux favoris';
    $('mmVol').textContent = 'VOL ' + Math.round(mu.settings.volume * 100) + ' %';
  }
  function muMiniFrame(now) {
    const on = muAmbSmallOn(); $('muMini').classList.toggle('amb', on); if (on) muAmbSmall(muAmbMini, $('muMini'), $('mmAmb'), $('mu').dataset.ms || 'nova', T, muBass(), now);
    const cv = $('mmDisc'), deck = $('muMini').classList.contains('deck');
    if (deck) {  // la même platine que dans NeoMusic, dessinée à la taille réelle du canevas
      const r = cv.getBoundingClientRect(), k = devicePixelRatio || 1, w = Math.round(r.width * k), h = Math.round(r.height * k);
      if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
      const g = cv.getContext('2d'); g.clearRect(0, 0, w, h); if (w && h) muDeck(g, w, h, now, !!(muAudio && !muAudio.paused));
    } else {
      if (cv.width !== 184 || cv.height !== 184) cv.width = cv.height = 184;  // retour au disque seul : la taille d'origine
      const g = cv.getContext('2d'), W = cv.width; g.clearRect(0, 0, W, W);
      if (mu.settings.vinyl) {
        const b = muPixBuf('pxMini', 46, 46), {disc} = muPixKit(b);  // le même disque en pixels, cerclé de la couleur du thème
        disc(23, 23, 22, muCol(T.ACCENT)); muPixRecord(b, 23, 23, 20, mp.deckAng || 0, mp.coverImg); const [ox, oy] = muPixShow(g, b, W, W, 4); muSharpLabel(g, ox + 23.5 * 4, oy + 23.5 * 4, (muLabelR(20) - .5) * 4, mp.deckAng || 0, mp.coverImg, 4);
      } else if (mp.coverImg) { const im = mp.coverImg, s = Math.min(im.width, im.height); g.drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, W, W); }
      else { g.fillStyle = T.CARD_ALT; g.fillRect(0, 0, W, W); g.fillStyle = T.ACCENT; g.font = 'bold 80px Consolas'; g.textAlign = 'center'; g.fillText('?', W / 2, W / 2 + 28); }
    }
    const sup = muSuperOn(now); $('mmSpec').parentElement.classList.toggle('sup', sup);  // the super visualiser follows into the portable player
    if (sup) muSuperSpectrum($('mmSpec'), 39, now); else muPixSpectrum($('mmSpec'), 21, now);
    const dur = muAudio?.duration || mp.length || 0, pos = muAudio?.currentTime || mp.resume || 0;
    $('mmSeek').firstChild.style.width = (dur ? Math.min(100, pos / dur * 100) : 0) + '%';
    $('mmTime').textContent = muClock(pos) + ' / ' + muClock(dur);
  }
  // platine:début (recopié tel quel dans widget.js par tools/widget-sync.js : le widget dessine aussi l'ambiance)
  /* ---------- l'ambiance du thème : une petite scène en pixels derrière l'appli (ciel, décor, particules en profondeur), qui réagit aux basses ---------- */
  // une toile au tiers de la taille de la page, 30 images par seconde au plus ; le décor fixe (ciel, silhouettes) est peint une fois, puis recopié à chaque image
  const MU_AMB = {nova: 'space', onyx: 'night', grenat: 'bokeh', aube: 'dawn', ambre: 'shafts', abyme: 'abyss', sakura: 'sakura', crepuscule: 'dusk', menthe: 'fizz',
    rubis: 'gems', glacier: 'aurora', cuivre: 'forge', lavande: 'meadow', foret: 'forest', ocean: 'sea', soleil: 'sun', cyber: 'code', neon: 'synth'};
  const muAmb = {at: 0, ms: '', parts: [], fx: [], e: 0, t: 0, kick: 0, avg: 0, kAt: 0, gust: 0, spr: new Map()};
  const muMix = (a, b, f) => { const A = muHex(a), B = muHex(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * f).toString(16).padStart(2, '0')).join(''); };
  const muClamp01 = v => Math.max(0, Math.min(1, v));
  const muSeed = a => () => { a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };  // le même tirage à chaque fois (le décor ne change pas d'une ouverture à l'autre)
  const muRgba = (c, a) => 'rgba(' + muHex(c).join(',') + ',' + a + ')';
  function muSpr(rows, c, c2) {  // un petit dessin en pixels : '#' la couleur, '+' la couleur à moitié, 'o' la seconde couleur
    const k = rows + c + c2; let s = muAmb.spr.get(k); if (s) return s;
    const R = rows.split('|'); s = document.createElement('canvas'); s.width = R[0].length; s.height = R.length; const g = s.getContext('2d');
    R.forEach((row, y) => [...row].forEach((ch, x) => { if (ch === '.') return; g.globalAlpha = ch === '+' ? .45 : 1; g.fillStyle = ch === 'o' ? c2 || '#fff' : c; g.fillRect(x, y, 1, 1); }));
    muAmb.spr.set(k, s); return s;
  }
  function muGlow(c, r) {  // un halo en anneaux (des paliers nets, pas un flou), r en pixels de la toile
    const k = 'g' + c + r; let s = muAmb.spr.get(k); if (s) return s;
    s = document.createElement('canvas'); s.width = s.height = r * 2 + 1; const g = s.getContext('2d'); g.fillStyle = c;
    for (let i = r; i >= 1; i--) { g.globalAlpha = .16 * (1 - i / (r + 1)) + .05; g.beginPath(); g.arc(r + .5, r + .5, i, 0, 7); g.fill(); }
    muAmb.spr.set(k, s); return s;
  }
  function muVGrad(c) {  // une bande verticale qui s'allume au milieu (les aurores, les rayons)
    const k = 'v' + c; let s = muAmb.spr.get(k); if (s) return s;
    s = document.createElement('canvas'); s.width = 1; s.height = 32; const g = s.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 32);
    gr.addColorStop(0, muRgba(c, 0)); gr.addColorStop(.6, muRgba(c, 1)); gr.addColorStop(1, muRgba(c, 0)); g.fillStyle = gr; g.fillRect(0, 0, 1, 32);
    muAmb.spr.set(k, s); return s;
  }
  // le décor fixe : un ciel en bandes (dégradé à paliers, façon pixel art), des reliefs et des silhouettes
  const muSky = (g, W, y0, y1, c0, c1, step = 3) => { for (let y = y0; y < y1; y += step) { g.fillStyle = muMix(c0, c1, (y - y0) / Math.max(1, y1 - y0)); g.fillRect(0, y, W, step); } };
  const muRidgeY = (x, base, amp, seed, rough = 1) => Math.round(base - amp * (.55 * Math.sin(x * .011 * rough + seed * 1.7) + .3 * Math.sin(x * .029 * rough + seed * 3.1) + .15 * Math.sin(x * .071 * rough + seed * 5.3)));
  function muRidge(g, W, H, base, amp, col, seed, rough = 1, cap) {  // une ligne de montagnes (somme de sinus), cap : la couleur de la neige sur les sommets
    for (let x = 0; x < W; x++) {
      const y = muRidgeY(x, base, amp, seed, rough);
      g.fillStyle = col; g.fillRect(x, y, 1, H - y); if (cap && y < base - amp * .45) { g.fillStyle = cap; g.fillRect(x, y, 1, 2); }
    }
  }
  function muPines(g, W, H, base, hMin, hMax, col, seed, gap = 7) {  // des sapins en triangles à étages
    const R = muSeed(seed);
    for (let x = -4; x < W + 4; x += gap * (.6 + R() * .8)) {
      const h = hMin + R() * (hMax - hMin), cx = Math.round(x), top = base - h; g.fillStyle = col;
      for (let y = 0; y < h; y++) { const w = Math.round((y % 6) * .45 + y * .22) + 1; g.fillRect(cx - w, Math.round(top + y), w * 2 + 1, 1); }
      g.fillRect(cx - 1, base - 1, 3, H - base + 1);
    }
    g.fillRect(0, base, W, H - base);
  }
  function muGrass(g, W, H, hMax, col, seed, base = H) {
    const R = muSeed(seed); g.fillStyle = col; g.fillRect(0, Math.round(base - 3), W, H);
    for (let x = 0; x < W; x++) { const h = 2 + R() * hMax * (.5 + .5 * Math.abs(Math.sin(x * .05 + seed))); g.fillRect(x, Math.round(base - 3 - h), 1, Math.round(h)); }
  }
  const muP = (W, H, o) => { const R = Math.random; return {x: R() * W, y: R() * H, z: .25 + R() * .75, ph: R() * 6.28, v: R(), ...o}; };
  const MU_SPR = {
    cross: '.+.|+#+|.+.', star5: '..+..|..#..|+#o#+|..#..|..+..', star7: '...+...|...#...|..+#+..|+##o##+|..+#+..|...#...|...+...',
    flake: '+.#.+|.+#+.|##o##|.+#+.|+.#.+', bub1: '.#.|#.#|.#.', bub2: '.##.|#o.#|#..#|.##.', bub3: '.###.|#o..#|#...#|#...#|.###.',
    petal: ['.#+|###|+#.', '+#.|##+|.#.', '.##|##.', '#.|##|.#', '#|#'], leaf: ['..o|.##|##.', '.#.|#o#|.#.', 'o..|##.|.##', '#|o|#'],
    shard: ['.#.|#o#|.#.', '#|o|#'], bird: ['#...#|.#.#.|..#..', '.....|##.##|..#..'], fly: ['##.##|#o#o#|.#.#.', '.#.#.|.#o#.|..#..'],
  };
  // chaque scène : init (les particules), back (le décor fixe, peint une fois), draw (chaque image : x le contexte, f le pas en images à 30/s, e les basses, k le coup de basse)
  const MU_SCN = {
    space: {  // Nova : un voyage dans les étoiles, comme Cyber un seul motif net : les étoiles viennent du fond et filent vers les bords, plus vite sur les basses
      init: (W, H) => Array.from({length: Math.round(W * H / 170)}, () => ({x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random(), c: Math.random() < .15})),
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .35); g.fillRect(0, 0, W, H); },
      draw(x, W, H, C, f, t, e) {
        const cx = W / 2, cy = H * .42, S = Math.max(W, H) * .3, sp = (.0035 + .016 * e) * f;
        for (const p of muAmb.parts) {
          const z0 = p.z; p.z -= sp;
          const X = cx + p.x / p.z * S, Y = cy + p.y / p.z * S;
          if (p.z <= .03 || X < 0 || X >= W || Y < 0 || Y >= H) { p.x = Math.random() * 2 - 1; p.y = Math.random() * 2 - 1; p.z = 1; continue; }
          const X0 = cx + p.x / z0 * S, Y0 = cy + p.y / z0 * S, b = 1 - p.z, n = Math.min(8, Math.round(Math.hypot(X - X0, Y - Y0)));
          x.globalAlpha = Math.min(1, .4 + b); x.fillStyle = p.c ? C.a : b > .5 ? C.t : C.s;
          for (let i = 0; i <= n; i++) x.fillRect(Math.round(X - (X - X0) * i / Math.max(1, n)), Math.round(Y - (Y - Y0) * i / Math.max(1, n)), 1, 1);
        }
      },
    },
    night: {  // Onyx : pluie oblique sur une ville, fenêtres allumées, éclaboussures, éclair sur les gros coups de basse
      init: (W, H) => Array.from({length: Math.round(W * H / 2200)}, () => muP(W, H)),
      back(g, W, H, C) {
        muSky(g, W, 0, H, C.bg, muMix(C.bg, C.card, .8));
        const R = muSeed(7);
        for (const [lay, col, hMax] of [[0, muMix(C.bg, C.card, .55), .42], [1, muMix(C.bg, '#000000', .35), .3]])
          for (let x = 0; x < W;) { const w = 8 + R() * 18 | 0, h = H * (.08 + R() * hMax) | 0, G = muAmb.G + lay * H * .04; g.fillStyle = col; g.fillRect(x, G - h, w - 1, H - G + h);
            if (lay) for (let wy = G - h + 3; wy < G - 3; wy += 4) for (let wx = x + 2; wx < x + w - 3; wx += 3) if (R() < .18) { g.fillStyle = R() < .5 ? muRgba(C.a, .7) : muRgba(C.b, .6); g.fillRect(wx, wy, 1, 2); g.fillStyle = col; }
            x += w + (R() * 3 | 0); }
      },
      draw(x, W, H, C, f, t, e, k) {
        if (k > .95 && e > .55) muAmb.flash = 1; muAmb.flash = (muAmb.flash || 0) * .8;
        if (muAmb.flash > .05) { x.globalAlpha = muAmb.flash * .12; x.fillStyle = C.t; x.fillRect(0, 0, W, H); }
        const gy = Math.round(muAmb.G + H * .04); x.globalAlpha = .18 + .2 * e; x.drawImage(muVGrad(C.a), 0, gy - 6, W * .5, 14); x.drawImage(muVGrad(C.b), W * .5, gy - 6, W * .5, 14);
        x.fillStyle = muMix(C.s, C.t, .3);
        for (const p of muAmb.parts) {
          const sp = (3 + 5 * p.z) * f * (1 + .5 * e), L = 4 + Math.round(7 * p.z); p.y += sp; p.x -= sp * .35;
          if (p.y > muAmb.G + H * .04 - (1 - p.z) * H * .2) { muAmb.fx.push({x: p.x, y: p.y, life: 1}); p.y = -Math.random() * 20; p.x = Math.random() * (W + 40); }
          for (let i = 0; i < L; i++) { x.globalAlpha = (.2 + .5 * p.z) * (1 - i / L); x.fillRect(Math.round(p.x + i * .35), Math.round(p.y - i), 1, 1); }
        }
        for (const s of muAmb.fx) { s.life -= .12 * f; x.globalAlpha = Math.max(0, s.life) * .6; const d = Math.round((1 - s.life) * 3); x.fillRect(Math.round(s.x) - d, Math.round(s.y) - 1, 1, 1); x.fillRect(Math.round(s.x) + d, Math.round(s.y) - 1, 1, 1); }
      },
    },
    bokeh: {  // Grenat : un quadrillage de petits losanges ; une vague de lumière les traverse en diagonale, plus vive sur les basses
      init: () => [],
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .25); g.fillRect(0, 0, W, H); },
      draw(x, W, H, C, f, t, e) {
        const sp = muSpr('...#...|..#.#..|.#...#.|#.....#|.#...#.|..#.#..|...#...', C.a), sp2 = muSpr('...#...|..###..|.#####.|#######|.#####.|..###..|...#...', C.a);
        for (let j = 0, y = -3; y < H + 4; j++, y += 6) for (let X = (j % 2) * 6 - 3; X < W + 4; X += 12) {
          const v = Math.max(0, Math.cos((X + y * 1.4) / 70 - t * .7)) ** 8;
          x.globalAlpha = .12 + v * (.3 + .45 * e); x.drawImage(v > .85 && e > .35 ? sp2 : sp, X - 3, y - 3);
        }
      },
    },
    dawn: {  // Aube : un ciel en bandes nettes, un soleil plein, des nuages en pixels qui passent, deux lignes de collines (ni halo ni particules)
      init: (W, H) => Array.from({length: 7}, () => ({x: Math.random() * W, y: muAmb.G * (.08 + Math.random() * .45), w: 16 + Math.random() * 30 | 0, v: .05 + Math.random() * .1})),
      back(g, W, H, C) {
        const G = Math.round(muAmb.G); muSky(g, W, 0, G, muMix(C.bg, '#000000', .25), muMix(C.bg, C.w, .4), 4); g.fillStyle = muMix(C.bg, '#000000', .3); g.fillRect(0, G, W, H - G);
        const hl = muAmb.hl = document.createElement('canvas'); hl.width = W; hl.height = H; const q = hl.getContext('2d');
        muRidge(q, W, H, G - H * .03, H * .07, muMix(C.bg, C.a, .25), 3, .8); muRidge(q, W, H, G + 2, H * .05, muMix(C.bg, '#000000', .2), 9, 1.3);
      },
      draw(x, W, H, C, f, t, e) {
        const G = muAmb.G, sx = Math.round(W * .68), sy = Math.round(G - H * .1), r = Math.round(H * .09);
        x.globalAlpha = 1; x.fillStyle = muMix(C.w, '#ffffff', .25);
        for (let yy = -r; yy <= r; yy++) { const w = Math.round(Math.sqrt(r * r - yy * yy)); if (yy > r * .3 && (yy & 3) === 0) continue; x.fillRect(sx - w, sy + yy, 2 * w + 1, 1); }  // le bas du soleil rayé
        for (const c of muAmb.parts) {
          c.x += c.v * (1 + e) * f; if (c.x - c.w > W) c.x = -c.w * 1.2;
          x.globalAlpha = .85; x.fillStyle = muMix(C.bg, C.t, .3); const X = Math.round(c.x), Y = Math.round(c.y);
          [[.35, .2], [.7, .05], [1, 0], [.85, .1]].forEach(([k, o], i) => x.fillRect(X + Math.round(c.w * o), Y + i * 2, Math.round(c.w * k), 2));
        }
        x.globalAlpha = 1; x.drawImage(muAmb.hl, 0, 0);
      },
    },
    shafts: {  // Ambre : des alvéoles de miel ; quelques cellules se remplissent doucement puis se vident, plus nombreuses sur les basses
      init: (W, H) => { const L = []; for (let j = 0, y = 0; y < H + 10; j++, y += 8) for (let X = (j % 2) * 5; X < W + 10; X += 10) L.push({x: X, y, ph: Math.random() * 6.28, v: .2 + Math.random() * .5}); return L; },
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .25); g.fillRect(0, 0, W, H); const s = muSpr('..###..|.#...#.|#.....#|#.....#|#.....#|.#...#.|..###..', muMix(C.bg, C.a, .16)); for (const p of muAmb.parts || []) g.drawImage(s, p.x - 3, p.y - 3); },
      draw(x, W, H, C, f, t, e) {
        const s = muSpr('..###..|.#####.|#######|#######|#######|.#####.|..###..', C.a);
        for (const p of muAmb.parts) { const v = Math.sin(t * p.v + p.ph); if (v < .75 - .25 * e) continue; x.globalAlpha = Math.min(.55, (v - .7 + .25 * e) * 1.6); x.drawImage(s, p.x - 3, p.y - 3); }
      },
    },
    abyss: {  // Abyme : des bulles nettes qui montent du fond en oscillant, sur un fond qui s'assombrit en bandes, des rochers en bas
      init: (W, H) => Array.from({length: Math.round(W * H / 1400)}, () => ({x: Math.random() * W, y: Math.random() * H, s: Math.random() * 3 | 0, v: .3 + Math.random() * .6, ph: Math.random() * 6.28})),
      back(g, W, H, C) { muSky(g, W, 0, H, muMix(C.bg, C.b, .12), muMix(C.bg, '#000000', .5), 6); muRidge(g, W, H, H - H * .05, H * .05, muMix(C.bg, '#000000', .6), 5, 1.4); },
      draw(x, W, H, C, f, t, e) {
        const B = ['bub1', 'bub2', 'bub3'];
        for (const p of muAmb.parts) {
          p.y -= p.v * (1 + 1.5 * e) * (1 + p.s * .3) * f; if (p.y < -6) { p.y = H + 4; p.x = Math.random() * W; }
          x.globalAlpha = .35 + p.s * .2; x.drawImage(muSpr(MU_SPR[B[p.s]], p.s ? C.b : C.s, C.t), Math.round(p.x + Math.sin(t * 1.5 + p.ph) * 2), Math.round(p.y));
        }
      },
    },
    sakura: {  // Sakura : une branche fleurie, des pétales qui tournent et dérivent, des rafales sur les coups de basse
      init: (W, H) => Array.from({length: Math.round(W * H / 1500) + 12}, () => muP(W, H)),
      back(g, W, H, C) {
        const R = muSeed(11), wood = muMix(C.bg, C.card, .9), tips = [];
        const br = (x0, y0, a, len, w) => { if (len < 4 || w < .6) { tips.push([x0, y0]); return; } const x1 = x0 + Math.cos(a) * len, y1 = y0 + Math.sin(a) * len; g.strokeStyle = wood; g.lineWidth = w; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); br(x1, y1, a - .35 - R() * .3, len * (.62 + R() * .15), w * .7); br(x1, y1, a + .25 + R() * .3, len * (.55 + R() * .15), w * .65); };
        g.imageSmoothingEnabled = false; br(W + 2, -2, Math.PI * .8, H * .13, 3);
        for (const [tx, ty] of tips) for (let i = 0; i < 7; i++) { const ox = Math.round(tx + R() * 8 - 4), oy = Math.round(ty + R() * 8 - 4); g.globalAlpha = .85; g.fillStyle = C.a; g.fillRect(ox - 1, oy, 3, 1); g.fillRect(ox, oy - 1, 1, 3); g.fillStyle = muMix(C.a, C.t, .6); g.fillRect(ox, oy, 1, 1); }
        g.globalAlpha = 1;
      },
      draw(x, W, H, C, f, t, e, k) {
        muAmb.gust = Math.max(muAmb.gust * .96, k > .9 ? 2.2 : 0);
        for (const p of muAmb.parts) {
          p.y += (.25 + .45 * p.z) * f; p.x += ((.3 + .4 * p.z) * (1 + muAmb.gust) + Math.sin(t * 1.2 + p.ph) * .4) * f;
          if (p.y > H + 4 || p.x > W + 6) { if (Math.random() < .5) { p.x = -4; p.y = Math.random() * H; } else { p.y = -4; p.x = Math.random() * W; } }
          const fr = MU_SPR.petal[Math.floor(t * (1.5 + 2 * p.v) + p.ph * 3) % MU_SPR.petal.length];
          x.globalAlpha = .45 + .45 * p.z; x.drawImage(muSpr(fr, p.v < .6 ? C.a : muMix(C.a, C.t, .5)), Math.round(p.x), Math.round(p.y));
        }
      },
    },
    dusk: {  // Crépuscule : ciel orangé, lune, silhouettes d'arbres et d'herbes, lucioles qui clignotent
      init: (W, H) => Array.from({length: 30}, () => muP(W, H, {x: W * (.25 + Math.random() * .75), y: muAmb.G * (.45 + Math.random() * .6)})),
      back(g, W, H, C) {
        muSky(g, W, 0, H, C.bg, muMix(C.bg, C.a, .5)); const R = muSeed(3);
        for (let i = 0; i < W * H / 500; i++) { g.globalAlpha = .2 + R() * .5; g.fillStyle = C.t; g.fillRect(R() * W | 0, R() * H * .45 | 0, 1, 1); } g.globalAlpha = 1;
        const mx = Math.round(W * .84), my = Math.round(muAmb.G * .32), mr = Math.round(H * .07);
        for (let y = -mr; y <= mr; y++) for (let x = -mr; x <= mr; x++) if (x * x + y * y <= mr * mr && (x - mr * .45) ** 2 + (y + mr * .2) ** 2 > mr * mr * .8) { g.fillStyle = muMix(C.t, C.b, .25); g.fillRect(mx + x, my + y, 1, 1); }
        muPines(g, W, H, muAmb.G + H * .02, H * .1, H * .22, muMix(C.bg, '#000000', .25), 4, 11); muGrass(g, W, H, H * .06, muMix(C.bg, '#000000', .45), 8, muAmb.G + H * .06);
      },
      draw(x, W, H, C, f, t, e) {
        for (const p of muAmb.parts) {
          p.x += Math.sin(t * .5 + p.ph) * .25 * f; p.y += Math.cos(t * .4 + p.ph * 2) * .15 * f; if (p.x < -4) p.x = W + 2; if (p.x > W + 4) p.x = -2;
          const a = Math.max(0, Math.sin(t * (1 + p.v) + p.ph)) ** 2 * (.7 + .5 * e); if (a < .03) continue;
          x.globalAlpha = a * .8; x.drawImage(muGlow(C.b, 4), Math.round(p.x) - 4, Math.round(p.y) - 4); x.globalAlpha = Math.min(1, a * 1.3); x.fillStyle = muMix(C.b, C.t, .5); x.fillRect(Math.round(p.x), Math.round(p.y), 1, 1);
        }
      },
    },
    fizz: {  // Menthe : des gouttes tombent sur l'eau, vue d'en haut : des ronds nets qui s'élargissent et s'effacent, plus nombreux sur les basses
      init: () => [],
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .25); g.fillRect(0, 0, W, H); },
      draw(x, W, H, C, f, t, e, k) {
        const P = muAmb.parts; if (Math.random() < (.2 + .4 * e) * f || k > .8) P.push({x: Math.random() * W | 0, y: Math.random() * H | 0, r: 0, m: 8 + Math.random() * 14});
        for (const p of P) {
          p.r += .35 * f; const R = Math.round(p.r); if (R < 1) continue;
          const key = 'ring' + R + C.a; let s = muAmb.spr.get(key);
          if (!s) { s = document.createElement('canvas'); s.width = s.height = R * 2 + 1; const q = s.getContext('2d'); q.fillStyle = C.a; for (let a = 0; a < 6.283; a += .5 / R) q.fillRect(Math.round(R + Math.cos(a) * R), Math.round(R + Math.sin(a) * R), 1, 1); muAmb.spr.set(key, s); }
          x.globalAlpha = .95 * (1 - p.r / p.m); x.drawImage(s, p.x - R, p.y - R);
          if (p.r > 4) { x.globalAlpha *= .5; const r2 = R - 3, s2 = muAmb.spr.get('ring' + r2 + C.a); if (s2) x.drawImage(s2, p.x - r2, p.y - r2); }
        }
        muAmb.parts = P.filter(p => p.r < p.m);
      },
    },
    gems: {  // Rubis : une surface taillée en facettes (des triangles à peine plus clairs ou plus sombres) ; un reflet passe en biais, plus vif sur les basses
      init: () => [],
      back(g, W, H, C) {
        const im = g.createImageData(W, H), w = 22, h = 18, A = muHex(muMix(C.bg, '#000000', .2)), B = muHex(C.a);
        for (let y = 0; y < H; y++) for (let x0 = 0; x0 < W; x0++) {
          const j = Math.floor(y / h), fy = (y % h) / h, xx = x0 + (j % 2) * w / 2, i = Math.floor(xx / w), fx = (xx % w) / w, tri = (i + j) % 2 ? fx + fy < 1 : fx > fy;
          const r = muSeed(i * 7919 + j * 104729 + (tri ? 1 : 0))(), k = .03 + r * .11, o = (y * W + x0) * 4;
          for (let c = 0; c < 3; c++) im.data[o + c] = Math.round(A[c] + (B[c] - A[c]) * k); im.data[o + 3] = 255;
        }
        g.putImageData(im, 0, 0);
      },
      draw(x, W, H, C, f, t, e) {
        const per = W + H + 80, p = (t * 22) % (per + 200) - 40; x.fillStyle = C.t;
        for (let y = 0; y < H; y++) { const X = Math.round(p - y * .6); x.globalAlpha = .05 + .1 * e; x.fillRect(X, y, 6, 1); x.globalAlpha = .1 + .15 * e; x.fillRect(X + 2, y, 2, 1); }
      },
    },
    aurora: {  // Glacier : la neige qui tombe en trois profondeurs, qui part de côté sur les basses ; des montagnes enneigées au loin (plus d'aurores)
      init: (W, H) => Array.from({length: Math.round(W * H / 320)}, () => ({x: Math.random() * W, y: Math.random() * H, z: Math.random() * 3 | 0, ph: Math.random() * 6.28})),
      back(g, W, H, C) {
        const G = Math.round(muAmb.G); muSky(g, W, 0, G, muMix(C.bg, '#000000', .3), muMix(C.bg, C.b, .15), 4); g.fillStyle = muMix(C.bg, '#000000', .2); g.fillRect(0, G, W, H - G);
        muRidge(g, W, H, G, H * .12, muMix(C.bg, C.s, .18), 4, .9, muMix(C.t, C.bg, .25)); muRidge(g, W, H, G + 3, H * .05, muMix(C.bg, '#000000', .15), 11, 1.6);
      },
      draw(x, W, H, C, f, t, e) {
        const fl = muSpr(MU_SPR.flake, C.t, C.b), wind = .2 + 1.2 * e;
        for (const p of muAmb.parts) {
          const z = p.z + 1; p.y += .25 * z * f; p.x += (wind * z * .4 + Math.sin(t + p.ph) * .15) * f;
          if (p.y > H + 3) { p.y = -4; p.x = Math.random() * W; } if (p.x > W + 3) p.x = -3;
          const X = Math.round(p.x), Y = Math.round(p.y); x.globalAlpha = .35 + p.z * .3;
          if (p.z === 2 && (p.ph * 10 | 0) % 4 === 0) x.drawImage(fl, X - 2, Y - 2); else { x.fillStyle = p.z ? C.t : C.s; x.fillRect(X, Y, p.z === 2 ? 2 : 1, p.z === 2 ? 2 : 1); }
        }
      },
    },
    forge: {  // Cuivre : des engrenages qui tournent lentement, emboîtés sur les bords ; ils accélèrent sur les basses
      init(W, H) {
        const L = [], R = muSeed(17), add = (x, y, r, d) => L.push({x, y, r, n: Math.max(8, Math.round(r / 2.2)), d, a: R() * 6});
        add(W * .06, H * .15, H * .2, 1); add(W * .06 + H * .37, H * .15 + H * .07, H * .13, -1); add(W * .94, H * .7, H * .26, -1); add(W * .94 - H * .45, H * .7 + H * .12, H * .15, 1); add(W * .55, H * 1.02, H * .18, 1); add(W * .55 + H * .33, H * .96, H * .11, -1);
        return L;
      },
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .25); g.fillRect(0, 0, W, H); },
      draw(x, W, H, C, f, t, e) {
        muAmb.spin = (muAmb.spin || 0) + (.006 + .03 * e) * f;
        for (const q of muAmb.parts) {
          const a0 = q.a + muAmb.spin * q.d * 30 / q.r, n = q.n, R1 = q.r, R0 = q.r - 3; x.beginPath();
          for (let i = 0; i < n * 4; i++) { const a = a0 + i / (n * 4) * 6.2832, rr = i % 4 < 2 ? R1 : R0; x.lineTo(q.x + Math.cos(a) * rr, q.y + Math.sin(a) * rr); }
          x.closePath(); x.globalAlpha = 1; x.fillStyle = muMix(C.bg, C.a, .22); x.fill();
          x.fillStyle = muMix(C.bg, '#000000', .25); x.beginPath(); x.arc(q.x, q.y, q.r * .62, 0, 6.2832); x.fill();
          x.fillStyle = muMix(C.bg, C.a, .22); for (let s = 0; s < 4; s++) { const a = a0 + s * 1.5708; x.beginPath(); x.moveTo(q.x + Math.cos(a - .12) * 2, q.y + Math.sin(a - .12) * 2); x.lineTo(q.x + Math.cos(a - .05) * q.r * .64, q.y + Math.sin(a - .05) * q.r * .64); x.lineTo(q.x + Math.cos(a + .05) * q.r * .64, q.y + Math.sin(a + .05) * q.r * .64); x.lineTo(q.x + Math.cos(a + .12) * 2, q.y + Math.sin(a + .12) * 2); x.fill(); }
          x.beginPath(); x.arc(q.x, q.y, Math.max(2, q.r * .16), 0, 6.2832); x.fill();
        }
      },
    },
    meadow: {  // Lavande : un champ de lavande qui ondule, des papillons qui volettent, du pollen
      init(W, H) { muAmb.stalks = Array.from({length: Math.round(W * 1.2)}, () => { const x = Math.random() * W, d = Math.random() ** 1.6; return {x, d, y: muRidgeY(x, muAmb.G - H * .03, H * .05, 3, .7) + 2 + d * H * .12, ph: Math.random() * 6}; }).sort((p, q) => p.y - q.y); return [...Array.from({length: 5}, () => muP(W, H, {bf: 1, tx: Math.random() * W, ty: Math.random() * H * .7})), ...Array.from({length: 40}, () => muP(W, H))]; },
      back(g, W, H, C) { muSky(g, W, 0, H, C.bg, muMix(C.bg, C.b, .2)); muRidge(g, W, H, muAmb.G - H * .03, H * .05, muMix(C.bg, C.a, .22), 3, .7); g.fillStyle = muMix(C.bg, C.a, .15); g.fillRect(0, Math.round(muAmb.G + H * .04), W, H); },
      draw(x, W, H, C, f, t, e) {
        for (const s of muAmb.stalks) {
          const X = Math.round(s.x + Math.sin(t * .9 + s.x * .03 + s.ph * .3) * (.6 + s.d * 1.2) * (1 + e)), Y = Math.round(s.y), big = s.d > .55;
          x.globalAlpha = .45 + .5 * s.d; x.fillStyle = muMix(C.bg, C.b, .35); x.fillRect(Math.round(s.x), Y, 1, big ? 3 : 1);
          x.fillStyle = s.ph < 2 ? muMix(C.a, C.h, .45) : C.a; x.fillRect(X, Y - (big ? 3 : 1), 1, big ? 3 : 1); if (big) { x.fillStyle = muMix(C.a, C.t, .4); x.fillRect(X, Y - 4, 1, 1); }
        }
        for (const p of muAmb.parts) {
          if (p.bf) { if (Math.hypot(p.tx - p.x, p.ty - p.y) < 6) { p.tx = Math.random() * W; p.ty = Math.random() * H * .75; }
            const a = Math.atan2(p.ty - p.y, p.tx - p.x) + Math.sin(t * 3 + p.ph) * .8; p.x += Math.cos(a) * .6 * f; p.y += Math.sin(a) * .6 * f + Math.sin(t * 7 + p.ph) * .3;
            x.globalAlpha = .85; x.drawImage(muSpr(MU_SPR.fly[Math.floor(t * 8 + p.ph) & 1], p.v < .5 ? C.h : C.a, C.t), Math.round(p.x) - 2, Math.round(p.y) - 1); continue; }
          p.x += (.08 + Math.sin(t * .4 + p.ph) * .1) * f; p.y -= .04 * f; if (p.x > W + 2) p.x = -2; if (p.y < -2) p.y = H + 2;
          x.globalAlpha = .25 + .35 * Math.abs(Math.sin(t + p.ph)) + .3 * e; x.fillStyle = C.w; x.fillRect(Math.round(p.x), Math.round(p.y), 1, 1);
        }
      },
    },
    forest: {  // Forêt : trois rangées de sapins dans la brume, rayons de soleil, feuilles qui tombent en tournant, quelques lucioles
      init: (W, H) => [...Array.from({length: 30}, () => muP(W, H)), ...Array.from({length: 10}, () => muP(W, H, {ff: 1, x: W * (.25 + Math.random() * .75), y: muAmb.G * (.55 + Math.random() * .45)}))],
      back(g, W, H, C) {
        muSky(g, W, 0, H, muMix(C.bg, C.b, .1), C.bg);
        const G = muAmb.G; muPines(g, W, H, G - H * .06, H * .12, H * .24, muMix(C.bg, C.a, .18), 1, 9); muPines(g, W, H, G, H * .12, H * .26, muMix(C.bg, C.a, .1), 2, 12); muPines(g, W, H, G + H * .08, H * .14, H * .3, muMix(C.bg, '#000000', .35), 3, 16);
      },
      draw(x, W, H, C, f, t, e) {
        for (let i = 0; i < 3; i++) { const u = W * (.2 + i * .28); x.globalAlpha = .05 + .03 * Math.sin(t * .3 + i * 2) + .04 * e; x.fillStyle = C.b; x.beginPath(); x.moveTo(u, 0); x.lineTo(u + W * .05, 0); x.lineTo(u - H * .3 + W * .1, H); x.lineTo(u - H * .3, H); x.fill(); }
        for (const p of muAmb.parts) {
          if (p.ff) { p.x += Math.sin(t * .6 + p.ph) * .2 * f; p.y += Math.cos(t * .5 + p.ph) * .1 * f; const a = Math.max(0, Math.sin(t * 1.5 + p.ph)) ** 2; if (a < .05) continue; x.globalAlpha = a * .7; x.drawImage(muGlow(C.b, 3), Math.round(p.x) - 3, Math.round(p.y) - 3); continue; }
          p.y += (.25 + .4 * p.z) * f; p.x += (Math.sin(t * 1.1 + p.ph) * .5 + .1) * f; if (p.y > H + 4) { p.y = -4; p.x = Math.random() * W; }
          const fr = MU_SPR.leaf[Math.floor(t * (1 + 2 * p.v) + p.ph * 3) % 4]; x.globalAlpha = .45 + .45 * p.z;
          x.drawImage(muSpr(fr, p.v < .45 ? C.a : p.v < .8 ? C.b : muMix(C.b, C.d, .5), muMix(C.bg, '#000000', .2)), Math.round(p.x), Math.round(p.y));
        }
      },
    },
    sea: {  // Océan : des lignes de vagues sur toute la hauteur, qui roulent de gauche à droite et se creusent sur les basses
      init: () => [],
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .3); g.fillRect(0, 0, W, H); },
      draw(x, W, H, C, f, t, e) {
        const A = 1.5 + 3 * e;
        for (let j = 0, y0 = 4; y0 < H + 6; j++, y0 += 7) {
          x.fillStyle = j % 3 ? C.b : C.a; x.globalAlpha = j % 3 ? .22 : .38;
          for (let X = 0; X < W; X += 2) { const v = Math.sin(X * .045 + t * (1 + j % 2 * .4) + j * .9); x.fillRect(X, Math.round(y0 + v * A), 2, 1); }
        }
      },
    },
    sun: {  // Soleil : de grands rayons qui partent du coin en haut à droite et tournent lentement, à peine plus clairs que le fond, plus vifs sur les basses
      init: () => [],
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .2); g.fillRect(0, 0, W, H); },
      draw(x, W, H, C, f, t, e) {
        const cx = W * 1.02, cy = -H * .08, R = Math.hypot(W, H) * 1.2, n = 18, rot = t * .025;
        x.fillStyle = C.a; x.globalAlpha = .06 + .06 * e;
        for (let i = 0; i < n; i++) { const a = rot + i / n * 6.2832; x.beginPath(); x.moveTo(cx, cy); x.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R); x.lineTo(cx + Math.cos(a + .14) * R, cy + Math.sin(a + .14) * R); x.fill(); }
      },
    },
    code: {  // Cyber : de vrais caractères (3 × 5 pixels) qui tombent en colonnes, tête blanche, traînée qui s'éteint, et une bande pâle sur les basses
      init(W, H) {
        const R = muSeed(13); muAmb.gl = Array.from({length: 24}, () => Array.from({length: 5}, (_, y) => Array.from({length: 3}, (_, x) => (x === 1 && y % 2 === 0) || R() < .45 ? '#' : '.').join('')).join('|'));
        return Array.from({length: Math.round(W / 6)}, (_, i) => ({x: i * 6, y: (Math.random() * 1.6 - .4) * H, v: .5 + Math.random(), L: 6 + Math.random() * 12 | 0, g: Array.from({length: 22}, () => Math.random() * 24 | 0), c: Math.random() < .25}));
      },
      back(g, W, H, C) { g.fillStyle = muRgba(C.b, .04); for (let y = 0; y < H; y += 3) g.fillRect(0, y, W, 1); },
      draw(x, W, H, C, f, t, e, k) {
        const R = muAmb.now; if (k > .9) muAmb.fx.push({y: Math.random() * H, h: 2 + Math.random() * 4 | 0, life: 1});
        for (const p of muAmb.parts) {
          p.y += p.v * (1.2 + 2 * e) * f; if (p.y - p.L * 6 > H) { p.y = -Math.random() * H * .3; p.L = 6 + Math.random() * 12 | 0; }
          if (Math.random() < .05 * f) p.g[Math.random() * p.g.length | 0] = Math.random() * 24 | 0;
          const head = Math.floor(p.y / 6);
          for (let i = 0; i < p.L; i++) { const Y = (head - i) * 6; if (Y < -6 || Y > H) continue;
            x.globalAlpha = (i ? .55 * (1 - i / p.L) + .08 : .8) * (R && p.x >= R[0] && p.x < R[2] && Y >= R[1] && Y < R[3] ? .3 : 1); x.drawImage(muSpr(muAmb.gl[p.g[(head - i + 220) % p.g.length]], i ? (p.c ? C.b : C.a) : C.t), p.x, Y); }
        }
        for (const s of muAmb.fx) { s.life -= .2 * f; if (s.life <= 0) continue; x.globalAlpha = .12 * s.life; x.fillStyle = C.b; x.fillRect(0, Math.round(s.y), W, s.h); }
      },
    },
    synth: {  // Néon : des traits de lumière qui filent sur un quadrillage, tournent à angle droit et laissent une traînée qui s'éteint ; plus rapides sur les basses
      init: (W, H) => Array.from({length: Math.max(6, Math.round(W * H / 8000))}, (_, i) => ({x: Math.round(Math.random() * W / 8) * 8, y: Math.round(Math.random() * H / 8) * 8, d: i % 4, c: i % 2, tr: [], m: 0})),
      back(g, W, H, C) { g.fillStyle = muMix(C.bg, '#000000', .35); g.fillRect(0, 0, W, H); g.fillStyle = muRgba(C.a, .06); for (let X = 0; X < W; X += 8) g.fillRect(X, 0, 1, H); for (let y = 0; y < H; y += 8) g.fillRect(0, y, W, 1); },
      draw(x, W, H, C, f, t, e) {
        const D = [[1, 0], [0, 1], [-1, 0], [0, -1]];
        for (const p of muAmb.parts) {
          p.m += (1 + 2 * e) * f;
          while (p.m >= 1) {
            p.m--; p.x += D[p.d][0]; p.y += D[p.d][1]; p.tr.push([p.x, p.y]); if (p.tr.length > 70) p.tr.shift();
            if (p.x % 8 === 0 && p.y % 8 === 0 && Math.random() < .18) p.d = (p.d + (Math.random() < .5 ? 1 : 3)) % 4;
            if (p.x < -2 || p.x > W + 2 || p.y < -2 || p.y > H + 2) { p.x = (p.x + W) % W; p.y = (p.y + H) % H; p.x -= p.x % 8; p.y -= p.y % 8; p.tr = []; }
          }
          x.fillStyle = p.c ? C.b : C.a; p.tr.forEach(([X, Y], i) => { x.globalAlpha = (i + 1) / p.tr.length * .95; x.fillRect(X, Y, 1, 1); });
          x.globalAlpha = 1; x.fillStyle = C.t; x.fillRect(p.x, p.y, 1, 1);
        }
      },
    },
  };
  // une couche de plus sur toute la hauteur (comme les colonnes de Cyber) : les particules du thème en trois profondeurs, qui accélèrent avec les basses
  // k : dot (1 ou 2 pixels), streak (un trait dans le sens de la chute), glow (un halo), spr (des dessins de MU_SPR ; fr : une suite d'images animée)
  const MU_DEEP = {
    night: [{k: 'streak', c: ['s', 't'], n: 1.6, vx: -.8, vy: 5, a: .5}, {k: 'glow', r: [1, 3], c: ['a', 'w'], n: .12, vx: .05, tw: .4, a: .6}],
    sakura: [{k: 'spr', fr: 'petal', c: ['h', 'a', 't'], n: .6, vx: .6, vy: .7, sw: 1.2}, {k: 'dot', c: ['h', 't'], n: .6, vx: .3, vy: .2, sw: .5, tw: 1}],
    dusk: [{k: 'glow', r: [2, 3], c: ['w', 'a'], n: .35, vx: .05, vy: -.06, sw: .8, tw: 1.2}, {k: 'dot', c: ['t'], n: .8, tw: 1}],
    meadow: [{k: 'spr', fr: 'fly', c: ['b', 'a', 'w'], n: .12, vx: .35, vy: -.1, sw: 1.6}, {k: 'dot', c: ['w', 't', 'a'], n: 1, vx: .15, vy: -.12, sw: .5, tw: 1}],
    forest: [{k: 'spr', fr: 'leaf', c: ['a', 'w', 'd'], n: .35, vx: .4, vy: .55, sw: 1}, {k: 'glow', r: [1, 2], c: ['w'], n: .25, sw: .8, tw: 1.2}],
  };
  function muDeepInit(W, H, L) {
    const n = W * H / 120000;
    return (L || []).map(sp => ({sp, P: Array.from({length: Math.round(sp.n * 60 * n)}, () => ({x: Math.random() * W, y: Math.random() * H, z: .35 + Math.random() * .65, ph: Math.random() * 6.28, i: Math.random() * 999 | 0, r: Math.random()}))}));
  }
  function muDeepDraw(x, W, H, C, f, t, e, k) {
    for (const {sp, P} of muAmb.deep || []) for (const p of P) {
      const v = (1 + 2 * e) * p.z * f; p.x += (sp.vx || 0) * v + Math.cos(t * 1.3 + p.ph) * (sp.sw || 0) * .3 * f; p.y += (sp.vy || 0) * v;
      if (p.x < -14) p.x += W + 28; else if (p.x > W + 14) p.x -= W + 28;
      if (p.y < -14 || p.y > H + 14) { p.y = p.y < 0 ? H + 12 : -12; p.x = Math.random() * W; }
      const col = C[sp.c[p.i % sp.c.length]], tw = sp.tw ? .55 + .45 * Math.sin(t * (1.5 + p.r * 2) * sp.tw + p.ph) : 1;
      x.globalAlpha = Math.min(1, (.45 + .75 * p.z) * tw * (sp.a || 1) * (1 + .6 * k)); const X = Math.round(p.x), Y = Math.round(p.y);
      if (sp.k === 'dot') { x.fillStyle = col; const s = p.z > .6 ? 2 : 1; x.fillRect(X, Y, s, s); }
      else if (sp.k === 'streak') { x.fillStyle = col; const L = Math.round(3 + 6 * p.z), dx = (sp.vx || 0) / (sp.vy || 1); for (let j = 0; j < L; j++) x.fillRect(X - Math.round(j * dx), Y - j, 1, 1); }
      else if (sp.k === 'glow') { const r = Math.round(sp.r[0] + (sp.r[1] - sp.r[0]) * p.r); x.drawImage(muGlow(col, r), X - r, Y - r); x.fillStyle = col; x.fillRect(X, Y, 1, 1); }
      else { const fr = sp.fr ? MU_SPR[sp.fr] : null, rows = fr ? fr[Math.floor(t * 6 + p.ph * 3) % fr.length] : MU_SPR[sp.s[p.i % sp.s.length]]; x.drawImage(muSpr(rows, col, C.t), X, Y); }
    }
    if (k > .3) { x.globalAlpha = .1 * k; x.drawImage(muVGrad(C.a), 0, -H * .6, W, H * 1.2); }  // un coup de basse : une vague de lumière douce
  }
  const muAmbC = T => ({bg: T.BG || T.CARD, card: T.CARD, a: T.ACCENT, b: T.ACCENT_2, t: T.TEXT, s: T.SUBTEXT, w: T.WARN, d: T.DANGER, h: T.HEART || T.DANGER, n: muMix(T.BG || T.CARD, '#000000', .55)});
  // une image de l'ambiance dans la toile cv (W x H), pour l'état muAmb en cours ; bass : le niveau des basses (0 à 1)
  function muAmbDraw(cv, W, H, ms, C, bass, now) {
    const dt = Math.min(.1, (now - (muAmb.at || now)) / 1000); muAmb.at = now; muAmb.t += dt;
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; muAmb.ms = ''; }
    const sc = MU_SCN[MU_AMB[ms]] || MU_SCN.space, key = ms + W + 'x' + H + Object.values(C).join('');
    if (muAmb.ms !== key) {  // un nouveau thème (ou une autre taille) : le décor est repeint, les particules recréées
      muAmb.ms = key; muAmb.spr.clear(); muAmb.fx = []; muAmb.gust = 0; muAmb.parts = sc.init(W, H, C); muAmb.deep = muDeepInit(W, H, MU_DEEP[MU_AMB[ms]]);
      const bd = muAmb.bd = document.createElement('canvas'); bd.width = W; bd.height = H; sc.back?.(bd.getContext('2d'), W, H, C);
    }
    muAmb.e = Math.max(bass, muAmb.e * .9);  // monte d'un coup sur un coup de basse, retombe doucement
    muAmb.avg = muAmb.avg * .94 + bass * .06;
    if (bass > muAmb.avg * 1.3 + .06 && now - muAmb.kAt > 220) { muAmb.kick = 1; muAmb.kAt = now; } else muAmb.kick *= .6;  // un coup de basse net : les scènes y réagissent (rafale, éclair, étincelles…)
    const x = cv.getContext('2d'); x.globalAlpha = 1; x.clearRect(0, 0, W, H); x.drawImage(muAmb.bd, 0, 0);
    sc.draw(x, W, H, C, dt * 30, muAmb.t, muAmb.e, muAmb.kick); muDeepDraw(x, W, H, C, dt * 30, muAmb.t, muAmb.e, muAmb.kick);
    muAmb.fx = muAmb.fx.filter(s => s.life > 0 && s.y < H + 20 && s.y > -40);
    x.globalAlpha = 1;
  }
  // l'ambiance dans un petit lecteur (box : son cadre, cv : sa toile au tiers), avec son propre état (st) : les scènes lisent muAmb, on l'échange le temps d'une image
  function muAmbSmall(st, box, cv, ms, T, bass, now) {
    if (now - (st.at || 0) < 33) return;
    const W = Math.ceil(box.offsetWidth / 3), H = Math.ceil(box.offsetHeight / 3); if (!W || !H) return;
    const keep = {...muAmb}; for (const k in muAmb) delete muAmb[k];
    Object.assign(muAmb, {at: 0, ms: '', parts: [], fx: [], e: 0, t: 0, kick: 0, avg: 0, kAt: 0, gust: 0, spr: new Map(), ...st, G: Math.round(H * .7), now: null});
    try { muAmbDraw(cv, W, H, ms, muAmbC(T), bass, now); }
    finally { for (const k in st) delete st[k]; Object.assign(st, muAmb); for (const k in muAmb) delete muAmb[k]; Object.assign(muAmb, keep); }
  }
  // platine:fin
  function muAmbFrame(now) {
    const cv = $('muAmb'), on = mu.settings.ambiance !== false && !mu.settings.noImages, root = $('mu');
    root.classList.toggle('amb', on);
    if (!on) { if (muAmb.ms) { muAmb.ms = ''; cv.getContext('2d').clearRect(0, 0, cv.width, cv.height); } return; }
    if (now - muAmb.at < 33) return;
    const W = Math.ceil(root.clientWidth / 3), H = Math.ceil(root.clientHeight / 3); if (!W || !H) return;
    const ms = root.dataset.ms || 'nova', C = muAmbC(T);
    if (now - (muAmb.gAt || 0) > 1000) {  // la ligne de sol : le bas des cartes du haut (elles laissent le plus voir la scène)
      muAmb.gAt = now; const top = root.getBoundingClientRect().top, b = Math.max(0, ...[...root.querySelectorAll('.muNow,.muReco')].filter(e => e.offsetHeight).map(e => e.getBoundingClientRect().bottom - top));
      const G = Math.round(b ? Math.max(H * .35, Math.min(H * .8, b / 3)) : H * .62); if (Math.abs(G - (muAmb.G || 0)) > 3) { muAmb.G = G; muAmb.ms = ''; }
      const nw = root.querySelector('.muNow'), rr = root.getBoundingClientRect(), q = nw?.offsetHeight && nw.getBoundingClientRect();  // la carte du lecteur, en pixels de la toile (Cyber s'y fait discret)
      muAmb.now = q ? [(q.left - rr.left) / 3, (q.top - top) / 3, (q.right - rr.left) / 3, (q.bottom - top) / 3] : null;
    }
    muAmbDraw(cv, W, H, ms, C, muBass(), now);
  }
  const muBass = () => muAudio && !muAudio.paused ? (muSpec.levels[0] + muSpec.levels[1] + muSpec.levels[2]) / 3 || 0 : 0;
  const muAmbMini = {};  // l'état de l'ambiance du petit lecteur (Options : « Ambiance sur le petit lecteur et le widget »)
  const muAmbSmallOn = () => !!mu.settings.ambMini && mu.settings.ambiance !== false && !mu.settings.noImages;
  function muFrame(now) {
    requestAnimationFrame(muFrame);
    mp.frameAt = now;
    const main = view.classList.contains('on');
    if (document.hidden || (!main && !mp.miniOn && !mp.wData?.title)) return;  // nothing on screen (nor a song for the home widget): no drawing at all (the music still plays)
    if (muAudio && !muAudio.paused && muNodes) { if (now - muSpec.blockAt >= 64) { muSpec.blockAt = now; muSpectrumBlock(); } }
    else muSpec.ref = 1e-6;
    muSpin(now);
    if (main) {
      muAmbFrame(now); muDrawCover(now); if (mu.settings.visualizer) muSuperOn(now) ? muSuperSpectrum($('muSpectrum'), 112, now) : muPixSpectrum($('muSpectrum'), 64, now);
      if (muAudio && !muAudio.paused && now - (mp.progAt || 0) > 120) { mp.progAt = now; muDrawProgress(); }
    } else if (mp.miniOn) muMiniFrame(now);
    if (muAudio && !muAudio.paused) { muWidgetSpec(now); if (performance.now() - (mp.wAt || 0) > 5000) muWidget(); }
  }

  // NeoMusic caché (on est sur l'accueil) : le navigateur arrête requestAnimationFrame dans son cadre, et le spectre du widget de
  // l'accueil restait figé. Ce minuteur prend le relais tant que muFrame ne tourne plus.
  setInterval(() => {
    const now = performance.now();
    if (now - (mp.frameAt || 0) < 250 || !muAudio || muAudio.paused || !mp.wData?.title) return;
    if (muNodes && now - muSpec.blockAt >= 64) { muSpec.blockAt = now; muSpectrumBlock(); }
    muWidgetSpec(now); if (now - (mp.wAt || 0) > 5000) muWidget();
  }, 100);

  /* ---------- listening time, levels, session (every 250 ms like MuPlayer's update_clock) ---------- */
  function muClockTick() {
    if (!muAudio || muAudio.paused || !mp.cur) return;
    const now = performance.now();
    if (mp.lastTick) {
      const s = Math.min(.5, Math.max(0, (now - mp.lastTick) / 1000)), st = mu.stats, title = mp.cur.display_title || '', artist = mp.cur.author || 'Inconnu';
      st.seconds = (+st.seconds || 0) + s;
      st.songs_time[title] = (+st.songs_time[title] || 0) + s; st.artists_time[artist] = (+st.artists_time[artist] || 0) + s;
      muLevelCheck();
      if (now - mp.saveAt > 15000) { mp.saveAt = now; muSaveSession(false); muSave(500); }
    }
    mp.lastTick = now;
    if (mp.sleepAt && Date.now() >= mp.sleepAt) muSleepCountdown();
  }
  function muSaveSession(save = true) {
    if (!mp.cur) return;
    mu.session = {playlist: muPlaylistOf(mp.cur)?.name || mp.pl, id: muId(mp.cur), position: muAudio ? muAudio.currentTime : mp.resume};
    if (save) muSave();
  }
  function muRestoreSession() {
    const s = mu.session; if (!s?.id) return;
    const p = muPl(s.playlist), t = p?.tracks.find(x => muId(x) === s.id); if (!t) return;
    mp.cur = t; mp.queue = p.tracks.slice(); mp.resume = Math.max(0, +s.position || 0); mp.length = muDur(t); mp.paused = true;
    $('muTitle').textContent = t.display_title || t.file; muFitTitle();
    muSetCover(t); muFavButton(); muDrawProgress(true);
    const i = mp.view.findIndex(x => x === t); if (i >= 0) { mp.sel = new Set([i]); mp.anchor = i; muDraw(); }
  }

  /* ---------- status line (title bar) ---------- */
  function muStatus(text, color) {
    clearInterval(mp.statusTimer); mp.statusTimer = null;
    const el = $('muStatus'); if (!el) return;
    el.style.color = color || T.WARN;
    if (!/^Téléchargement \d/.test(text)) muProgressBar(0);
    if (/\.\.\.$/.test(text) || /attente/i.test(text)) {  // the "..." of a long task moves
      const base = text.replace(/\.+$/, ''); let n = 1;
      el.textContent = '●  ' + base + '.';
      mp.statusTimer = setInterval(() => { n = n >= 3 ? 1 : n + 1; el.textContent = '●  ' + base + '.'.repeat(n); }, 450);
    } else el.textContent = '●  ' + text;
  }
  function muProgressBar(p) { const b = $('muDl'); if (b) b.style.width = Math.max(0, Math.min(100, p)) + '%'; }

  /* ---------- favourites, adding, deleting (to the 7-day trash) ---------- */
  function muToggleFav(t = mp.cur) {
    if (!t) return;
    const fav = muPl('Favoris'), id = muId(t), i = fav.tracks.findIndex(x => muId(x) === id);
    if (i >= 0) { fav.tracks.splice(i, 1); muStatus('Retiré des favoris'); }
    else {
      const copy = {...t}; delete copy.last_played;
      fav.tracks.push(copy); muStatus('Ajouté aux favoris', T.HEART);
      if (!copy.file && copy.url) muQueue(() => muDownloadInto(copy).then(() => muSave()).catch(e => muWarn('favori', e)));  // Favoris is offline: the song is downloaded
      muFavAchievements();
    }
    muSave(); mp.favs = muFavIds(); muFavButton(); if (mp.pl === 'Favoris') muRefresh(); else muDraw();
  }
  function muAddTracksTo(list, name) {
    const p = muPl(name), have = new Set(p.tracks.map(muId)); let n = 0;
    for (const t of list) {
      if (have.has(muId(t))) { if (list.length === 1) muStatus(`Déjà présent dans « ${name} »`); continue; }
      const copy = {...t};
      if (p.mode === 'online') { if (!copy.url) { muNotify('error', 'Ajout', 'Cette musique n\'a pas de source en ligne disponible.'); continue; } copy.is_online = true; copy.duration = muDur(t); }
      else if (!copy.file && copy.url) muQueue(() => muDownloadInto(copy, name).then(() => muSave()).catch(e => muWarn('ajout', e)));
      p.tracks.push(copy); have.add(muId(t)); n++;
    }
    if (!n) return;
    if (name === 'Favoris') muFavAchievements();
    muSizeAchievement(p);
    muSave(); mp.favs = muFavIds(); if (mp.pl === name) muRefresh(); else muDraw();
    muStatus(n > 1 ? `${n} musiques ajoutées à « ${name} »` : `Ajouté à « ${name} »`);
  }
  function muDeleteSelection() { muDeleteTracks([...mp.sel].sort((a, b) => a - b).map(i => mp.view[i])); }
  function muDeleteTracks(list) {
    const p = muPl(mp.pl);
    for (const t of list) {
      const i = p.tracks.indexOf(t); if (i < 0) continue;
      p.tracks.splice(i, 1);
      mu.trash.push({item: t, playlist: p.name, title: t.display_title || t.file, deleted_at: Date.now() / 1000});
    }
    mp.sel.clear(); muSave(); mp.favs = muFavIds(); muRefresh();
    muStatus(list.length > 1 ? list.length + ' musiques à la corbeille' : 'Musique à la corbeille');
  }
  function muUsedElsewhere(file) { return !!file && (mu.playlists.some(p => p.tracks.some(t => t.file === file)) || mu.trash.some(e => e.item?.file === file)); }
  function muCleanupTrash() {  // 7 days later the entry goes, and its file too if nothing else uses it
    const now = Date.now() / 1000, keep = [], drop = [];
    for (const e of mu.trash) (now - (+e.deleted_at || now) >= 7 * 86400 ? drop : keep).push(e);
    if (!drop.length) return;
    mu.trash = keep;
    for (const e of drop) if (e.item?.file && !muUsedElsewhere(e.item.file)) neo.musicDeleteFile(e.item.file);
    muSave();
  }

  /* ---------- background jobs one after the other (downloads), with the progress line in the title bar ---------- */
  function muQueue(job) { const p = mp.busyQueue.then(job, job); mp.busyQueue = p.catch(() => {}); return p; }
  let muDlId = 0;
  neo.onMusicProgress?.(d => { if (d.id === mp.dlId) { muProgressBar(d.p); $('muStatus').textContent = '●  Téléchargement ' + Math.round(d.p) + '%'; $('muStatus').style.color = T.ACCENT_2; } });
  async function muDownload(url) {
    mp.dlId = ++muDlId; muStatus('Téléchargement 0%', T.ACCENT_2); muProgressBar(0);
    const r = await neo.musicDownload(url, mp.dlId);
    muProgressBar(100); muStatus('Conversion audio...', T.ACCENT_2);
    mp.exists[r.file] = true;
    return r;
  }
  async function muDownloadInto(t) {  // gives an online entry its own file on this PC
    const r = await muDownload(t.url);
    t.file = r.file; t.is_online = false; if (!t.cover && r.cover) t.cover = r.cover; if (!t.duration) t.duration = r.duration;
    muStatus('Musique téléchargée'); muDraw();
    return t;
  }
  // The library comes through the sync, the mp3 do not: every offline song this PC does not have yet is downloaded in the background,
  // one after the other, at launch and whenever another PC changes the library. Same YouTube id = same file name on every PC.
  const muSyncing = new Set();
  async function muSyncFiles() {
    if (!mu) return;
    const offline = mu.playlists.filter(p => p.mode === 'offline').flatMap(p => p.tracks).concat(mu.trash.map(e => e.item).filter(Boolean));
    const names = [...new Set(offline.map(t => t.file).filter(Boolean))];
    if (names.length) Object.assign(mp.exists, await neo.musicExists(names));
    const urls = [...new Set(offline.filter(t => t.url && (!t.file || mp.exists[t.file] === false)).map(t => t.url))].filter(u => !muSyncing.has(u));
    if (!urls.length) return 0;
    muCaps ||= await neo.musicCaps().catch(() => muDefaultCaps);
    if (!muCaps.ytdlp) return muWarn('synchro', urls.length + ' musique(s) à télécharger, mais yt-dlp n\'est pas installé'), 0;
    urls.forEach(u => muSyncing.add(u));
    let done = 0;
    for (const url of urls) muQueue(async () => {
      try {
        const r = await muDownload(url);
        for (const t of mu.playlists.flatMap(p => p.mode === 'offline' ? p.tracks : []).concat(mu.trash.map(e => e.item).filter(Boolean))) if (t.url === url) { t.file = r.file; t.is_online = false; if (!t.cover && r.cover) t.cover = r.cover; }
        done++; muSave(); muDraw();
        muStatus(done === urls.length ? `Synchro : ${done} musique(s) téléchargée(s) sur ce PC` : `Synchro : ${done} / ${urls.length} musiques`, T.ACCENT_2);
      } catch (e) { muWarn('synchro', e); }
      finally { muSyncing.delete(url); }
    });
    return urls.length;
  }

  /* ---------- NeoDex glue: global shortcuts, the tab ---------- */
  function muHotkeys() {
    const map = {};
    for (const [key, , , def] of MU_SHORTCUTS) map[key] = key in mu.settings.shortcuts ? mu.settings.shortcuts[key] : def;
    neo.musicHotkeys?.(map).then(failed => { if (failed?.length) muWarn('raccourcis', 'déjà pris par une autre appli : ' + failed.join(', ')); });
  }
  const MU_ACTIONS = {toggle: () => muToggle(), prev: () => muPrev(), next: () => muNext(), volUp: () => muSetVolume(mu.settings.volume + .05), volDown: () => muSetVolume(mu.settings.volume - .05),
    mute: () => { if (mu.settings.volume > 0) { mp.beforeMute = mu.settings.volume; muSetVolume(0); muStatus('Son coupé'); } else { muSetVolume(mp.beforeMute || .5); muStatus('Son rétabli'); } },
    fwd: () => muSeek((muAudio?.currentTime || 0) + 10), back: () => muSeek((muAudio?.currentTime || 0) - 10), shuffle: () => muShuffle(), fav: () => muToggleFav(),
    fullscreen: () => neo.win('fs'), mini: () => muMini()};
  neo.onMusicHotkey?.(async action => { await muLoad(); muBuild(); muShortcutAchievement(); MU_ACTIONS[action]?.(); });
  function muMini() {
    mu.settings.mini = !mu.settings.mini; muSave();
    $('mu').classList.toggle('mini', mu.settings.mini);
    muStatus(mu.settings.mini ? 'Mode petit lecteur activé' : 'Mode normal restauré');
    muDraw();
  }
  neo.onDataChanged?.(name => {  // another PC changed the library: take it, keep playing what plays
    if (name !== 'music' || !mu) return;
    neo.musicLoad().then(d => { const id = muId(mp.cur); mu = muRepair(d); if (mp.built) { muApplyTheme(); muApplySettingsUi(); muLoadPlaylist(muPl(mp.pl) ? mp.pl : 'Favoris'); } muHotkeys(); for (const p of mu.playlists) { const t = p.tracks.find(x => muId(x) === id); if (t) { mp.cur = t; break; } } muSyncFiles(); });
  });
  addEventListener('beforeunload', () => { if (mu) { if (mp.cur) muSaveSession(false); clearTimeout(muSaveTimer); neo.musicSave(mu); } });
  async function muOpen() {
    await muLoad();
    muBuild();
    muDraw(); muDrawProgress(true); muFitTitle();
  }
  muLoad().catch(e => muWarn('chargement', e));
  /* NeoMusic, part 2: MuPlayer's windows and dialogs (Options, Statistiques, Succès, Corbeille, Artistes à découvrir, imports...),
     recommendations and weekly playlists, sleep mode and alarm, levels and achievements. */

  /* ---------- dialogs: secondary windows (title bar with accent strip), ModernDialog prompts, NotifyDialog, playlist mode ---------- */
  let muWinZ = 0;
  function muWindow(title, width) {
    const layer = $('muLayer'), mu0 = $('mu');
    const w = Math.max(width || 620, Math.round(mu0.clientWidth / 2));
    const win = mh('div.muWin', {style: {width: Math.min(w, mu0.clientWidth) + 'px'}});
    const bar = mh('div.muWinBar', {}, mh('i'), mh('b', {text: title.toUpperCase()}), mh('button', {text: 'X', title: 'Fermer', onclick: () => close()}));
    const body = mh('div.muWinBody');
    win.append(bar, body); layer.append(win); win.style.zIndex = ++muWinZ;
    const close = () => { win.remove(); removeEventListener('keydown', esc, true); };
    const esc = e => { if (e.key === 'Escape' && +win.style.zIndex === Math.max(...[...layer.children].map(w => +w.style.zIndex))) { e.stopPropagation(); close(); } };
    addEventListener('keydown', esc, true);
    bar.onpointerdown = e => {  // drag by the title bar, like the Tk windows
      if (e.target.tagName === 'BUTTON') return;
      const x0 = e.clientX - win.offsetLeft, y0 = e.clientY - win.offsetTop; bar.setPointerCapture(e.pointerId);
      bar.onpointermove = ev => { win.style.left = Math.max(0, Math.min(mu0.clientWidth - 80, ev.clientX - x0)) + 'px'; win.style.top = Math.max(0, Math.min(mu0.clientHeight - 40, ev.clientY - y0)) + 'px'; };
      bar.onpointerup = () => { bar.onpointermove = null; };
    };
    win.onpointerdown = () => { if (+win.style.zIndex !== muWinZ) win.style.zIndex = ++muWinZ; };  // a click brings it to the front (moving the node instead would swallow the click)
    return {win, body, close};
  }
  const muH = (text, cls = '') => text.includes('·') ? mh('div.muWH' + cls, {text}) : mh('span.muWHx');  // only the headings that say more than the window title
  const muSec = text => mh('div.muWSec', {text});
  const muNote = text => mh('p.muWNote', {text});
  const muButton = (text, fn, kind = '') => mh('button.muBtn' + (kind ? '.' + kind : ''), {text, onclick: fn});
  function muModal(title, build, titleColor) {  // ModernDialog / NotifyDialog / PlaylistModeDialog: small, centred, modal
    return new Promise(resolve => {
      const shade = mh('div.muShade'), box = mh('div.muDlg');
      const done = v => { shade.remove(); removeEventListener('keydown', key, true); resolve(v); };
      const key = e => { if (e.key === 'Escape') { e.stopPropagation(); done(null); } };
      box.append(mh('div.muDlgBar', {}, mh('b', {text: title.toUpperCase(), style: titleColor ? {color: titleColor} : null}), mh('button', {text: 'X', onclick: () => done(null)})), mh('div.muDlgCard', {}, ...build(done)));
      shade.append(box); $('mu').append(shade);
      addEventListener('keydown', key, true);
      setTimeout(() => box.querySelector('input,button.first')?.focus(), 30);
    });
  }
  function muPrompt(title, prompt, value = '') {
    return muModal(title, done => {
      const input = mh('input.muDlgIn', {value, spellcheck: 'false', onkeydown: e => { if (e.key === 'Enter') done(input.value.trim()); }});
      return [mh('b.muDlgTitle', {text: title}), mh('p', {text: prompt}), input, mh('div.muDlgBtns', {}, muButton('OK', () => done(input.value.trim()), 'accent'), muButton('ANNULER', () => done(null), 'danger'))];
    });
  }
  function muConfirm(title, message) {
    return muModal(title, done => [mh('b.muDlgTitle', {text: title}), mh('p', {text: message}), mh('div.muDlgBtns', {}, muButton('OUI', () => done(true), 'accent first'), muButton('NON', () => done(false), 'danger'))]).then(v => v === true);
  }
  function muNotify(kind, title, message) {
    const [icon, color] = {error: ['✕', T.DANGER], warning: ['⚠', T.WARN], success: ['✓', T.ACCENT_2], info: ['ℹ', T.ACCENT]}[kind] || ['ℹ', T.ACCENT];
    return muModal(icon + '  ' + title, done => [mh('pre.muDlgMsg', {text: message}), mh('div.muDlgBtns', {}, mh('button.muBtn.first', {text: 'OK', style: {color}, onclick: () => done(true)}))], color);
  }
  function muModeDialog() {
    return muModal('Mode de la playlist', done => [mh('b.muDlgTitle.small', {text: 'Comment cette playlist doit-elle gérer la musique ?'}),
      mh('button.muMode', {onclick: () => done('offline')}, mh('b', {text: 'HORS LIGNE'}), mh('span', {text: 'Les musiques ajoutées sont téléchargées et écoutables sans connexion.'})),
      mh('button.muMode.alt', {onclick: () => done('online')}, mh('b', {text: 'EN LIGNE'}), mh('span', {text: 'Rien n\'est téléchargé à part la pochette : la musique est diffusée en streaming au moment de la lecture.'}))]);
  }
  const muDefaultCaps = {ytdlp: '', ffmpeg: false};
  let muCaps = null;
  async function muNeedYtdlp() {
    muCaps ||= await neo.musicCaps().catch(() => muDefaultCaps);
    if (muCaps.ytdlp) return true;
    muNotify('error', 'Dépendance manquante', 'yt-dlp n\'est pas installé.\n\nCommande : python -m pip install -U yt-dlp');
    return false;
  }

  /* ---------- playlists ---------- */
  async function muNewPlaylist() {
    let name = await muPrompt('Nouvelle playlist', 'Nom de la nouvelle playlist :');
    if (!name) return;
    if (muPl(name)) return muNotify('warning', 'NeoMusic', 'Cette playlist existe déjà.');
    if (MU_SYSTEM.includes(name)) return muNotify('warning', 'NeoMusic', 'Cette playlist est gérée automatiquement par NeoMusic.');
    name = name.replace(/[\\/:*?"<>|]/g, '_').trim(); if (!name) return;
    const mode = await muModeDialog(); if (!mode) return;
    mu.playlists.push({name, mode, tracks: []}); muSave();
    muLoadPlaylist(name); muPlaylistCreated();
    muStatus(mode === 'online' ? 'Playlist créée (en ligne)' : 'Playlist créée (hors ligne)');
  }
  async function muDeletePlaylist() {
    const name = mp.pl;
    if (MU_SYSTEM.includes(name)) return muNotify('warning', 'NeoMusic', 'Cette playlist système ne peut pas être supprimée.');
    if (!await muConfirm('Supprimer', `Supprimer définitivement la playlist « ${name} » ?`)) return;
    const p = muPl(name); mu.playlists = mu.playlists.filter(x => x !== p);
    for (const t of p.tracks) if (t.file && !muUsedElsewhere(t.file)) neo.musicDeleteFile(t.file);  // its files, unless another playlist or the trash still uses them
    muSave(); muLoadPlaylist('Favoris'); muStatus('Playlist supprimée');
  }
  const muTrack = (m, online) => ({display_title: m.author ? `${m.title} - ${m.author}` : m.title, author: m.author || '', publish_date: m.publish_date || '', date_added: Date.now() / 1000,
    song_length: muTime(m.duration), duration: +m.duration || 0, url: m.url, thumbnail_url: m.thumbnail_url || m.thumbnail || '', cover: m.cover || '', file: online ? '' : m.file || '', is_online: !!online});

  /* ---------- Rechercher / importer: one field for a name or any YouTube, SoundCloud or Deezer link ---------- */
  const MU_YT = /^https?:\/\/(www\.|m\.)?(youtube\.com|youtu\.be|music\.youtube\.com)\//i, MU_SC = /^https?:\/\/(www\.|m\.)?(soundcloud\.com|on\.soundcloud\.com|snd\.sc)\//i, MU_DZ = /deezer\.com\/|(deezer|dzr)\.page\.link/i;
  async function muSearchDialog() {
    if (mp.pl === 'Favoris') return muNotify('warning', 'NeoMusic', 'Sélectionne une vraie playlist pour ajouter une musique.');
    if (!await muNeedYtdlp()) return;
    const q = await muPrompt('Rechercher / importer', 'Nom de musique, ou lien : vidéo/playlist YouTube, piste/playlist SoundCloud, piste/playlist Deezer :');
    if (!q) return;
    if (MU_YT.test(q)) return /[?&]list=([\w-]+)/.test(q) ? muImportLink(q, 'youtube') : muAddUrl(q);
    if (MU_SC.test(q)) return /soundcloud\.com\/[^/?#]+\/sets\//i.test(q) ? muImportLink(q, 'soundcloud') : muAddUrl(q);
    if (MU_DZ.test(q)) {
      muStatus('Recherche de la piste Deezer...', T.ACCENT_2);
      try {
        const r = await neo.musicDeezer(q);
        if (r.kind === 'playlist') return muImportLink(r.id, 'deezer');
        if (r.kind === 'track') { muStatus('Recherche sur YouTube...', T.ACCENT_2); const [best] = await neo.musicSearch(r.query, 1); if (!best) throw new Error('Introuvable sur YouTube'); return muAddUrl(best.url); }
        return muNotify('warning', 'Rechercher / importer', 'Lien Deezer reconnu mais pas exploitable ici (ni piste, ni playlist) -- ex. lien d\'album ou de profil non pris en charge.');
      } catch (e) { muStatus('Import échoué', T.DANGER); return muNotify('error', 'Piste Deezer', 'Piste introuvable :\n\n' + e.message); }
    }
    muSearchResults(q);
  }
  /* ---------- Chercher un artiste : ses titres les plus écoutés (Deezer), on coche ceux à ajouter à la playlist ouverte ---------- */
  async function muArtistDialog() {
    if (mp.pl === 'Favoris') return muNotify('warning', 'NeoMusic', 'Sélectionne une vraie playlist pour ajouter des musiques.');
    if (!await muNeedYtdlp()) return;
    const q = await muPrompt('Chercher un artiste', "Nom de l'artiste :"); if (!q) return;
    const w = muWindow('Artiste', 720), status = mh('p.muWNote', {text: 'Recherche de ' + q + '…'}), rows = mh('div.muRows'), go = muButton('AJOUTER', () => {}, 'accent'), all = muButton('TOUT COCHER', () => {}, '');
    const head = mh('div.muArtHead', {}, mh('div.ic', {text: q.trim().charAt(0).toUpperCase() || '♪'}), mh('div', {}, mh('b', {text: q}), status)), filter = mh('input.muArtFilter', {placeholder: 'Filtrer les titres…', spellcheck: false}), tools = mh('div.muArtTools', {}, filter, all);
    rows.className = 'muArtList'; w.body.append(head, tools, rows, mh('div.muWEnd', {}, go, muButton('FERMER', w.close, '')));
    let list = [], boxes = [];
    const count = () => { const n = boxes.filter(b => b.checked).length; go.textContent = n ? 'AJOUTER (' + n + ')' : 'AJOUTER'; go.disabled = !n; };
    try {
      const r = await neo.musicArtist(q);
      if (!r) { status.textContent = 'Aucun artiste trouvé.'; return; }
      list = r.tracks; head.querySelector('b').textContent = r.artist; head.querySelector('.ic').textContent = r.artist.charAt(0).toUpperCase(); status.textContent = list.length + ' titres' + (r.fans ? ' · ' + r.fans.toLocaleString('fr-FR') + ' fans' : '') + ' · coche ceux à ajouter dans « ' + mp.pl + ' »';
      if (/^https:\/\//.test(r.picture || '')) { const ph = mh('img.ph', {src: r.picture, alt: r.artist}); ph.onload = () => head.querySelector('.ic')?.replaceWith(ph); }
      const rowEls = [];
      rows.replaceChildren(...list.map((t, i) => { const b = mh('input', {type: 'checkbox'}); boxes.push(b); const row = mh('label.muArtRow', {}, mh('span.n', {text: String(i + 1)}), b, mh('div', {}, mh('b', {text: t.title}), mh('small', {text: t.album || ''})), mh('span.d', {text: t.duration ? muTime(t.duration) : ''})); b.onchange = () => { row.classList.toggle('on', b.checked); count(); }; rowEls.push(row); return row; }));
      filter.oninput = () => { const f = filter.value.toLowerCase(); rowEls.forEach((row, i) => { row.style.display = !f || (list[i].title + ' ' + (list[i].album || '')).toLowerCase().includes(f) ? '' : 'none'; }); };
      all.onclick = () => { const on = boxes.some((b, i) => !b.checked && rowEls[i].style.display !== 'none'); boxes.forEach((b, i) => { if (rowEls[i].style.display !== 'none') { b.checked = on; rowEls[i].classList.toggle('on', on); } }); all.textContent = on ? 'TOUT DÉCOCHER' : 'TOUT COCHER'; count(); };
      go.onclick = async () => {
        const pick = list.filter((_, i) => boxes[i].checked), name = mp.pl; w.close();
        muStatus('Ajout de ' + pick.length + ' titre(s) de ' + r.artist + '…', T.ACCENT_2);
        for (const t of pick) { try { const y = await neo.musicResolve(r.artist, t.title); if (y) await muAddUrl(y.url, name, y); } catch (e) { muWarn('artiste', e); } }
        muStatus('Titres de ' + r.artist + ' ajoutés', T.ACCENT_2);
      };
      count();
    } catch (e) { status.textContent = 'Recherche impossible : ' + e.message; }
  }
  async function muSearchResults(q) {  // five results to choose from (MuPlayer took the first one directly)
    const w = muWindow('Recherche', 620);
    const status = mh('p.muWNote', {text: 'Recherche sur YouTube…'}), rows = mh('div.muRows');
    w.body.append(muH('RÉSULTATS · ' + q), status, rows, mh('div.muWEnd', {}, muButton('FERMER', w.close, 'accent')));
    try {
      const res = await neo.musicSearch(q, 6);
      status.textContent = res.length ? `${res.length} résultat(s) · « ${mp.pl} »` : 'Aucun résultat trouvé.';
      rows.replaceChildren(...res.map(r => mh('div.muWRow', {}, mh('img.muWThumb', {src: r.thumbnail, alt: ''}), mh('div', {}, mh('b', {text: r.title}), mh('span', {text: (r.author || '?') + (r.duration ? ' · ' + muTime(r.duration) : '')})),
        muButton('＋ AJOUTER', e => { e.target.disabled = true; e.target.textContent = 'AJOUTÉE'; muAddUrl(r.url, mp.pl, r); }, 'accent'))));
    } catch (e) { status.textContent = 'Recherche impossible : ' + e.message; muStatus('Recherche échouée'); }
  }
  function muAddUrl(url, name = mp.pl, hint) {  // one song into a playlist: copied from another playlist if it is already somewhere, else downloaded (offline) or only described (online)
    return muQueue(async () => {
      const p = muPl(name); if (!p) return;
      if (p.tracks.some(t => t.url === url)) return muStatus('Déjà présente dans cette playlist');
      const other = mu.playlists.flatMap(x => x.tracks).find(t => t.url === url && (p.mode === 'online' || (t.file && mp.exists[t.file] !== false)));
      if (other) return muAddTracksTo([other], name);
      try {
        let t;
        if (p.mode === 'online') {
          muStatus('Ajout en ligne...', T.ACCENT_2);
          const m = hint?.title ? {...hint, thumbnail_url: hint.thumbnail} : await neo.musicInfo(url);
          m.cover = await neo.musicCover(m.thumbnail_url || m.thumbnail).catch(() => '');
          t = muTrack(m, true);
        } else t = muTrack(await muDownload(url));
        p.tracks.push(t); muSave(); muSizeAchievement(p);
        if (mp.pl === name) muRefresh();
        muStatus(p.mode === 'online' ? 'Musique ajoutée (en ligne)' : 'Musique ajoutée');
        muScheduleReco();
        return t;
      } catch (e) {
        muStatus(p.mode === 'online' ? 'Ajout échoué' : 'Téléchargement échoué', T.DANGER);
        muNotify('error', p.mode === 'online' ? 'Ajout en ligne' : 'Téléchargement', 'Impossible ' + (p.mode === 'online' ? 'd\'ajouter' : 'de télécharger') + ' la musique.\n\n' + e.message);
      }
    });
  }

  /* ---------- whole playlists: YouTube, SoundCloud, Deezer links, or a file (Exportify CSV / JSON / text) ---------- */
  let muImporting = null;
  function muImportWindow(title) {
    const w = muWindow(title, 560), state = {cancel: false};
    const st = mh('b.muImpStatus', {text: 'Analyse de la playlist...'}), det = mh('p.muWNote'), bar = mh('i');
    w.body.append(muH('IMPORT DE PLAYLIST'), st, det, mh('div.muImpBar', {}, bar), mh('div.muWEnd', {}, muButton('ANNULER', () => { state.cancel = true; st.textContent = 'Annulation…'; }, 'danger')));
    state.update = (s, d, f) => { st.textContent = s; det.textContent = d || ''; bar.style.width = Math.round((f || 0) * 100) + '%'; };
    state.w = w;
    return state;
  }
  async function muImportLink(url, kind) {
    if (muImporting) return muNotify('warning', 'NeoMusic', 'Un import de playlist est déjà en cours.');
    const target = mp.pl, ui = muImportWindow('Import de playlist');
    muImporting = ui; muStatus('Analyse de la playlist...', T.ACCENT_2);
    try {
      const entries = await neo.musicEntries(url, kind);
      await muImportEntries(entries, target, ui);
    } catch (e) { ui.w.close(); muNotify('error', 'Import de playlist', 'Impossible de lire cette playlist.\n\n' + e.message); muStatus('Import échoué', T.DANGER); }
    muImporting = null;
  }
  async function muImportEntries(entries, target, ui) {
    const p = muPl(target), online = p.mode === 'online';
    let added = 0, dup = 0, failed = 0;
    for (let i = 0; i < entries.length && !ui.cancel; i++) {
      let e = entries[i];
      ui.update(`${i + 1} / ${entries.length}`, e.title ? e.title + (e.author ? ' — ' + e.author : '') : e.query || e.url, i / entries.length);
      try {
        if (!e.url) { const [best] = await neo.musicSearch(e.query || `${e.title} ${e.author}`, 1); if (!best) throw new Error('introuvable'); e = {...best, ...(e.title ? {} : {})}; }
        if (p.tracks.some(t => t.url === e.url)) { dup++; continue; }
        const other = mu.playlists.flatMap(x => x.tracks).find(t => t.url === e.url && (online || t.file));
        let t;
        if (other) t = {...other, is_online: online || other.is_online};
        else if (online) { const cover = await neo.musicCover(e.thumbnail).catch(() => ''); t = muTrack({...e, cover, thumbnail_url: e.thumbnail}, true); }
        else t = muTrack(await muDownload(e.url));
        p.tracks.push(t); added++;
        if (added % 5 === 0) { muSave(); if (mp.pl === target) muRefresh(); }
      } catch (err) { failed++; muWarn('import', err); }
    }
    muSave(); muSizeAchievement(p); if (mp.pl === target) muRefresh();
    ui.w.close();
    muStatus(ui.cancel ? 'Import annulé' : 'Import terminé', T.ACCENT_2);
    muNotify(failed ? 'warning' : 'success', 'Import de playlist', `${added} musique(s) ajoutée(s) à « ${target} »` + (dup ? `\n${dup} déjà présente(s)` : '') + (failed ? `\n${failed} introuvable(s) ou indisponible(s)` : '') + (ui.cancel ? '\n\nImport annulé avant la fin.' : ''));
  }
  function muCsv(text) {  // rows of a CSV file with quotes, as objects keyed by the header
    const rows = [], row = [''], push = () => rows.push(row.splice(0, row.length, '').slice(0));
    let q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"' && text[i + 1] === '"') { row[row.length - 1] += '"'; i++; } else if (c === '"') q = false; else row[row.length - 1] += c; }
      else if (c === '"') q = true; else if (c === ',') row.push(''); else if (c === '\n') push(); else if (c !== '\r') row[row.length - 1] += c;
    }
    if (row.some(Boolean)) push();
    const [head, ...data] = rows;
    return data.filter(r => r.some(Boolean)).map(r => Object.fromEntries(head.map((h, i) => [h.trim(), r[i] || ''])));
  }
  async function muImportFile(file) {
    if (mp.pl === 'Favoris') return muNotify('warning', 'NeoMusic', 'Sélectionne une vraie playlist avant l\'import.');
    if (!await muNeedYtdlp()) return;
    const text = (await file.text()).replace(/^﻿/, ''), queries = [];
    try {
      if (/\.json$/i.test(file.name)) {
        const d = JSON.parse(text), rows = Array.isArray(d) ? d : d.tracks || [];
        for (const r of rows) { const t = r?.track && typeof r.track === 'object' ? r.track : r || {}; const title = t.track || t.trackName || t.name || t.title; let artist = t.artist || t.artistName || '';
          if (!artist && Array.isArray(t.artists)) artist = t.artists.map(a => a?.name || '').join(', '); if (title) queries.push(`${title} ${artist}`.trim()); }
      } else if (/\.csv$/i.test(file.name)) for (const r of muCsv(text)) { const title = r['Track Name'] || r.track || r.title; if (title) queries.push(`${title} ${r['Artist Name(s)'] || r.artist || r.Artist || ''}`.trim()); }
      else queries.push(...text.split(/\r?\n/).map(l => l.trim()).filter(l => l && !l.startsWith('#')).flatMap(l => /^@(?:[\w-]{11})+$/.test(l) ? l.slice(1).match(/.{11}/g).map(id => 'https://youtu.be/' + id) : [l]));  // QR serré : « @ » puis les identifiants YouTube collés
    } catch (e) { return muNotify('error', 'Import playlist', 'Impossible de lire le fichier :\n\n' + e.message); }
    if (!queries.length) return muNotify('warning', 'Import playlist', 'Aucun titre exploitable dans ce fichier.');
    if (muImporting) return muNotify('warning', 'NeoMusic', 'Un import de playlist est déjà en cours.');
    const ui = muImportWindow('Importer une playlist'); muImporting = ui;
    await muImportEntries(queries.map(q => /^(https?:\/\/|www\.)/.test(q) ? {url: q.replace(/^www\./, 'https://www.')} : {query: q}), mp.pl, ui);
    muImporting = null;
  }

  /* ---------- "Recommandé pour toi", weekly playlists: artists close to the ones you really listen to (Deezer's related artists, weighted by plays) ---------- */
  const muTaste = (cur) => {  // tes artistes, du plus écouté au moins écouté : écoutes + 3 par favori + un bonus pour la musique en cours
    const w = new Map(), add = (a, n) => { a = (a || '').trim(); if (a) w.set(a, (w.get(a) || 0) + n); };
    for (const [a, n] of Object.entries(mu.stats.artists || {})) add(a, Math.min(n, 40));
    for (const t of muPl('Favoris').tracks) add(t.author, 3);
    for (const p of mu.playlists) if (!MU_SYSTEM.includes(p.name)) for (const t of p.tracks) add(t.author, .5);  // toute ta bibliothèque compte un peu, pas seulement les favoris
    if (cur) add(cur.author, 12);
    return [...w].map(([artist, x]) => ({artist, w: x})).sort((p, q) => q.w - p.w);
  };
  const muLibraryArtists = () => [...new Set(mu.playlists.flatMap(p => p.tracks.map(t => (t.author || '').trim().toLowerCase())).filter(Boolean))];
  function muScheduleReco() {
    clearTimeout(mp.recoTimer); const req = ++mp.recoReq;
    if ($('muReco')) $('muReco').textContent = 'Recherche...';
    mp.recoTimer = setTimeout(() => muReco(req), 700);
  }
  async function muReco(req) {
    const show = (title, url, cover) => {
      if (req !== mp.recoReq) return;
      mp.recoUrl = url || ''; $('muReco').textContent = title || 'Aucune recommandation disponible.';
      $('muRecoCover').replaceChildren(...(cover && !mu.settings.noImages ? [mh('img', {src: 'neoplugin://neodex.music/cover/' + encodeURIComponent(cover), alt: ''})] : []));
    };
    muCaps ||= await neo.musicCaps().catch(() => muDefaultCaps);
    const cur = mp.cur || muPl(mp.pl).tracks.at(-1);
    if (!muCaps.ytdlp || !cur) return show('', '', '');
    const seeds = muTaste(cur).slice(0, 6);
    if (!seeds.length) return show('', '', '');
    const have = new Set([...muPl(mp.pl).tracks, ...muPl('Favoris').tracks].map(t => t.url).filter(Boolean));
    try {
      const seen = mu.settings.recoSeen ||= [], found = (await neo.musicMix(seeds, muLibraryArtists())).filter(e => e.url && !have.has(e.url) && !seen.includes(e.url));  // classées par proximité avec tes goûts
      if (req !== mp.recoReq) return;
      let pick = found[Math.floor(Math.random() * Math.min(8, found.length))];  // au hasard parmi les 8 plus proches jamais proposées
      if (!pick) for (const s of seeds.slice(0, 3)) { pick = (await neo.musicSearch(s + ' official song', 8)).find(e => !have.has(e.url) && !seen.includes(e.url) && (!e.duration || (e.duration >= 90 && e.duration <= 600)) && !/reaction|interview|review|compilation|mix|playlist|full album|best of|top 10/i.test(e.title)); if (pick || req !== mp.recoReq) break; }
      if (!pick) return show('', '', '');
      seen.push(pick.url); if (seen.length > 80) seen.shift(); muSave();
      show(pick.title, pick.url, await neo.musicCover(pick.thumbnail).catch(() => ''));
    } catch (e) { muWarn('recommandation', e); show('', '', ''); }
  }
  function muAddReco() {
    if (!mp.recoUrl) return;
    if (mp.pl === 'Favoris') return muNotify('warning', 'NeoMusic', 'Sélectionne une vraie playlist pour ajouter une musique.');
    muAddUrl(mp.recoUrl);
  }
  const MU_WEEKLY = ['Radar des sorties', 'Découvertes de la semaine'];
  function muWkUi() {  // le bouton METTRE À JOUR, seulement sur le Radar et les Découvertes
    const b = $('muWkBtn'); if (!b) return; const on = MU_WEEKLY.includes(mp.pl);
    b.hidden = !on; b.disabled = !!mp.weeklyBusy; b.textContent = mp.weeklyBusy ? 'MISE À JOUR…' : 'METTRE À JOUR';
    $('muWkInfo').textContent = on && mu.settings.weeklyAt ? 'mise à jour du ' + new Date(mu.settings.weeklyAt).toLocaleDateString('fr-FR') : '';
  }
  // « Radar des sorties » et « Découvertes de la semaine », remplies une fois par semaine (ou avec METTRE À JOUR).
  // La semaine n'est comptée faite qu'une fois les listes remplies : après une panne de réseau, on réessaie à la prochaine ouverture ;
  // une recherche qui ne trouve rien garde les musiques d'avant au lieu de vider la liste.
  async function muWeekly(force) {
    const wk = muWeek();
    if (mp.weeklyBusy || (!force && mu.settings.weeklyWeek === wk && mu.settings.weeklyAlgo === 4)) return;
    muCaps ||= await neo.musicCaps().catch(() => muDefaultCaps);
    if (!muCaps.ytdlp) { if (force) muNotify('warning', 'NeoMusic', 'Le téléchargement n\'est pas encore prêt : réessaie dans un instant.'); return; }
    const taste = muTaste(), artists = taste.map(x => x.artist);
    if (!artists.length) return muStatus('Radar : ajoute des favoris ou écoute quelques musiques');
    mp.weeklyBusy = true; muWkUi();
    return muQueue(async () => {
      try {
        let news = await neo.musicRadar(artists.slice(0, 30)).catch(() => []);
        if (news.length < 3) news = [...news, ...await neo.musicWeekly(artists.slice(0, 6).map(a => a + ' new release'), true).catch(() => [])];  // sans Deezer : la recherche YouTube d'avant
        const nr = await muFillWeekly('Radar des sorties', news.slice(0, 24));
        const nd = await muFillWeekly('Découvertes de la semaine', (await neo.musicMix(taste.slice(0, 8), muLibraryArtists()).catch(() => [])).slice(0, 12));
        if (nr + nd) { Object.assign(mu.settings, {weeklyWeek: wk, weeklyAlgo: 4, weeklyAt: Date.now()}); muSave(); muStatus(`Cette semaine : ${nr} sortie${nr > 1 ? 's' : ''} et ${nd} découverte${nd > 1 ? 's' : ''}`); }
        else muStatus('Rien trouvé cette fois : nouvel essai à la prochaine ouverture', T.WARN);
      } catch (e) { muStatus('Mise à jour hebdomadaire indisponible', T.DANGER); muWarn('hebdo', e); }
      finally { mp.weeklyBusy = false; muWkUi(); }
    });
  }
  async function muFillWeekly(name, entries) {
    const p = muPl(name), old = p.tracks, elsewhere = new Set(mu.playlists.filter(x => x !== p).flatMap(x => x.tracks.map(t => t.url))), keep = new Map(old.map(t => [t.url, t]));
    const todo = entries.filter(e => e.url && !elsewhere.has(e.url)), items = [];
    for (const [i, e] of todo.entries()) {
      muStatus(`${name} : ${i + 1} / ${todo.length}`);
      if (keep.has(e.url)) { items.push(keep.get(e.url)); continue; }  // déjà là la semaine d'avant : pas de nouveau téléchargement
      try { items.push(muTrack(await muDownload(e.url))); } catch (err) { muWarn(name, err); }
    }
    if (!items.length) return 0;  // rien de neuf : on garde la liste d'avant
    const now = new Set(items.map(t => t.url));
    p.tracks = items; muSave(); if (mp.pl === name) muRefresh();
    for (const t of old) if (!now.has(t.url) && t.file && !muUsedElsewhere(t.file)) neo.musicDeleteFile(t.file);  // les musiques de la semaine d'avant s'en vont, sauf si gardées ailleurs
    return items.length;
  }

  /* ---------- sleep mode, music alarm ---------- */
  async function muSleepDialog() {
    const v = await muPrompt('Mode sommeil', 'Nombre de morceaux avant arrêt (vide = durée) :');
    if (v == null) return;
    if (v) {
      if (!/^\d+$/.test(v)) return muNotify('warning', 'Mode sommeil', 'Entre un nombre entier de morceaux.');
      mp.sleepTracks = Math.max(1, +v); mp.sleepAt = null; muSleepIndicator();
      return muStatus(`Sommeil après ${mp.sleepTracks} morceaux`);
    }
    const m = await muPrompt('Mode sommeil', 'Durée en minutes :');
    if (!m) return;
    if (!(+m.replace(',', '.') > 0)) return muNotify('warning', 'Mode sommeil', 'Entre une durée en minutes.');
    mp.sleepTracks = null; mp.sleepAt = Date.now() + Math.max(1, +m.replace(',', '.')) * 60000; muSleepIndicator();
    muStatus('Mode sommeil activé');
  }
  function muSleepIndicator() {
    clearInterval(mp.sleepTimer);
    const el = $('muSleep'), paint = () => { el.textContent = mp.sleepTracks != null ? `☾ ${mp.sleepTracks} pistes` : mp.sleepAt ? '☾ ' + muTime((mp.sleepAt - Date.now()) / 1000) : ''; if (!mp.sleepAt && mp.sleepTracks == null) clearInterval(mp.sleepTimer); };
    paint(); if (mp.sleepAt) mp.sleepTimer = setInterval(paint, 1000);
  }
  function muSleepCountdown() {  // true when the sleep mode just stopped the music
    if (mp.sleepTracks != null) {
      if (--mp.sleepTracks <= 0) { mp.sleepTracks = null; muSleepIndicator(); muStop(); muStatus('Mode sommeil terminé'); return true; }
      muSleepIndicator();
    }
    if (mp.sleepAt && Date.now() >= mp.sleepAt) { mp.sleepAt = null; muSleepIndicator(); muStop(); muStatus('Mode sommeil terminé'); return true; }
    return false;
  }
  async function muWakeDialog() {
    const v = await muPrompt('Réveil musical', 'Heure de lecture (HH:MM) :');
    if (!v) return;
    const m = /^(\d{1,2})[:hH](\d{2})$/.exec(v.trim());
    if (!m || +m[1] > 23 || +m[2] > 59) return muNotify('warning', 'Réveil musical', 'Utilise le format HH:MM, par exemple 07:30.');
    const t = new Date(); t.setHours(+m[1], +m[2], 0, 0); if (t <= Date.now()) t.setDate(t.getDate() + 1);
    clearTimeout(mp.wakeTimer); clearInterval(mp.wakeTick);
    mp.wakeAt = +t;
    mp.wakeTimer = setTimeout(() => { mp.wakeAt = null; $('muWake').textContent = ''; clearInterval(mp.wakeTick); muStatus('Réveil musical'); if (!muAudio || muAudio.paused) muToggle(); }, t - Date.now());
    const paint = () => { $('muWake').textContent = mp.wakeAt ? '◷ ' + muTime((mp.wakeAt - Date.now()) / 1000) : ''; };
    paint(); mp.wakeTick = setInterval(paint, 1000);
    muStatus(`Réveil programmé à ${m[1].padStart(2, '0')}:${m[2]}`);
  }

  /* ---------- levels (from the listening time) and achievements ---------- */
  const muMinutesFor = l => l <= 1 ? 0 : 5.57 * (l - 1) ** 1.55;  // niveau 100 = ~115 h d écoute
  function muLevel() {
    const total = ((+mu.stats.seconds || 0) + (+mu.stats.levelBonus || 0)) / 60; let level = 1;
    while (muMinutesFor(level + 1) <= total) level++;
    const floor = muMinutesFor(level), next = muMinutesFor(level + 1);
    return {level, total, next, progress: Math.max(0, Math.min(1, (total - floor) / Math.max(1, next - floor)))};
  }
  function muLevelCheck() {
    const {level} = muLevel(); if (level <= (+mu.stats.xp_level_seen || 1)) return;
    mu.stats.xp_level_seen = level;
    const theme = Object.entries(MU_THEME_LEVEL).find(([, l]) => l === level)?.[0];
    muStatus(theme ? `Niveau ${level} atteint — thème « ${theme} » débloqué !` : level === 100 ? 'Niveau 100 atteint — super visualiseur débloqué (Options) !' : level === 200 ? 'Niveau 200 atteint — interface Deluxe débloquée (Options) !' : muDeckNew(level) ? `Niveau ${level} atteint — platine : ${muDeckNew(level)} (Options) !` : `Niveau ${level} atteint !`, T.ACCENT);
    muSave();
  }
  function muUnlock(id) {
    if (mu.achievements.unlocked[id]) return;
    mu.achievements.unlocked[id] = muStamp(); muSave();
    muStatus('Succès débloqué : ' + (MU_ACHIEVEMENTS.find(a => a[0] === id)?.[1] || id), T.ACCENT);
  }
  function muMonthDone(year, month, weekdays, covered, today) {  // every Saturday/Sunday (or Sunday) of the month, checked on the last one
    const days = new Date(year, month, 0).getDate(), match = [];
    for (let d = 1; d <= days; d++) if (weekdays.includes((new Date(year, month - 1, d).getDay() + 6) % 7)) match.push(d);
    return match.length && today === match.at(-1) && match.every(d => covered.includes(d));
  }
  function muRecordPlay(t) {
    const st = mu.stats, title = t.display_title || '', artist = t.author || 'Inconnu', now = new Date(), today = muToday(now);
    st.plays = (+st.plays || 0) + 1; st.songs[title] = (+st.songs[title] || 0) + 1; st.artists[artist] = (+st.artists[artist] || 0) + 1; st.daily[today] = (+st.daily[today] || 0) + 1;
    st.history.push({title, artist, playlist: muPlaylistOf(t)?.name || mp.pl, date: muStamp(now)}); st.history = st.history.slice(-100);
    t.last_played = Date.now() / 1000;
    const pr = mu.achievements.progress;
    if (st.plays >= 1) muUnlock('first_play'); if (st.plays >= 100) muUnlock('hundred_plays'); if (st.plays >= 1000) muUnlock('thousand_plays');
    if (st.seconds >= 24 * 3600) muUnlock('marathon'); if (st.seconds >= 168 * 3600) muUnlock('full_week');
    const songs = new Set(pr.unique_songs); songs.add(muId(t)); pr.unique_songs = [...songs]; if (songs.size >= 500) muUnlock('five_hundred_unique');
    if (t.author) { const a = new Set(pr.unique_artists); a.add(t.author); pr.unique_artists = [...a]; if (a.size >= 50) muUnlock('explorer_50_artists'); }
    const h = now.getHours(), mn = now.getMinutes(), m = now.getMonth() + 1, d = now.getDate(), wd = (now.getDay() + 6) % 7;
    if (h >= 2 && h < 5) muUnlock('insomniac'); if (h < 7) muUnlock('early_bird'); if (h === 0) muUnlock('night_owl');
    if (wd === 4 && d === 13) muUnlock('friday_13'); if (m === 12 && d === 31) muUnlock('new_years_eve'); if (m === 12 && d === 25) muUnlock('christmas'); if (h === mn) muUnlock('palindrome');
    if (pr.last_active_date !== today) {
      const gap = pr.last_active_date ? Math.round((new Date(today) - new Date(pr.last_active_date)) / 864e5) : null;
      if (gap === 1) pr.streak_count = (+pr.streak_count || 0) + 1; else { if (gap >= 30) muUnlock('grand_prince'); pr.streak_count = 1; }
      pr.last_active_date = today;
    }
    const s = +pr.streak_count || 0;
    if (s >= 3) muUnlock('streak_3'); if (s >= 7) muUnlock('streak_7'); if (s >= 30) { muUnlock('streak_30'); muUnlock('grand_prince'); } if (s >= 100) muUnlock('streak_100');
    if (wd >= 5) { if (pr.weekend_month !== m) { pr.weekend_month = m; pr.weekend_days = []; } if (!pr.weekend_days.includes(d)) pr.weekend_days.push(d); if (muMonthDone(now.getFullYear(), m, [5, 6], pr.weekend_days, d)) muUnlock('weekend_warrior'); }
    if (wd === 6) { if (pr.sunday_month !== m) { pr.sunday_month = m; pr.sunday_days = []; } if (!pr.sunday_days.includes(d)) pr.sunday_days.push(d); if (muMonthDone(now.getFullYear(), m, [6], pr.sunday_days, d)) muUnlock('sunday_ritual'); }
    if (t.date_added && Date.now() / 1000 - t.date_added < 86400) muUnlock('fresh_out');
    if ((+st.songs[title] || 0) >= 50) muUnlock('loyal_fan');
    if (pr.obsession_date !== today) { pr.obsession_date = today; pr.obsession_counts = {}; }
    pr.obsession_counts[title] = (+pr.obsession_counts[title] || 0) + 1; if (pr.obsession_counts[title] >= 10) muUnlock('obsession');
    muSave();
  }
  function muFavAchievements() { const n = muPl('Favoris').tracks.length; if (n >= 1) muUnlock('first_favorite'); if (n >= 50) muUnlock('fifty_favorites'); }
  function muSizeAchievement(p) { if (p.tracks.length >= 100) muUnlock('mega_playlist'); }
  function muPlaylistCreated() { const pr = mu.achievements.progress; pr.playlists_created = (+pr.playlists_created || 0) + 1; if (pr.playlists_created >= 1) muUnlock('architect'); if (pr.playlists_created >= 10) muUnlock('dj_in_training'); muSave(); }
  function muShuffleAchievement(id) { const pr = mu.achievements.progress; if (id && pr.last_shuffle_identity === id) muUnlock('lucky'); pr.last_shuffle_identity = id; muSave(); }
  function muShortcutAchievement() { const pr = mu.achievements.progress; pr.shortcut_uses = (+pr.shortcut_uses || 0) + 1; if (pr.shortcut_uses >= 10) muUnlock('shortcut_pro'); muSave(5000); }
  function muStartupAchievements() { const f = mu.achievements.progress.first_seen_date; if (f && (Date.now() - new Date(f)) / 864e5 >= 365) muUnlock('one_year'); }

  /* ---------- Statistiques ---------- */
  function muStatCard(value, label, color) { return mh('div.muStat', {}, mh('b', {text: value, style: {color: color || T.ACCENT}}), mh('span', {text: label})); }
  function muBarChart(values, labels, color, highlightLast) {
    const max = Math.max(1, ...values);
    return mh('div.muChart', {}, ...values.map((v, i) => mh('div', {title: labels[i] + ' : ' + v}, mh('i', {style: {height: Math.max(v ? 3 : 0, v / max * 84) + 'px', background: !highlightLast || i === values.length - 1 ? color : muShade(color, -.45)}}), mh('span', {text: labels[i]}))));
  }
  function muBarRow(rank, primary, secondary, value, max, color) {
    return mh('div.muBarRow', {}, mh('b', {text: rank + '.'}), mh('div', {}, mh('span', {text: primary}), mh('i', {}, mh('i', {style: {width: Math.max(2, Math.min(100, value / (max || 1) * 100)) + '%', background: color}}))), mh('em', {text: secondary}));
  }
  function muStats() {
    const st = mu.stats, plays = +st.plays || 0, secs = +st.seconds || 0, daily = st.daily, w = muWindow('Statistiques', 760), b = w.body;
    const days = Object.keys(daily).filter(d => +daily[d] > 0).sort(), today = new Date(), dayN = d => +daily[muToday(d)] || 0;
    let cur = 0, bestRun = 0, run = 0, prev = null;
    for (const d of days) { const t = new Date(d); run = prev && Math.round((t - prev) / 864e5) === 1 ? run + 1 : 1; bestRun = Math.max(bestRun, run); prev = t; }
    if (prev && Math.round((new Date(muToday(today)) - prev) / 864e5) <= 1) cur = run;
    const mon = new Date(today); mon.setDate(today.getDate() - (today.getDay() + 6) % 7);
    const week = days.filter(d => d >= muToday(mon)).reduce((a, d) => a + +daily[d], 0), month = days.filter(d => d.startsWith(muToday(today).slice(0, 7))).reduce((a, d) => a + +daily[d], 0);
    const bestDay = days.slice().sort((a, x) => daily[x] - daily[a])[0];
    b.append(mh('div.muWHead', {}, muH('STATISTIQUES D\'ÉCOUTE'), days[0] ? mh('span', {text: 'Depuis le ' + days[0].split('-').reverse().join('/')}) : null));
    b.append(muSec('VUE D\'ENSEMBLE'), mh('div.muStats', {}, ...[[String(plays), 'Lectures totales'], [muTime(secs), 'Temps total écouté'], [String(Object.keys(st.songs).length), 'Titres différents écoutés'],
      [String(Object.keys(st.artists).length), 'Artistes différents écoutés'], [muTime(plays ? secs / plays : 0), 'Durée moyenne par lecture'], [String(days.length), 'Jours d\'activité'],
      [cur + ' jour(s)', 'Série d\'écoute actuelle'], [bestRun + ' jour(s)', 'Meilleure série d\'écoute'], [bestDay ? bestDay.slice(8) + '/' + bestDay.slice(5, 7) + ` (${daily[bestDay]})` : '--', 'Jour le plus actif']].map(([v, l]) => muStatCard(v, l))));
    b.append(mh('div.muStats', {}, muStatCard(String(dayN(today)), 'Écoutes aujourd\'hui', T.ACCENT_2), muStatCard(String(week), 'Écoutes cette semaine', T.ACCENT_2), muStatCard(String(month), 'Écoutes ce mois-ci', T.ACCENT_2)));
    const last14 = Array.from({length: 14}, (_, i) => { const d = new Date(today); d.setDate(d.getDate() - 13 + i); return d; });
    b.append(muSec('ACTIVITÉ - 14 DERNIERS JOURS'), muBarChart(last14.map(dayN), last14.map(d => String(d.getDate()).padStart(2, '0')), T.ACCENT, true));
    const wk = [0, 0, 0, 0, 0, 0, 0]; for (const d of days) wk[(new Date(d).getDay() + 6) % 7] += +daily[d];
    b.append(muSec('RÉPARTITION PAR JOUR DE LA SEMAINE'), muBarChart(wk, ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'], T.ACCENT_2));
    const top = (o, n = 10) => Object.entries(o).sort((a, x) => x[1] - a[1]).slice(0, n), none = () => mh('p.muWNote', {text: 'Aucune donnée'});
    const ts = top(st.songs); b.append(muSec('TOP 10 TITRES LES PLUS ÉCOUTÉS'), ...(ts.length ? ts.map(([t, n], i) => muBarRow(i + 1, t, n + ' lecture(s)', n, ts[0][1], T.ACCENT)) : [none()]));
    const tt = top(st.songs_time); b.append(muSec('TOP 10 TITRES PAR TEMPS D\'ÉCOUTE'), ...(tt.length ? tt.map(([t, s], i) => muBarRow(i + 1, t, muTime(s), s, tt[0][1], T.ACCENT)) : [none()]));
    const ta = top(st.artists); b.append(muSec('TOP 10 ARTISTES'), ...(ta.length ? ta.map(([a, n], i) => muBarRow(i + 1, a, n + ' lecture(s)' + (st.artists_time[a] ? ' · ' + muTime(st.artists_time[a]) : ''), n, ta[0][1], T.ACCENT_2)) : [none()]));
    const recent = st.history.slice(-8).reverse();
    b.append(muSec('ACTIVITÉ RÉCENTE'), ...(recent.length ? recent.map(e => mh('div.muRecent', {}, mh('span', {text: `${e.title || '?'} — ${e.artist || '?'}`}), mh('em', {text: e.date || ''}))) : [none()]));
    const lv = muLevel();
    b.append(muSec('NIVEAU'), mh('p.muWNote', {text: `Niveau ${lv.level} — ${Math.floor((+mu.stats.seconds || 0) / 60)} min d'écoute cumulées`}), mh('div.muLevel', {}, mh('i', {style: {width: Math.max(1, lv.progress * 100) + '%'}})));
    b.append(mh('div.muWEnd', {}, muButton('FERMER', w.close, 'accent')));
  }

  /* ---------- Succès ---------- */
  function muAchievements() {
    const list = MU_ACHIEVEMENTS.filter(a => a[0] !== 'hidden_font' || mu.achievements.unlocked.hidden_font);  // the Discord bonus font has no place in NeoDex
    const w = muWindow('Succès', 760), un = mu.achievements.unlocked;
    w.body.append(mh('div.muWHead', {}, muH('SUCCÈS'), mh('b.muAchCount', {text: `${list.filter(a => un[a[0]]).length} / ${list.length}`})), muNote('Clique sur un succès verrouillé pour voir comment le débloquer.'));
    for (const [id, name, desc] of list) {
      const at = un[id];
      w.body.append(mh('div.muAch' + (at ? '.on' : ''), {}, at ? mh('b', {text: name}) : mh('span.muLock', {html: muLock(34)}),
        mh('div', {}, mh('p', {text: desc}), at ? mh('em', {text: 'Débloqué le ' + at}) : null)));
    }
    w.body.append(mh('div.muWEnd', {}, muButton('FERMER', w.close, 'accent')));
  }

  /* ---------- Corbeille (7 days) ---------- */
  function muTrash() {
    muCleanupTrash();
    const w = muWindow('Corbeille', 700); let pick = -1;
    const list = mh('div.muTrashList', {}, ...mu.trash.map((e, i) => mh('button', {text: `${e.title || e.item?.display_title || '?'}  —  ${e.playlist || 'playlist inconnue'}`, onclick: ev => { pick = i; list.querySelectorAll('button').forEach(b => b.classList.toggle('on', b === ev.target)); }})));
    if (!mu.trash.length) list.append(mh('p.muWNote', {text: 'La corbeille est vide.'}));
    w.body.append(muH('CORBEILLE · RESTAURATION SOUS 7 JOURS'), list, mh('div.muWEnd', {}, muButton('RESTAURER', () => {
      if (pick < 0) return;
      const e = mu.trash.splice(pick, 1)[0], target = muPl(e.playlist) ? e.playlist : mp.pl;
      muPl(target).tracks.push(e.item); muSave(); w.close();
      if (target === mp.pl) muRefresh();
      muStatus(`Musique restaurée dans « ${target} »`);
    }, 'accent')));
  }

  /* ---------- Vérifier la bibliothèque, stockage, journal ---------- */
  async function muLibraryCheck() {
    const w = muWindow('Vérifier la bibliothèque', 640);
    w.body.append(muH('VÉRIFICATION DE LA BIBLIOTHÈQUE'), muNote('Analyse en cours…'));
    const files = [...new Set(mu.playlists.flatMap(p => p.tracks.map(t => t.file)).filter(Boolean))];
    Object.assign(mp.exists, await neo.musicExists(files));
    const missing = mu.playlists.flatMap(p => p.mode === 'offline' ? p.tracks.filter(t => t.file ? mp.exists[t.file] === false : !t.url).map(t => ({t, p})) : []);
    const dups = mu.playlists.flatMap(p => { const c = {}; for (const t of p.tracks) c[muId(t)] = (c[muId(t)] || 0) + 1; return Object.entries(c).filter(([, n]) => n > 1).map(([id, n]) => ({p, id, n, title: p.tracks.find(t => muId(t) === id).display_title})); });
    const used = new Set([...files, ...mu.trash.map(e => e.item?.file).filter(Boolean)]), orphans = (await neo.musicFiles()).filter(f => !used.has(f));
    const section = (title, n, lines) => mh('div.muCheck', {}, mh('b', {text: `${title} (${n})`, style: {color: n ? T.WARN : T.TEXT}}), mh('pre', {text: n ? lines.slice(0, 6).join('\n') + (n > 6 ? `\n… et ${n - 6} de plus` : '') : 'Rien à signaler.'}));
    w.body.replaceChildren(muH('VÉRIFICATION DE LA BIBLIOTHÈQUE'), muNote('Fichiers manquants, doublons et fichiers orphelins détectés.'),
      section('Fichiers manquants', missing.length, missing.map(m => `${m.t.display_title}  —  ${m.p.name}`)), section('Doublons', dups.length, dups.map(d => `${d.title} ×${d.n}  —  ${d.p.name}`)), section('Fichiers orphelins', orphans.length, orphans),
      mh('div.muWBtns', {},
        muButton('RETIRER LES MANQUANTS', async () => { if (!missing.length || !await muConfirm('Fichiers manquants', `Retirer ${missing.length} musique(s) introuvable(s) de leurs playlists ?`)) return; for (const {t, p} of missing) p.tracks.splice(p.tracks.indexOf(t), 1); muSave(); muRefresh(); w.close(); muStatus('Musiques manquantes retirées'); }),
        muButton('RETÉLÉCHARGER LES MANQUANTS', () => { const todo = missing.filter(m => m.t.url); if (!todo.length) return; w.close(); for (const {t} of todo) muQueue(() => muDownloadInto(t).then(() => muSave()).catch(e => muWarn('retéléchargement', e))); muStatus(`${todo.length} musique(s) en cours de téléchargement`, T.ACCENT_2); }),
        muButton('RETIRER LES DOUBLONS', async () => { if (!dups.length || !await muConfirm('Doublons', 'Ne garder qu\'un exemplaire de chaque musique dans chaque playlist ?')) return; for (const p of mu.playlists) { const seen = new Set(); p.tracks = p.tracks.filter(t => !seen.has(muId(t)) && seen.add(muId(t))); } muSave(); muRefresh(); w.close(); muStatus('Doublons retirés'); }),
        muButton('SUPPRIMER LES ORPHELINS', async () => { if (!orphans.length || !await muConfirm('Fichiers orphelins', `Supprimer définitivement ${orphans.length} fichier(s) qui ne sont dans aucune playlist ?`)) return; for (const f of orphans) await neo.musicDeleteFile(f); w.close(); muStatus('Fichiers orphelins supprimés'); }, 'danger')));
  }
  const muSize = n => n >= 1 << 30 ? (n / (1 << 30)).toFixed(2) + ' Go' : n >= 1 << 20 ? (n / (1 << 20)).toFixed(1) + ' Mo' : Math.round(n / 1024) + ' Ko';
  async function muStorage() {
    const w = muWindow('Stockage', 600), s = await neo.musicStorage();
    const row = (label, x) => mh('div.muRecent', {}, mh('span', {text: label}), mh('em', {text: muSize(x.bytes) + (x.count > 1 ? ` · ${x.count} fichiers` : '')}));
    w.body.append(muH('POIDS DE NEOMUSIC'), muNote(s.root), row('Musiques', s.musics), row('Pochettes', s.covers), row('Formes d\'onde et volume (cache de ce PC)', s.cache),
      mh('div.muRecent.total', {}, mh('span', {text: 'Total'}), mh('em', {text: muSize(s.musics.bytes + s.covers.bytes + s.cache.bytes)})),
      mh('div.muWEnd', {}, muButton('VIDER LES CACHES', async () => { if (!await muConfirm('Vider les caches', 'Les formes d\'onde et les volumes seront recalculés à la prochaine écoute. Continuer ?')) return; await neo.musicClearCache(); muCache = {}; w.close(); muStatus('Caches vidés'); muDrawProgress(true); }), muButton('FERMER', w.close, 'accent')));
  }
  function muLogs() {
    const w = muWindow('Journal', 640);
    w.body.append(muH('JOURNAL DE NEOMUSIC'), mh('pre.muLogs', {text: muLog.length ? muLog.slice().reverse().join('\n') : 'Aucune erreur pour l\'instant.'}), mh('div.muWEnd', {}, muButton('FERMER', w.close, 'accent')));
  }

  /* ---------- QR codes: the music list of a playlist (Options, EXPORTER EN QR CODE). Encoder copied from Qraft (byte mode, versions 1-40, Reed-Solomon, 8 masks) ---------- */
  const muQr = (() => {
  // ---------- l'encodeur ----------
  const ECL = {L: [0, 1], M: [1, 0], Q: [2, 3], H: [3, 2]};  // [indice dans les tables, bits de format]
  const ECC_PER_BLOCK = [
    [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
    [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]];
  const NUM_BLOCKS = [
    [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
    [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
    [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]];
  const rawModules = v => { let r = (16 * v + 128) * v + 64; if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; };
  const dataCodewords = (v, e) => Math.floor(rawModules(v) / 8) - ECC_PER_BLOCK[e][v] * NUM_BLOCKS[e][v];
  const alignPos = v => { if (v === 1) return []; const n = Math.floor(v / 7) + 2, size = v * 4 + 17, step = Math.floor((v * 8 + n * 3 + 5) / (n * 4 - 4)) * 2, r = []; for (let p = size - 7; r.length < n - 1; p -= step) r.unshift(p); return [6, ...r]; };
  const gmul = (x, y) => { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11d); z ^= ((y >>> i) & 1) * x; } return z & 255; };
  function rsDivisor(deg) { const r = Array(deg).fill(0); r[deg - 1] = 1; let root = 1; for (let i = 0; i < deg; i++) { for (let j = 0; j < deg; j++) { r[j] = gmul(r[j], root); if (j + 1 < deg) r[j] ^= r[j + 1]; } root = gmul(root, 2); } return r; }
  function rsRemainder(data, div) { const r = div.map(() => 0); for (const b of data) { const f = b ^ r.shift(); r.push(0); div.forEach((c, i) => r[i] ^= gmul(c, f)); } return r; }
  const MASKS = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, x => x % 3 === 0, (x, y) => (x + y) % 3 === 0, (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
    (x, y) => x * y % 2 + x * y % 3 === 0, (x, y) => (x * y % 2 + x * y % 3) % 2 === 0, (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0];
  const formatBits = (e, mask) => { const d = ECL[e][1] << 3 | mask; let r = d; for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537); return (d << 10 | r) ^ 0x5412; };
  // la grille des motifs fixes (repères, synchronisation, alignement, version) : renvoie [modules, estFixe]
  function functionPatterns(v) {
    const size = v * 4 + 17, m = Array.from({length: size}, () => Array(size).fill(false)), fn = m.map(r => r.map(() => false));
    const set = (x, y, d) => { m[y][x] = d; fn[y][x] = true; };
    for (let i = 0; i < size; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    for (const [cx, cy] of [[3, 3], [size - 4, 3], [3, size - 4]]) for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const x = cx + dx, y = cy + dy, d = Math.max(Math.abs(dx), Math.abs(dy)); if (x >= 0 && y >= 0 && x < size && y < size) set(x, y, d !== 2 && d !== 4); }
    const ap = alignPos(v), n = ap.length;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { if ((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0)) continue; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(ap[i] + dx, ap[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }
    drawFormat(m, fn, 0, size);  // réserve la place (les vrais bits viennent avec le masque)
    if (v >= 7) { let r = v; for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1f25); const b = v << 12 | r; for (let i = 0; i < 18; i++) { const d = (b >>> i & 1) === 1, a = size - 11 + i % 3, c = Math.floor(i / 3); set(a, c, d); set(c, a, d); } }
    return [m, fn];
  }
  function drawFormat(m, fn, bits, size) {
    const set = (x, y, d) => { m[y][x] = d; fn[y][x] = true; }, bit = i => (bits >>> i & 1) === 1;
    for (let i = 0; i <= 5; i++) set(8, i, bit(i)); set(8, 7, bit(6)); set(8, 8, bit(7)); set(7, 8, bit(8)); for (let i = 9; i < 15; i++) set(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i++) set(size - 1 - i, 8, bit(i)); for (let i = 8; i < 15; i++) set(8, size - 15 + i, bit(i)); set(8, size - 8, true);
  }
  // l'ordre de lecture en zigzag des modules libres, colonne par colonne de deux, de droite à gauche
  function zigzag(fn) { const size = fn.length, out = []; for (let right = size - 1; right >= 1; right -= 2) { if (right === 6) right = 5; for (let vert = 0; vert < size; vert++) for (let j = 0; j < 2; j++) { const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - vert : vert; if (!fn[y][x]) out.push([x, y]); } } return out; }
  function blocksLayout(v, e) { const nb = NUM_BLOCKS[e][v], ecc = ECC_PER_BLOCK[e][v], raw = Math.floor(rawModules(v) / 8), nShort = nb - raw % nb, shortLen = Math.floor(raw / nb); return {nb, ecc, nShort, shortLen}; }
  function penalty(m) {
    const n = m.length; let p = 0, dark = 0;
    const lines = []; for (let i = 0; i < n; i++) { lines.push(m[i]); lines.push(m.map(r => r[i])); }
    for (const L of lines) { let run = 1; for (let i = 1; i <= n; i++) { if (i < n && L[i] === L[i - 1]) run++; else { if (run >= 5) p += run - 2; run = 1; } }
      for (let i = 0; i + 11 <= n; i++) { const s = L.slice(i, i + 11).map(Number).join(''); if (s === '10111010000' || s === '00001011101') p += 40; } }
    for (let y = 0; y < n - 1; y++) for (let x = 0; x < n - 1; x++) { const c = m[y][x]; if (c === m[y][x + 1] && c === m[y + 1][x] && c === m[y + 1][x + 1]) p += 3; }
    for (const r of m) for (const c of r) if (c) dark++;
    return p + (Math.ceil(Math.abs(dark * 20 - n * n * 10) / (n * n)) - 1) * 10;
  }
  // encode : texte -> {modules, version, mask, ecl, used, cap}
  function encode(text, eclName, forceMask = -1) {
    const bytes = [...new TextEncoder().encode(text)], e = ECL[eclName][0];
    let v = 1; for (; v <= 40; v++) { const need = 4 + (v < 10 ? 8 : 16) + bytes.length * 8; if (need <= dataCodewords(v, e) * 8) break; }
    if (v > 40) return null;
    const bits = [], put = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push(val >>> i & 1); };
    put(4, 4); put(bytes.length, v < 10 ? 8 : 16); bytes.forEach(b => put(b, 8));
    const cap = dataCodewords(v, e) * 8; put(0, Math.min(4, cap - bits.length)); put(0, (8 - bits.length % 8) % 8);
    const data = []; for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
    for (let pad = 0xec; data.length < cap / 8; pad ^= 0xec ^ 0x11) data.push(pad);
    const {nb, ecc, nShort, shortLen} = blocksLayout(v, e), div = rsDivisor(ecc), blocks = []; let k = 0;
    for (let i = 0; i < nb; i++) { const dat = data.slice(k, k + shortLen - ecc + (i < nShort ? 0 : 1)); k += dat.length; const r = rsRemainder(dat, div); if (i < nShort) dat.push(0); blocks.push(dat.concat(r)); }
    const all = []; for (let i = 0; i < blocks[0].length; i++) blocks.forEach((b, j) => { if (i !== shortLen - ecc || j >= nShort) all.push(b[i]); });
    const [base, fn] = functionPatterns(v), size = base.length, order = zigzag(fn);
    order.forEach(([x, y], i) => { base[y][x] = i < all.length * 8 ? (all[i >>> 3] >>> (7 - (i & 7)) & 1) === 1 : false; });
    let best = null;
    for (let mk = 0; mk < 8; mk++) { if (forceMask >= 0 && mk !== forceMask) continue;
      const m = base.map((r, y) => r.map((c, x) => fn[y][x] ? c : c !== MASKS[mk](x, y))); drawFormat(m, fn.map(r => r.slice()), formatBits(eclName, mk), size);
      const p = penalty(m); if (!best || p < best.p) best = {m, p, mask: mk}; }
    return {modules: best.m, version: v, mask: best.mask, ecl: eclName, size, used: bytes.length, cap: dataCodewords(v, e) - (v < 10 ? 2 : 3)};
  }
    return encode;
  })();
  // le moins de codes possible : les identifiants YouTube (11 signes) collés sur une ligne « @… », les autres musiques une par ligne ; un code tient ~2 800 octets (version 40)
  function muQrPages(p, max = 2800) {
    const pages = [], enc = new TextEncoder(); let ids = [], other = [], len = 0;
    const flush = () => { pages.push({n: ids.length + other.length, text: [...(ids.length ? ['@' + ids.join('')] : []), ...other].join('\n')}); ids = []; other = []; len = 0; };
    for (const t of p.tracks) {
      const id = /(?:youtu\.be\/|[?&]v=)([\w-]{11})/.exec(t.url || '')?.[1], l = id ? '' : String(t.url || t.display_title || '').slice(0, 200); if (!id && !l) continue;
      const add = id ? 11 : enc.encode(l).length + 1; if (len && len + add > max) flush(); if (id) ids.push(id); else other.push(l); len += add;
    }
    if (len) flush(); return pages;
  }
  function muQrExport(name) {
    const p = muPl(name); if (!p?.tracks.length) return muNotify('warning', 'QR code', 'Cette playlist est vide.');
    const pages = muQrPages(p); let i = 0;
    const w = muWindow('QR code', 640), can = mh('canvas', {style: {display: 'block', margin: '10px auto', imageRendering: 'pixelated', maxWidth: '100%'}}), info = mh('p.muWNote');
    const show = () => {
      const q = muQr(`# NeoMusic · ${name}` + (pages.length > 1 ? ` · ${i + 1}/${pages.length}` : '') + '\n' + pages[i].text, 'L'), n = q.size + 8, k = Math.max(3, Math.floor(560 / n)), g = can.getContext('2d');
      can.width = can.height = n * k; g.fillStyle = '#fff'; g.fillRect(0, 0, n * k, n * k); g.fillStyle = '#000';
      q.modules.forEach((r, y) => r.forEach((d, x) => d && g.fillRect((x + 4) * k, (y + 4) * k, k, k)));
      info.textContent = `« ${name} » · ` + (pages.length > 1 ? `code ${i + 1} sur ${pages.length} · ` : '') + `${pages[i].n} musique(s)`; prev.disabled = i === 0; next.disabled = i === pages.length - 1; prev.hidden = next.hidden = pages.length < 2;
    };
    const prev = muButton('◀ PRÉCÉDENT', () => { i--; show(); }), next = muButton('SUIVANT ▶', () => { i++; show(); });
    w.body.append(muNote(pages.length > 1 ? 'Scanne les codes un par un : chaque code ajoute ses musiques à la playlist ouverte.' : 'Scanne ce code : ses musiques s\'ajoutent à la playlist ouverte.'), can, info, mh('div.muWEnd', {}, prev, next, muButton('FERMER', w.close, 'accent')));
    show();
  }

  /* ---------- Options ---------- */
  function muDeckPick(level) {  // le choix de la platine ; celles du niveau suivant restent visibles, verrouillées
    if (level < 150) return mh('p.muWNote.ind', {text: 'Platine : se débloque au niveau 150, avec ses socles et ses bras jusqu\'au niveau 190 (tu es niveau ' + level + ').'});
    const [cb, ca] = muDeckParts();
    const row = (label, list, key, cur, swatch) => mh('div.muDecks', {}, mh('span.muSmall', {text: label}), ...Object.entries(list).map(([n, d]) => {
      const sw = mh('i.muSw', {style: {background: swatch(d)}});
      if (d.lv > level) return mh('button.muBtn.locked', {title: d.note, onclick: () => muStatus(`${label === 'SOCLE' ? 'Socle' : 'Bras'} « ${n} » : niveau ${d.lv}.`, T.WARN)}, sw, n + ' · niv. ' + d.lv);
      return mh('button.muBtn' + (n === cur ? '.accent.on' : ''), {title: d.note, onclick: e => {
        const [b, a] = muDeckParts(); Object.assign(mu.settings, {deckBase: b, deckArm: a, [key]: n}); muSave();  // l'autre pièce reste celle d'avant
        for (const x of e.currentTarget.parentElement.querySelectorAll('.muBtn:not(.locked)')) { const on = x === e.currentTarget; x.classList.toggle('on', on); x.classList.toggle('accent', on); }
      }}, sw, n);
    }));
    const theme = muShade(muBlend(T.CARD, T.ACCENT, .2), -.3);
    return mh('div', {}, mh('span.muSmall', {text: 'PLATINE : combine un socle et un bras'}),
      row('SOCLE', MU_BASES, 'deckBase', cb, d => d.mat ? d.mat[0] : theme),
      row('BRAS', MU_ARMS, 'deckArm', ca, d => d.metal ? d.metal[1] : muBlend('#a4a7b4', T.ACCENT, .25)));
  }
  let muOptTab = 'look';
  function muOptions() {
    const st = mu.settings, w = muWindow('Options', 780), b = w.body, lv = muLevel();
    const apply = () => { muSave(); muApplySettingsUi(); muRefresh(); muSetCover(mp.cur); muDrawProgress(true); muPresence(true); };  // chaque réglage s'enregistre dès qu'il change
    const check = (label, key, hint) => { const c = mh('input', {type: 'checkbox', checked: !!st[key], onchange: () => { st[key] = c.checked; apply(); }}); return mh('label.muCheck', {}, c, mh('span', {}, label, ...(hint ? [mh('small', {text: hint})] : []))); };
    b.append(muH('OPTIONS'));
    // des onglets : Apparence, Son, Raccourcis, Plus (l'onglet ouvert reste le même quand la fenêtre se rouvre, après un changement de thème)
    const TABS = [['look', 'Apparence'], ['sound', 'Son'], ['keys', 'Raccourcis'], ['more', 'Plus']], pane = {}, nav = mh('div.muOptNav'), panes = mh('div.muOptPanes');
    for (const [k, label] of TABS) {
      pane[k] = mh('div.muOptPane'); pane[k].hidden = k !== muOptTab; panes.append(pane[k]);
      nav.append(mh('button.muOptTab' + (k === muOptTab ? '.on' : ''), {text: label, onclick: e => { muOptTab = k; for (const [x] of TABS) pane[x].hidden = x !== k; for (const t of nav.children) t.classList.toggle('on', t === e.currentTarget); panes.parentElement.parentElement.scrollTop = 0; }}));
    }
    b.append(mh('div.muOpt', {}, nav, panes));
    const lookTop = mh('div'); pane.look.append(lookTop);
    const dateNow = st.dateAdded ? 'add' : st.releaseDate ? 'rel' : '';
    const dateSel = mh('select.muSelect', {onchange: () => { st.dateAdded = dateSel.value === 'add'; st.releaseDate = dateSel.value === 'rel'; apply(); }}, ...[['', 'Aucune'], ['add', 'Date d\'ajout'], ['rel', 'Date de sortie']].map(([v, t]) => mh('option', {value: v, text: t, selected: v === dateNow})));
    st.ambiance ??= true;  // les réglages d'avant la 2.4.2 n'ont pas cette clé : l'ambiance est là par défaut
    pane.look.append(muSec('AFFICHAGE'), check('Ambiance animée du thème', 'ambiance', 'Étoiles, pétales, neige, bulles… qui bougent avec les basses'), check('Ambiance sur le petit lecteur et le widget', 'ambMini', 'La scène du thème aussi derrière le petit lecteur et le widget de l’accueil'), check('Visualiseur audio', 'visualizer'), ...(lv.level >= 100 ? [check('Super visualiseur', 'superVis', 'Reflet, étincelles et lueur des basses')] : []),
      check('Pochette en disque vinyle', 'vinyl'), check('Forme d\'onde dans la barre de progression', 'waveform'), check('Appli pixel', 'pixelUi', 'Cadres, boutons et police de petit lecteur'),
      ...(lv.level >= 200 ? [check('Interface Deluxe', 'deluxe', 'L\'appli pixel en grand, la platine en vedette')] : []),
      check('Mur de pochettes', 'gallery', 'Une grille de pochettes au lieu de la liste'), check('Petit lecteur', 'mini', 'Seulement les playlists et les musiques'),
      mh('div.muWBtns', {}, mh('span', {text: 'Date dans la liste'}), dateSel), ...(lv.level >= 150 ? [muDeckPick(lv.level)] : []));
    pane.sound.append(muSec('LECTURE'), check('Même volume pour tous les morceaux', 'replaygain', 'ReplayGain : les morceaux trop forts ou trop faibles sont rééquilibrés'));

    // equaliser: 10 bands; moving one switches to "Custom" on save, picking a profile only previews it
    const base = (st.equalizer === 'Custom' ? st.eqBands : MU_PRESETS[st.equalizer] || MU_PRESETS.Normal).slice();
    const sliders = MU_BANDS.map((f, i) => { const v = mh('span', {text: (+base[i]).toFixed(1)}), r = mh('input', {type: 'range', min: -12, max: 12, step: .5, value: base[i], oninput: () => { v.textContent = (+r.value).toFixed(1); eqSave(); }}); return {r, v, col: mh('div.muBand', {}, v, r, mh('b', {text: f >= 1000 ? f / 1000 + 'k' : String(f)}))}; });
    const preset = mh('select.muSelect', {}, ...Object.keys(MU_PRESETS).map(k => mh('option', {text: k, selected: k === st.equalizer})));
    preset.onchange = () => { const g = preset.value === 'Custom' ? st.eqBands : MU_PRESETS[preset.value]; sliders.forEach((s, i) => { s.r.value = g[i]; s.v.textContent = (+g[i]).toFixed(1); }); st.equalizer = preset.value; muSave(); muApplySettingsUi(); };
    const eqSave = () => { st.eqBands = sliders.map(s => +s.r.value); st.equalizer = preset.value = 'Custom'; muSave(); muApplySettingsUi(); };
    pane.sound.append(muSec('ÉGALISEUR'), muNote('Chaque bande en dB. En déplacer une passe le profil en « Custom ».'),
      mh('div.muBands', {}, ...sliders.map(s => s.col)),
      mh('div.muWBtns', {}, muButton('RÉINITIALISER', () => { sliders.forEach(s => { s.r.value = 0; s.v.textContent = '0.0'; }); eqSave(); }), mh('span.muWNote', {text: 'ou profil prédéfini :'}), preset));
    const limiter = check('Limiteur', 'limiter', 'Évite que le son sature à fort volume'), bal = mh('input.muRange', {type: 'range', min: -1, max: 1, step: .05, value: st.balance, oninput: () => { st.balance = Math.round(+bal.value * 100) / 100; muSave(); muApplySettingsUi(); }});
    pane.sound.append(muSec('AUDIO'), limiter, mh('span.muSmall', {text: 'BALANCE GAUCHE / DROITE'}), mh('div.muWBtns', {}, mh('span', {text: 'G'}), bal, mh('span', {text: 'D'}), muButton('RÉINITIALISER', () => { bal.value = 0; bal.oninput(); })));
    const soon = [[100, 'Super visualiseur'], [150, 'Platine'], [170, 'Socles et bras de platine'], [200, 'Interface Deluxe'], ...Object.entries(MU_THEME_LEVEL).map(([n, l]) => [l, 'Thème ' + n])].filter(([l]) => l > lv.level).sort((x, y) => x[0] - y[0]);
    pane.look.append(muSec('NIVEAU ' + lv.level), muNote(Math.floor((+mu.stats.seconds || 0) / 60) + ' min d\'écoute' + (soon.length ? ' · prochain cadeau au niveau ' + soon[0][0] : ' · tout est débloqué')), mh('div.muLevel', {}, mh('i', {style: {width: Math.max(1, lv.progress * 100) + '%'}})),
      ...(soon.length ? [mh('div.muSoon', {}, ...soon.slice(0, 6).map(([l, t]) => mh('div', {}, mh('b', {text: 'Niv. ' + l}), mh('span', {text: t}))))] : []));
    lookTop.append(muSec('THÈME'), mh('div.muThemes', {}, ...Object.entries(MU_THEMES).map(([name, c]) => {
      const need = MU_THEME_LEVEL[name], locked = need && lv.level < need;
      const bar = (col, w) => mh('u', {style: {background: col, width: w || ''}});
      const pv = () => mh('div.pv', {style: {background: c.BG}}, mh('i.sd', {style: {background: c.SIDEBAR}}, bar(c.ACCENT), bar(c.SUBTEXT), bar(c.SUBTEXT)), mh('i.mn', {}, mh('u', {style: {background: c.CARD_ALT}}), mh('s', {style: {background: c.TEXT, opacity: .8}}), mh('s', {style: {background: c.SUBTEXT, opacity: .6}}), mh('em', {style: {background: c.ACCENT}})), mh('i.dk', {style: {background: c.ACCENT, boxShadow: '0 0 0 3px ' + c.CARD_ALT + ', 0 0 0 5px ' + c.BORDER}}));
      if (locked) { const p = pv(); p.append(mh('span.lk', {html: muLock(18)})); return mh('button.muTh.locked', {style: {background: c.CARD, color: c.SUBTEXT, borderColor: c.BORDER}, title: `Thème « ${name} » : niveau ${need}`, onclick: () => muStatus(`Thème « ${name} » débloqué au niveau ${need}.`, T.WARN)}, p, mh('div.nm', {style: {background: c.CARD}}, mh('b', {text: name}), mh('em', {text: 'Niv. ' + need}))); }
      return mh('button.muTh' + (name === st.theme ? '.on' : ''), {style: {background: c.CARD, color: c.TEXT, borderColor: name === st.theme ? c.ACCENT : c.BORDER, boxShadow: name === st.theme ? '0 0 0 2px ' + c.ACCENT : ''}, title: name, onclick: () => { if (name === st.theme) return; st.theme = name; muApplyTheme(); muSave(); muUnlock('customizer'); w.close(); muOptions(); muDrawProgress(true); }}, pv(), mh('div.nm', {style: {background: c.CARD}}, mh('b', {text: (name === st.theme ? '✓ ' : '') + name}), mh('span', {}, bar(c.ACCENT), bar(c.ACCENT_2), bar(c.HEART)))); 
    })), muSec('POLICE'), mh('div.muWBtns', {}, ...[['', 'Celle du thème'], ...Object.entries(MU_FONTS).map(([k, f]) => [k, f[0]])].map(([k, label]) =>
      mh('button.muBtn' + ((st.font || '') === k ? '.accent.on' : ''), {text: label, style: {fontFamily: k ? MU_FONTS[k][1] : ''}, onclick: () => { st.font = k; muApplyTheme(); apply(); w.close(); muOptions(); }}))));
    // shortcuts: click a field then press the combination (Échap cancels, Retour arrière / Suppr clears)
    const captured = {}, keysSave = (key, old) => {
      const vals = Object.values(captured).filter(Boolean);
      if (new Set(vals).size !== vals.length) { captured[key] = old; return muNotify('warning', 'Options', 'Ce raccourci sert déjà.'); }
      st.shortcuts = {...captured}; muSave(); muHotkeys();
    };
    pane.keys.append(muSec('RACCOURCIS CLAVIER'), muNote('Clique sur un champ puis tape la combinaison : avec Ctrl, Alt ou Shift, ou une touche F1 à F12 seule. Échap annule, Suppr retire le raccourci. Ils marchent partout dans Windows, même NeoDex derrière.'));
    for (const [key, label, , def] of MU_SHORTCUTS) {
      captured[key] = key in st.shortcuts ? st.shortcuts[key] : def;
      const f = mh('input.muKey', {readonly: true, value: captured[key] || 'Aucun'});
      f.onkeydown = e => {
        e.preventDefault(); e.stopPropagation();
        if (e.key === 'Escape') return f.blur();
        if (e.key === 'Backspace' || e.key === 'Delete') { const old = captured[key]; captured[key] = ''; keysSave(key, old); return f.blur(); }
        if (['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) return;
        const k = {' ': 'Space', ArrowLeft: 'Left', ArrowRight: 'Right', ArrowUp: 'Up', ArrowDown: 'Down'}[e.key] || (e.key.length === 1 ? e.key.toUpperCase() : e.key);
        const combo = (e.ctrlKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey ? 'Shift+' : '') + k;
        if (!/^F\d{1,2}$/.test(k) && !/(Ctrl|Alt|Shift)\+/.test(combo)) return muStatus('Un raccourci doit inclure Ctrl, Alt ou Shift', T.WARN);
        const old = captured[key]; captured[key] = combo; keysSave(key, old); f.blur();
      };
      f.onfocus = () => f.value = '…'; f.onblur = () => f.value = captured[key] || 'Aucun';
      pane.keys.append(mh('div.muKeyRow', {}, mh('span', {text: label}), f));
    }
    pane.more.append(muSec('DISCORD'), check('Montrer le morceau en cours dans mon statut Discord', 'discord', 'Avec le temps restant, ta playlist et la place du morceau ; « En pause » pendant 10 min quand tu mets en pause. L\'appli Discord ouverte sur ce PC suffit : ni compte ni mot de passe.'));
    pane.more.append(muSec('PC LENT'), check('Sans pochettes', 'noImages', 'Masque les pochettes partout : l\'appli est plus légère'));
    pane.more.append(muSec('ENTRETIEN'), muNote('Pour trouver un problème : les musiques abîmées ou manquantes, le journal des erreurs, et ce que NeoMusic prend sur le disque.'), mh('div.muWBtns', {}, muButton('VÉRIFIER LA BIBLIOTHÈQUE', () => muLibraryCheck()), muButton('VOIR LES LOGS', () => muLogs()), muButton('POIDS SUR LE DISQUE', () => muStorage())));
    const qrPl = mh('select.muSelect', {}, ...mu.playlists.filter(p => p.tracks.length).map(p => mh('option', {text: p.name, selected: p.name === mp.pl})));
    pane.more.append(muSec('EXPORTER EN QR CODE'), muNote('Les musiques d\'une playlist dans un QR code (plusieurs au-delà de 250 musiques). Un téléphone la récupère avec IMPORTER UN QR CODE.'),
      qrPl.options.length ? mh('div.muWBtns', {}, qrPl, muButton('AFFICHER LE QR CODE', () => muQrExport(qrPl.value), 'accent')) : muNote('Aucune playlist n\'a encore de musiques.'));
    b.append(mh('div.muWEnd', {}, mh('span.muWNote', {text: 'Chaque réglage s\'enregistre tout seul.'}), muButton('FERMER', w.close, 'accent')));
  }

  // ---- ce que NeoDex doit savoir de ce plugin ----
  host.hooks({ onTabChange: () => muMiniSync(), onClose: () => { if (muAudio && !muAudio.paused) muPause(); }, audio: () => muAudio ? { audible: !muAudio.paused && !muAudio.muted, muted: muAudio.muted } : null, mute: on => { if (muAudio) muAudio.muted = on; }, playing: () => !!muAudio && !muAudio.paused && !muAudio.muted });  // son de l'onglet, mini-lecteur, fermeture de l'onglet, NeoMe qui danse
  ctx.commands?.on('toggle', () => muToggle());  // les boutons du widget de l'accueil
  ctx.commands?.on('next', () => muNext());
  ctx.commands?.on('prev', () => muPrev());
  ctx.commands?.on('fav', () => { if (mp.cur) { muToggleFav(); muWidget(); } });
  ctx.commands?.on('volup', () => { muSetVolume(mu.settings.volume + .05); muMiniPaint(); muWidget(); });
  ctx.commands?.on('voldown', () => { muSetVolume(mu.settings.volume - .05); muMiniPaint(); muWidget(); });
  // ---- fin ----
  ctx.onOpen(() => { muOpen(); });
  ctx.onClose(() => { try { muAudio?.pause(); } catch {} document.querySelectorAll('.muMini').forEach(e => e.remove()); document.getElementById('muStyle')?.remove(); });
}
